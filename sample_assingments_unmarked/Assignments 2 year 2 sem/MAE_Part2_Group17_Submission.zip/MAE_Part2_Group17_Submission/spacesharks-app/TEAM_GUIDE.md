# SPACESHARKS App: Team Guide (Part 2)

CT124-3-2-MAE, Group 17. Please read this once, fully. If you use an AI assistant for your documents, **paste this whole file into it first**, so it knows the project, your role and what the others are doing.

---

## 1. Key facts

| | |
|---|---|
| Moodle deadline | Monday 2 November 2026, 11:00 PM |
| **Our deadline** | **Friday 30 October 2026.** The weekend is only for fixes. |
| Code freeze | Thursday 29 October, night |
| App | Flutter (Android), MVVM, Firebase (Auth + Firestore), public holidays API |
| Roles in the app | Owner/Manager, Content Creator/Staff, Client |

**What the app is:** a coordination app for SPACESHARKS, a digital marketing agency. It replaces WhatsApp/Viber chasing with one app:
- **Owners** see every client package, overdue items, staff workload and handovers.
- **Staff** see their tasks sorted by urgency, upload file versions, reply to feedback and hand files over.
- **Clients** see their package phase (Introduction → Build-up → Accelerated), approve or request changes with a timestamp, comment, and see next week's content.

Everything follows our Part 1 proposal (use cases OM-UC1–9, ST-UC1–8, CL-UC1–9).

---

## Status (Tue 27 Oct, early morning)

- **The app is built**: all 26 use cases for the 3 roles, task and package CRUD, image uploads, timestamped approvals, handovers, alerts, weekly calendar with the public holidays API.
- **Automated build on GitHub**: every push runs `flutter analyze` (no issues), **89 unit and widget tests (all passing, 88.9% coverage)**, takes screenshots of every screen and builds the APK. The emulator integration tests run in a second workflow. Results are on the `ci-output` and `ci-integration` branches.
- **Drafts exist for all documents** (Hassan shares the links): the design report, the automated test report and the user manual, with real screenshots and diagrams. Your job is now to **review, correct and own** your documents, not write them from zero.
- **Still to do**: connect the real Firebase project (section 6, Kaung + Hassan), build the final APK in Firebase mode, record the demo video.

## 2. How we work: one coder, two document leads

To keep it simple and avoid code conflicts, **only Hassan touches the code**. Kaung and Muntasir do **not** edit or push code. They own Firebase setup, test design and the documents, and each must understand the app well enough to explain it in the Q&A.

| | Hassan (Client role) | Kaung (Owner/Manager role) | Muntasir (Staff role) |
|---|---|---|---|
| **App** | Writes all the code for the 3 roles, runs the tests, builds the APK | Sets up **Firebase in the console** (no code) | Designs the **test cases** (what to test, expected results) |
| **Documents** | Workload matrix, demo video editing, compiles the final report | System description, CRUD table, architecture diagram, **user manual** | Use case diagram (all 3 roles), **automated test report** |
| **Demo video** | Records the Client part | Records the Owner part | Records the Staff part |
| **Q&A** | Explains the code | Explains Firebase, the data model, security rules, owner screens | Explains the tests, the holidays API, staff screens |

The lecturer can ask **anyone** to trace the code. Not being able to explain it can be treated as academic dishonesty. Hassan will walk everyone through the code before Friday, and section 5 explains it.

### What each person needs from the others

| Who | Needs | From | By |
|---|---|---|---|
| Hassan | To be added as a member of the Firebase project | Kaung | Tue 27 |
| Hassan | Test case table (section 6) | Muntasir | Wed 28 |
| Kaung, Muntasir | Screenshots of every screen + test run outputs | Hassan | Thu 29 night |
| Kaung, Muntasir | A 30-minute code walkthrough | Hassan | Thu 29 |
| Hassan | Finished documents | Kaung, Muntasir | Fri 30 afternoon |

---

## 3. Timeline

| Day | Hassan | Kaung | Muntasir |
|---|---|---|---|
| **Tue 27** | Client screens | Create the Firebase project, add Hassan; start the system description | Start the test case table; start the use case diagram |
| **Wed 28** | Owner + Staff screens; connect Firebase | CRUD table + architecture diagram | Finish the test case table → send to Hassan |
| **Thu 29** | Finish all screens, holidays API, automated tests from Muntasir's table; screenshots; code walkthrough. **Code freeze at night** | Start the user manual with screenshots | Start the test report with the test outputs |
| **Fri 30** | APK + ZIP, demo video, workload matrix, compile the report | Finish the user manual | Finish the test report |

---

## 4. Demo accounts (for screenshots and trying the app)

Password for all: `password123`

| Email | Role |
|---|---|
| owner@spacesharks.test | Owner / Manager |
| designer@spacesharks.test, editor@spacesharks.test, writer@spacesharks.test | Staff |
| client@kopikita.test, client@glowskin.test, client@urbanfit.test | Client |

Hassan will share the APK on Thursday so you can install it on an Android phone and try every screen.

---

## 5. How the code works (read this, you will be asked about it)

### Structure (MVVM)

```
lib/
  main.dart                 starts the app, picks demo data or Firebase
  app.dart                  theme + AppScope + AuthGate (role routing)
  core/
    models/                 the data classes (table below)
    data/
      doc_store.dart        one database interface used by everything
      memory_doc_store.dart demo database (sample data, used for building/testing)
      firestore_doc_store.dart  the real Cloud Firestore version
      auth_repository.dart  login (demo and Firebase)
      repositories.dart     ALL business rules (see below)
      seed_data.dart        the sample agency: 3 clients, 3 staff, 12 deliverables
    theme/ utils/ widgets/  colours, validators, date formats, shared widgets
  features/
    auth/                   login screen + sends each role to its home
    owner/  staff/  client/ each role's screens
    shared/                 alerts, calendar, comment thread, file versions
test/                       automated unit and widget tests
integration_test/           end-to-end tests on a phone/emulator
firestore.rules             database security rules
```

**MVVM in one sentence each:**
- **Model**: data classes (`ContentTask`, `ClientPackage`...) that convert to and from Firestore.
- **ViewModel**: one per screen. It gets live data from the repositories and works out lists and counts (for example "overdue items", "Do first"). It has no UI, so we can unit-test it.
- **View**: the screen widgets. They only display the ViewModel's data and call its actions.

**Demo vs Firebase:** every part of the app talks to one `DocStore` interface. In demo mode it is an in-memory database with sample data; in the final app it is Cloud Firestore. The screens never know the difference, which is why the app could be built before Firebase was ready.

### Firestore collections (the data model, for the report)

| Collection | What it stores | Key fields |
|---|---|---|
| `users` | Every account and its role | name, email, role (owner/staff/client), jobTitle, company |
| `packages` | A client's monthly package | clientName, clientUserId, packageName, phase, managerId, promisedItems, startDate |
| `tasks` | Each deliverable (post, reel, graphic...) | packageId, title, contentType, assigneeId, dueDate, publishDate, priority, status, latestVersion, approvedVersion |
| `comments` | Feedback thread messages | taskId, authorId, authorRole, text, createdAt, seenByAgency, seenAt |
| `approvals` | Client decisions, timestamped | taskId, decision (approved / changes requested), byName, versionNumber, note, createdAt |
| `versions` | Uploaded file versions | taskId, versionNumber, fileName, fileUrl, mimeType, uploadedBy, createdAt |
| `handovers` | Files passed between staff | taskId, fromName, toName, sentAt, receivedAt |
| `alerts` | In-app notifications | userId, type, title, body, read, createdAt |

Task status flow: **To do → In progress → Awaiting approval → Approved**, or **→ Changes requested → In progress** again.

### Business rules (in `repositories.dart`, all tested)

- Creating, editing or deleting a task alerts the assigned staff member (ST-UC2).
- A client comment alerts staff; a staff reply alerts the client (ST-UC4, CL-UC4).
- When staff open a thread, client comments get a **"Seen by agency" time** (CL-UC7).
- Staff "Send for approval" sets the status and alerts the client.
- A client decision saves a **timestamped approval**, updates the task, marks the approved version as **Final**, and alerts staff (CL-UC5, CL-UC6, OM-UC5).
- Uploading a file creates the **next version number** (ST-UC5).
- A handover stays **pending until the receiver confirms** (ST-UC6, OM-UC7).

### Third-party API

The weekly calendar calls the free **Nager.Date public holidays API** (`https://date.nager.at/api/v3/PublicHolidays/2026/MY`). It shows Malaysian holidays on the calendar and warns when a post is scheduled on a holiday. Each item also has an **"Add to Google Calendar"** button.

---

## 6. Detailed tasks

### Kaung: Firebase (console only) + design documents

**Firebase.** No code needed. **Follow [FIREBASE.md](FIREBASE.md) step by step**; it has every click. Summary:
1. Go to console.firebase.google.com → **Add project** → name it `spacesharks-app` (Google Analytics: off).
2. **Project settings → Users and permissions → Add member**: add Hassan's Google email as **Owner**. Send Hassan a message when done.
3. **Build → Authentication → Get started → Email/Password → Enable.**
4. **Build → Firestore Database → Create database** → location `asia-southeast1 (Singapore)` → **Start in test mode**.
5. Hassan then connects the app and loads the demo accounts. On Thursday, Kaung and Hassan publish the security rules from `firestore.rules` together.
6. Take screenshots for the report: the Authentication users list, the Firestore collections with data, and the Rules page.

**Documents** (drafts are ready in the shared "Problem Solving and Design" report and the User Manual; review them against the app, fix anything wrong, and make sure you can explain every part):
- **System description:** for each role, the problem (from our research) → our solution → functional requirements with the use case IDs. Reuse proposal sections 2.1 and 3.1.
- **CRUD table:** rows = the 8 collections in section 5, columns = Owner / Staff / Client, cells = C, R, U, D. For example, an owner can CRUD tasks; staff can read and update tasks; a client can read their own tasks and update them only by approving.
- **Architecture diagram** (draw.io): Views → ViewModels → Repositories → DocStore → Firebase Auth / Cloud Firestore, plus the Holidays API. Show demo mode (MemoryDocStore) as an alternative.
- **User manual:** one section per role with screenshots: how to sign in, then each screen and each action, step by step.

### Muntasir: test design + test report + use case diagram

**The test case table and the test report are already drafted** (89 automated test cases, all passing, with run screenshots and coverage). Muntasir: read every test case, check it against the app on a phone, add anything missing, and be ready to explain how `flutter test` and the integration tests work. The format used:

| ID | Role | Use case | Type (unit / widget / integration) | Steps | Expected result |
|---|---|---|---|---|---|
| TC-01 | All | Login | Widget | Leave email and password empty, tap Sign in | "Enter your email." and "Enter your password." shown |
| TC-02 | Client | CL-UC5 | Unit | Client approves "Barista day reel" | Task status = Approved, approval saved with time and name, staff alerted |

Cover **every use case for all 3 roles**: login and validation, owner dashboard counts, task create/edit/delete, staff "Do first" order, upload version, handover, send for approval, client approve / request changes, comments + "seen", alerts, calendar + holidays API, and one **full workflow**: owner creates a task → staff upload and submit → client approves → owner sees it delivered. Aim for about 35–45 cases.

Hassan and AI turn these into automated tests. 36 unit tests already exist and pass, so Hassan will tell you which of your cases they already cover.

**Automated test report (Thu–Fri, 15 marks, must look professional):**
1. Introduction and scope.
2. Tools: `flutter_test` (unit + widget), `integration_test` (end-to-end), run with `flutter test`.
3. Test environment: Flutter version, Android device or emulator, OS.
4. Test case table with **Actual result** and **Pass/Fail** columns added.
5. Screenshots of the test runs and the coverage percentage (Hassan sends these).
6. Bugs found and how they were fixed.
7. Conclusion.

**Use case diagram:** one diagram with all three actors (Owner/Manager, Content Creator/Staff, Client) and their use cases. Part 1 only had the staff one.

### Hassan: all code

1. Client screens: deliverable page (preview, approve / request changes, comments, approval history), approved library, calendar.
2. Owner screens: package detail with task **create / edit / delete**, package create/edit with validation, workload + handovers, status requests, calendar, package health indicator.
3. Staff screens: task detail (upload image version, send for approval, hand over), handovers tab, "My week" + overload flag.
4. Holidays API + "Add to Google Calendar" in the weekly calendar.
5. Connect Firebase, load demo accounts, publish security rules with Kaung.
6. Automated tests from Muntasir's table; send outputs and screenshots.
7. Code walkthrough with both on Thursday.
8. Friday: release APK, source ZIP, demo video edit, workload matrix, compile the final report.

---

## 7. Submission checklist (Hassan uploads)

- [ ] App ZIP (source code) + release APK
- [ ] Demo video (all 3 roles), or a YouTube link in the report
- [ ] One report (Times New Roman 12, single spacing, A4): problem solving and design, automated test report, user manual (all roles), workload matrix, references, AI usage form if required
- [ ] Part 1 documents again: generative research report, project proposal

## 8. Distinction checklist

**App (37):**
- [ ] All three roles work on real Firebase, with create / read / update / delete
- [ ] Every form is validated
- [ ] Every screen has loading, empty and error states
- [ ] Image upload + preview
- [ ] Holidays API visible
- [ ] Phone and tablet layouts
- [ ] Same design on every screen
- [ ] Extra spark: timestamped approvals, "seen" receipts, live updates between roles, package health

**Testing (15):**
- [ ] Unit + widget + integration tests
- [ ] A full workflow test
- [ ] A professional report with a test case table, screenshots and coverage

**Report (15):**
- [ ] System description, requirements, CRUD table, data model
- [ ] Use case diagram for all roles
- [ ] Wireframes for every role
- [ ] Architecture diagram
- [ ] Limitations

**Demo (8):**
- [ ] Video of all roles, user manual, workload matrix
- [ ] **Everyone can explain the code**

## 9. Workload matrix (draft; check your row)

| Member | App role | Built / delivered |
|---|---|---|
| Muhammad Hassan | Client | All app code (3 roles), automated tests, APK, demo video edit, report compilation |
| Kaung Htet | Owner/Manager | Firebase project setup, security rules review, system description, CRUD table, architecture diagram, user manual |
| Muntasir Uzzaman Mashrafi | Content Creator/Staff | Test case design, automated test report, use case diagram |

## 10. Using AI for your documents

- Paste this file first, then ask for one section at a time.
- Give it real facts: our use case IDs, the collections in section 5, the screenshots and test outputs Hassan sends.
- Check every claim against the actual app. Don't let it invent features we don't have.
- Declare AI use in the report if the module requires it.
