package com.spacesharks.spacesharks_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
