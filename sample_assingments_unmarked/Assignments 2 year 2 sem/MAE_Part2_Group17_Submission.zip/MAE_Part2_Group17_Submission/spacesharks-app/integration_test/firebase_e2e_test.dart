// End-to-end test on the REAL Firebase project (Auth + Firestore + security
// rules), driven through the app like a user, with a screenshot at each step.
//
// Uses its own client ("E2E Test Studio") and package so the demo data is not
// touched, and deletes everything it created at the end.
//
// Run on an Android device/emulator (screenshots are saved by the driver):
//   flutter drive --driver=test_driver/integration_test.dart \
//     --target=integration_test/firebase_e2e_test.dart

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:spacesharks_app/app.dart';
import 'package:spacesharks_app/core/data/doc_store.dart';
import 'package:spacesharks_app/core/models/models.dart';
import 'package:spacesharks_app/core/services/app_services.dart';
import 'package:spacesharks_app/firebase_options.dart';

const password = 'password123';
const ownerEmail = 'owner@spacesharks.test';
const writerEmail = 'writer@spacesharks.test';
const designerEmail = 'designer@spacesharks.test';
const clientEmail = 'client@e2etest.test';
const clientCompany = 'E2E Test Studio';
const taskTitle = 'E2E launch post';

/// A real sample photo bundled with the app, used as the uploaded design.
Future<Uint8List> sampleImage(String name) async =>
    (await rootBundle.load('assets/samples/$name')).buffer.asUint8List();

void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  late AppServices services;
  var shotNo = 0;
  var surfaceReady = false;
  final log = <String>[];
  final traces = <String>[];

  void step(String text) {
    log.add(text);
    // ignore: avoid_print
    print('E2E STEP: $text');
  }

  // ---------------------------------------------------------------- helpers
  Future<void> settle(WidgetTester t, [int frames = 6]) async {
    for (var i = 0; i < frames; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 150));
      await t.pump();
    }
  }

  Future<void> waitFor(WidgetTester t, Finder f, {int seconds = 25}) async {
    final end = DateTime.now().add(Duration(seconds: seconds));
    while (DateTime.now().isBefore(end)) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      await t.pump();
      if (f.evaluate().isNotEmpty) return;
    }
    throw TestFailure('Timed out after ${seconds}s waiting for: $f');
  }

  /// Polls [check] until it is true (writes to Firestore take a moment).
  Future<void> eventually(Future<bool> Function() check, String what, {int seconds = 30}) async {
    final end = DateTime.now().add(Duration(seconds: seconds));
    while (DateTime.now().isBefore(end)) {
      if (await check()) return;
      await Future<void>.delayed(const Duration(milliseconds: 500));
    }
    throw TestFailure('Not done after ${seconds}s: $what');
  }

  Future<void> waitGone(WidgetTester t, Finder f, {int seconds = 25}) async {
    final end = DateTime.now().add(Duration(seconds: seconds));
    while (DateTime.now().isBefore(end)) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      await t.pump();
      if (f.evaluate().isEmpty) return;
    }
    throw TestFailure('Still visible after ${seconds}s: $f');
  }

  Future<void> shot(WidgetTester t, String name) async {
    if (!surfaceReady) {
      // Android needs the Flutter surface turned into an image first; web does not.
      if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
        await binding.convertFlutterSurfaceToImage();
      }
      surfaceReady = true;
    }
    await settle(t, 4);
    shotNo++;
    await binding.takeScreenshot('${shotNo.toString().padLeft(2, '0')}_$name');
  }

  /// Scrolls the page (up first, then down) until [f] is built and visible.
  Future<void> scrollTo(WidgetTester t, Finder f) async {
    final scrollable = find.byWidgetPredicate(
        (w) => w is Scrollable && w.axisDirection == AxisDirection.down);
    for (var i = 0; i < 15 && f.evaluate().isEmpty && scrollable.evaluate().isNotEmpty; i++) {
      await t.drag(scrollable.first, const Offset(0, 300));
      await settle(t, 2);
    }
    for (var i = 0; i < 40 && f.evaluate().isEmpty && scrollable.evaluate().isNotEmpty; i++) {
      await t.drag(scrollable.first, const Offset(0, -300));
      await settle(t, 2);
    }
    await waitFor(t, f);
    await t.ensureVisible(f.first);
    await settle(t, 2);
  }

  Future<void> tap(WidgetTester t, Finder f) async {
    try {
      await waitFor(t, f, seconds: 10);
    } on TestFailure {
      await scrollTo(t, f); // built further up or down the page
    }
    final target = f.first;
    await t.ensureVisible(target);
    await settle(t, 2);
    await t.tap(target);
    await settle(t);
  }

  Future<void> enter(WidgetTester t, Finder f, String text) async {
    await waitFor(t, f);
    await t.ensureVisible(f.first);
    await t.enterText(f.first, text);
    await settle(t, 2);
  }

  Future<void> closeKeyboard(WidgetTester t) async {
    FocusManager.instance.primaryFocus?.unfocus();
    await settle(t, 3);
  }

  Future<void> login(WidgetTester t, String email) async {
    await waitFor(t, find.byKey(const Key('emailField')));
    await enter(t, find.byKey(const Key('emailField')), email);
    await enter(t, find.byKey(const Key('passwordField')), password);
    await closeKeyboard(t);
    await tap(t, find.byKey(const Key('loginButton')));
    await waitGone(t, find.byKey(const Key('loginButton')), seconds: 30);
    await settle(t);
  }

  Future<void> logout(WidgetTester t) async {
    // Back to the role's home first.
    while (find.byType(BackButton).evaluate().isNotEmpty) {
      await t.pageBack();
      await settle(t);
    }
    await tap(t, find.byKey(const Key('accountMenu')));
    await tap(t, find.text('Sign out'));
    await waitFor(t, find.byKey(const Key('loginButton')));
  }

  Future<void> tab(WidgetTester t, String label) async {
    final inBar = find.descendant(of: find.byType(NavigationBar), matching: find.text(label));
    await tap(t, inBar);
  }

  Future<void> back(WidgetTester t) async {
    await t.pageBack();
    await settle(t);
  }

  Future<void> dialogText(WidgetTester t, String text) async {
    await enter(t, find.byKey(const Key('dialogTextField')), text);
    await tap(t, find.byKey(const Key('dialogConfirm')));
  }

  String? e2eTaskId;

  /// The E2E task. Found by title the first time (as the owner), then read by
  /// id, because a client may only read their own tasks by id or package.
  Future<ContentTask> e2eTask() async {
    if (e2eTaskId != null) return (await services.tasks.getById(e2eTaskId!))!;
    final docs = await services.store.getCollection(Collections.tasks, whereField: 'title', isEqualTo: taskTitle);
    expect(docs, hasLength(1), reason: 'exactly one "$taskTitle" task');
    e2eTaskId = docs.single.id;
    return ContentTask.fromMap(docs.single.id, docs.single.data);
  }

  /// Runs [action] and names it in the error if Firebase refuses it.
  Future<T> traced<T>(String what, Future<T> Function() action) async {
    // ignore: avoid_print
    print('E2E TRACE: $what');
    traces.add(what);
    try {
      return await action();
    } catch (e) {
      throw TestFailure('$what failed: $e');
    }
  }

  Future<AppUser> me() async => (await services.users.getById(FirebaseAuth.instance.currentUser!.uid))!;

  // ---------------------------------------------------------------- setup
  /// Makes sure the E2E client account exists with a client profile.
  Future<String> ensureE2eClient() async {
    final auth = FirebaseAuth.instance;
    String uid;
    try {
      uid = (await auth.createUserWithEmailAndPassword(email: clientEmail, password: password)).user!.uid;
      // ignore: avoid_print
      print('E2E TRACE: created the E2E client account');
    } on FirebaseAuthException catch (e) {
      if (e.code != 'email-already-in-use') rethrow;
      uid = (await auth.signInWithEmailAndPassword(email: clientEmail, password: password)).user!.uid;
    }
    await auth.signOut();
    // Only an owner may create profiles (security rules).
    await traced('owner signs in', () => auth.signInWithEmailAndPassword(email: ownerEmail, password: password));
    await traced('owner saves the E2E client profile', () => services.users.save(AppUser(
        id: uid, name: 'Erin Tester', email: clientEmail, role: UserRole.client, company: clientCompany)));
    await auth.signOut();
    return uid;
  }

  /// Removes everything this test created (also left-overs from a failed run).
  Future<void> cleanUp(String clientUid) async {
    final auth = FirebaseAuth.instance;
    await auth.signOut();
    await auth.signInWithEmailAndPassword(email: ownerEmail, password: password);
    final pkgs = await traced('owner lists E2E packages',
        () => services.store.getCollection(Collections.packages, whereField: 'clientUserId', isEqualTo: clientUid));
    for (final p in pkgs) {
      await traced('owner deletes package ${p.id} with its tasks', () => services.packages.deleteWithTasks(p.id));
    }
    final strays = await traced('owner lists stray E2E tasks',
        () => services.store.getCollection(Collections.tasks, whereField: 'title', isEqualTo: taskTitle));
    for (final d in strays) {
      await traced('owner deletes stray task ${d.id}', () => services.tasks.delete(ContentTask.fromMap(d.id, d.data)));
    }
    await auth.signOut();
    // Each person deletes their own E2E alerts (alerts are private).
    for (final email in [ownerEmail, writerEmail, designerEmail, clientEmail]) {
      final uid = (await auth.signInWithEmailAndPassword(email: email, password: password)).user!.uid;
      for (final a in await traced('$email reads own alerts', () => services.alerts.getForUser(uid))) {
        final text = '${a.title} ${a.body}';
        if (text.contains('E2E')) {
          await traced('$email deletes alert ${a.id}', () => services.alerts.delete(a.id));
        }
      }
      await auth.signOut();
    }
    await auth.signInWithEmailAndPassword(email: ownerEmail, password: password);
    await traced('owner deletes the E2E client profile', () => services.store.delete(Collections.users, clientUid));
    await auth.signOut();
  }

  Future<void> runFlow(WidgetTester t) async {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    services = AppServices.firebase(useCloudStorage: false);
    await FirebaseAuth.instance.signOut();

    final clientUid = await ensureE2eClient();
    await cleanUp(clientUid); // left-overs from an earlier failed run
    await ensureE2eClient();
    step('Setup: E2E client account ready ($clientEmail)');

    await t.pumpWidget(SpacesharksApp(services: services));
    await waitFor(t, find.byKey(const Key('loginButton')));
    await shot(t, 'login');

    // Login validation and wrong password (FR1, FR17).
    await tap(t, find.byKey(const Key('loginButton')));
    await waitFor(t, find.text('Enter your email.'));
    await shot(t, 'login_validation');
    await enter(t, find.byKey(const Key('emailField')), ownerEmail);
    await enter(t, find.byKey(const Key('passwordField')), 'wrongpass');
    await closeKeyboard(t);
    await tap(t, find.byKey(const Key('loginButton')));
    await waitFor(t, find.byKey(const Key('loginError')), seconds: 30);
    await shot(t, 'login_wrong_password');
    step('Login: empty fields and wrong password are rejected');

    // ---------------------------------------------------------- OWNER
    await login(t, ownerEmail);
    await waitFor(t, find.text('Client packages'));
    await waitFor(t, find.text('Kopi Kita Cafe'));
    await shot(t, 'owner_dashboard_live');
    step('Owner: dashboard loads live packages from Firestore');

    // Create a package through the form (FR2, CRUD create).
    await tap(t, find.byKey(const Key('newPackageButton')));
    await enter(t, find.byKey(const Key('clientNameField')), clientCompany);
    await tap(t, find.byKey(const Key('clientAccountField')));
    await tap(t, find.textContaining(clientEmail).last);
    await enter(t, find.byKey(const Key('packageNameField')), 'E2E Growth Monthly');
    await enter(t, find.byKey(const Key('promisedField')), '6');
    await closeKeyboard(t);
    await shot(t, 'owner_new_package_filled');
    await tap(t, find.byKey(const Key('savePackageButton')));
    await waitFor(t, find.text(clientCompany));
    await shot(t, 'owner_dashboard_with_new_package');
    final pkg = (await services.store.getCollection(Collections.packages, whereField: 'clientUserId', isEqualTo: clientUid)).single;
    step('Owner: created package "${pkg.data['packageName']}" for $clientCompany');

    // Open it, change the phase (OM-UC6, CRUD update).
    await scrollTo(t, find.byKey(Key('package_${pkg.id}')));
    await tap(t, find.byKey(Key('package_${pkg.id}')));
    await waitFor(t, find.byKey(const Key('newTaskButton')));
    await tap(t, find.widgetWithText(ChoiceChip, 'Build-up'));
    await settle(t, 10);
    expect((await services.packages.getById(pkg.id))!.phase, PackagePhase.buildUp);
    await shot(t, 'owner_package_detail_phase_buildup');
    step('Owner: moved the package to the Build-up phase');

    // Create a task through the form (FR3, ST-UC2).
    await tap(t, find.byKey(const Key('newTaskButton')));
    await enter(t, find.byKey(const Key('taskTitleField')), taskTitle);
    await enter(t, find.byKey(const Key('taskDescriptionField')), 'Square post announcing the studio opening.');
    await closeKeyboard(t);
    await tap(t, find.byKey(const Key('taskAssigneeField')));
    await tap(t, find.textContaining('Priya Nair').last);
    await tap(t, find.byKey(const Key('taskDueButton')));
    await tap(t, find.text('OK'));
    await shot(t, 'owner_new_task_filled');
    await tap(t, find.byKey(const Key('saveTaskButton')));
    await waitFor(t, find.text(taskTitle));
    await shot(t, 'owner_package_with_new_task');
    var task = await e2eTask();
    expect(task.status, TaskStatus.todo);
    step('Owner: created task "$taskTitle" for Priya Nair');

    // Edit the task (CRUD update) and request a status (OM-UC9).
    await tap(t, find.text(taskTitle));
    await waitFor(t, find.byKey(const Key('taskMenu')));
    await tap(t, find.byKey(const Key('taskMenu')));
    await tap(t, find.text('Edit task'));
    await enter(t, find.byKey(const Key('taskDescriptionField')), 'Square post announcing the studio opening. Use the orange logo.');
    await closeKeyboard(t);
    await tap(t, find.byKey(const Key('saveTaskButton')));
    await waitFor(t, find.byKey(const Key('requestStatusButton')));
    await tap(t, find.byKey(const Key('requestStatusButton')));
    await shot(t, 'owner_task_detail');
    step('Owner: edited the task and requested a status update');
    await logout(t);

    // ---------------------------------------------------------- STAFF (writer)
    await login(t, writerEmail);
    await waitFor(t, find.textContaining('Do first'));
    task = await e2eTask();
    await scrollTo(t, find.byKey(Key('task_${task.id}')));
    await shot(t, 'staff_my_tasks_new_task');
    await tap(t, find.byKey(const Key('alertsBell')));
    await waitFor(t, find.text('New task: $taskTitle'));
    await waitFor(t, find.text('Status update requested: $taskTitle'));
    await shot(t, 'staff_alerts_new_task_and_status_request');
    await back(t);
    step('Staff: new task and status request arrived as alerts');

    await scrollTo(t, find.byKey(Key('task_${task.id}')));
    await tap(t, find.byKey(Key('task_${task.id}')));
    await tap(t, find.byKey(const Key('startButton')));
    await waitGone(t, find.byKey(const Key('startButton')));
    expect((await e2eTask()).status, TaskStatus.inProgress);
    step('Staff: started work (In progress)');

    // Upload version 1 (binary data in Firestore). The phone's file picker
    // cannot be driven by a test, so the same repository call is made directly.
    await services.files.uploadVersion(
        task: await e2eTask(), uploader: await me(), fileName: 'e2e_post_v1.jpg', bytes: await sampleImage('glow_intro.jpg'), mimeType: 'image/jpeg', note: 'First draft');
    await waitFor(t, find.text('e2e_post_v1.jpg'));
    step('Staff: uploaded version 1 (image stored in Firestore)');

    await tap(t, find.byKey(const Key('statusButton')));
    await dialogText(t, 'Draft 1 is uploaded, sending to the client today.');
    await tap(t, find.byKey(const Key('handOverButton')));
    await tap(t, find.text('Nurul Aina'));
    await dialogText(t, 'Please check the logo colours.');
    step('Staff: sent a status update and handed the task to Nurul Aina');

    await scrollTo(t, find.byKey(const Key('commentField')));
    await enter(t, find.byKey(const Key('commentField')), 'Hi! Draft 1 is ready for you.');
    await tap(t, find.byKey(const Key('sendCommentButton')));
    await waitFor(t, find.text('Hi! Draft 1 is ready for you.'));
    await closeKeyboard(t);

    await tap(t, find.byKey(const Key('submitButton')));
    await tap(t, find.byKey(const Key('confirmButton')));
    await waitGone(t, find.byKey(const Key('submitButton')));
    expect((await e2eTask()).status, TaskStatus.awaitingApproval);
    await shot(t, 'staff_task_detail_sent_for_approval');
    step('Staff: commented and sent version 1 for approval');
    await back(t);

    // Flag overload (ST-UC8).
    await tab(t, 'My week');
    await tap(t, find.byKey(const Key('flagOverloadButton')));
    await dialogText(t, 'E2E check: two launches this week.');
    await shot(t, 'staff_my_week');
    step('Staff: flagged overload to the owner');
    await logout(t);

    // ---------------------------------------------------------- STAFF (designer)
    await login(t, designerEmail);
    await tab(t, 'Handovers');
    final handover = (await services.store.getCollection(Collections.handovers, whereField: 'taskId', isEqualTo: task.id)).single;
    await scrollTo(t, find.byKey(Key('confirm_${handover.id}')));
    await shot(t, 'designer_handover_to_confirm');
    await tap(t, find.byKey(Key('confirm_${handover.id}')));
    await waitGone(t, find.byKey(Key('confirm_${handover.id}')));
    step('Staff (designer): confirmed the handover');
    await logout(t);

    // ---------------------------------------------------------- CLIENT
    await login(t, clientEmail);
    await waitFor(t, find.text(clientCompany));
    await shot(t, 'client_my_package');
    await tap(t, find.byKey(const Key('alertsBell')));
    await waitFor(t, find.text('Please review: $taskTitle'));
    await shot(t, 'client_alerts');
    await back(t);
    step('Client: sees only their package and got the review alert');

    await tap(t, find.byKey(Key('deliverable_${task.id}')));
    await waitFor(t, find.byKey(const Key('approveButton')));
    await shot(t, 'client_deliverable_waiting');
    await scrollTo(t, find.text('Hi! Draft 1 is ready for you.'));
    await shot(t, 'client_sees_staff_comment');

    // Change request needs a reason (FR17), then is saved (CL-UC5).
    await tap(t, find.byKey(const Key('requestChangesButton')));
    await tap(t, find.byKey(const Key('dialogConfirm')));
    await waitFor(t, find.text('Please write something first.'));
    await dialogText(t, 'Please make the logo bigger.');
    await waitGone(t, find.byKey(const Key('approveButton')));
    expect((await e2eTask()).status, TaskStatus.changesRequested);
    step('Client: requested changes (reason required)');

    await scrollTo(t, find.byKey(const Key('commentField')));
    await enter(t, find.byKey(const Key('commentField')), 'Also add our opening date.');
    await tap(t, find.byKey(const Key('sendCommentButton')));
    await waitFor(t, find.text('Also add our opening date.'));
    await closeKeyboard(t);
    await waitFor(t, find.textContaining('Not seen yet'));
    await shot(t, 'client_changes_requested_and_comment');
    step('Client: comment shows "Not seen yet"');

    // Isolation: this client cannot read another client's data (rules).
    Object? denied;
    try {
      await services.packages.getById('pkg_kopikita');
    } catch (e) {
      denied = e;
    }
    expect(denied, isNotNull, reason: "client must not read Kopi Kita's package");
    expect('$denied', contains('permission'));
    denied = null;
    try {
      await services.store.getCollection(Collections.packages);
    } catch (e) {
      denied = e;
    }
    expect(denied, isNotNull, reason: 'client must not list all packages');
    step('Security rules: client is denied other clients\' packages');
    await back(t);
    await logout(t);

    // ---------------------------------------------------------- STAFF: version 2
    await login(t, writerEmail);
    task = await e2eTask();
    await scrollTo(t, find.byKey(Key('task_${task.id}')));
    await tap(t, find.byKey(Key('task_${task.id}')));
    await scrollTo(t, find.text('Also add our opening date.'));
    await services.files.uploadVersion(
        task: await e2eTask(), uploader: await me(), fileName: 'e2e_post_v2.jpg', bytes: await sampleImage('glow_routine.jpg'), mimeType: 'image/jpeg', note: 'Bigger logo, date added');
    await scrollTo(t, find.text('e2e_post_v2.jpg'));
    await tap(t, find.byKey(const Key('submitButton')));
    await tap(t, find.byKey(const Key('confirmButton')));
    await waitGone(t, find.byKey(const Key('submitButton')));
    expect((await e2eTask()).latestVersion, 2);
    await shot(t, 'staff_version2_sent');
    step('Staff: uploaded version 2 and sent it again; client comments marked seen');
    await back(t);
    await logout(t);

    // ---------------------------------------------------------- CLIENT: approve
    await login(t, clientEmail);
    await tap(t, find.byKey(Key('deliverable_${task.id}')));
    await waitFor(t, find.text('Version 2 is waiting for your decision'));
    await scrollTo(t, find.textContaining('Seen by agency'));
    await tap(t, find.byKey(const Key('approveButton')));
    await dialogText(t, 'Perfect, post it!');
    await waitGone(t, find.byKey(const Key('approveButton')));
    final approved = await e2eTask();
    expect(approved.status, TaskStatus.approved);
    expect(approved.approvedVersion, 2);
    await shot(t, 'client_approved');
    step('Client: approved version 2 (comment was marked seen by agency)');
    await back(t);
    await tab(t, 'Library');
    await waitFor(t, find.text(taskTitle));
    await shot(t, 'client_library');
    await tab(t, 'Calendar');
    await shot(t, 'client_calendar');
    await tap(t, find.byKey(const Key('alertsBell')));
    await tap(t, find.text('Mark all read'));
    step('Client: approved item is in the Library; calendar opens; alerts marked read');
    await back(t);
    await logout(t);

    // ---------------------------------------------------------- OWNER: results
    await login(t, ownerEmail);
    await scrollTo(t, find.byKey(Key('package_${pkg.id}')));
    await tap(t, find.byKey(Key('package_${pkg.id}')));
    await scrollTo(t, find.textContaining('$taskTitle · v2'));
    await shot(t, 'owner_approval_log');
    step('Owner: approval log shows "$taskTitle · v2" with name and time');
    await back(t);
    await tap(t, find.byKey(const Key('alertsBell')));
    await waitFor(t, find.textContaining('is overloaded'));
    await waitFor(t, find.textContaining('Status from Priya Nair'));
    await shot(t, 'owner_alerts');
    await back(t);
    step('Owner: received the overload flag and the status update');
    await tab(t, 'Workload');
    await waitFor(t, find.text('Team workload'));
    await shot(t, 'owner_workload');
    await tab(t, 'Calendar');
    await shot(t, 'owner_calendar');
    await tab(t, 'Dashboard');

    // Persistence: a brand-new connection reads the same data back.
    final fresh = AppServices.firebase(useCloudStorage: false);
    expect((await fresh.tasks.getById(task.id))!.status, TaskStatus.approved);
    step('Persistence: data read back from Firestore by a new connection');

    // Delete the task, then the package, through the UI (CRUD delete).
    await scrollTo(t, find.byKey(Key('package_${pkg.id}')));
    await tap(t, find.byKey(Key('package_${pkg.id}')));
    await tap(t, find.text(taskTitle));
    await tap(t, find.byKey(const Key('taskMenu')));
    await tap(t, find.text('Delete task'));
    await tap(t, find.byKey(const Key('confirmButton')));
    await eventually(() async => await services.tasks.getById(task.id) == null, 'task deleted');
    await eventually(() async => (await services.store.getCollection(Collections.approvals, whereField: 'taskId', isEqualTo: task.id)).isEmpty, 'approvals deleted');
    while (find.byType(BackButton).evaluate().isNotEmpty && find.byKey(const Key('packageMenu')).evaluate().isEmpty) {
      await back(t);
    }
    await tap(t, find.byKey(const Key('packageMenu')));
    await tap(t, find.text('Delete package'));
    await tap(t, find.byKey(const Key('confirmButton')));
    await eventually(() async => await services.packages.getById(pkg.id) == null, 'package deleted');
    await waitGone(t, find.text(clientCompany));
    await shot(t, 'owner_dashboard_after_delete');
    step('Owner: deleted the task (with its records) and the package');
    await logout(t);

    await t.pumpWidget(const SizedBox()); // close the app before clean-up sign-ins
    await settle(t);
    await cleanUp(clientUid);
    step('Clean-up: E2E alerts and the E2E client profile removed');

    // ignore: avoid_print
    print('E2E SUMMARY\n${log.map((l) => 'PASS  $l').join('\n')}');
    binding.reportData = {'steps': log};
  }

  testWidgets('every role on real Firebase: create, deliver, review, approve, isolate, clean up',
      (t) async {
    try {
      await runFlow(t);
    } catch (e) {
      try {
        await shot(t, 'FAILED_here');
      } catch (_) {}
      // Web prints go to the browser console, so put the progress in the failure.
      throw TestFailure('$e\nSteps passed before the failure:\n${log.join('\n')}\nLast Firebase calls:\n${traces.reversed.take(6).toList().reversed.join('\n')}');
    }
  }, timeout: const Timeout(Duration(minutes: 20)));
}
