// End-to-end tests on a real device or emulator:
//   flutter test integration_test/app_test.dart
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:spacesharks_app/app.dart';
import 'package:spacesharks_app/core/models/models.dart';
import 'package:spacesharks_app/core/services/app_services.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  Future<void> login(WidgetTester tester, String email) async {
    await tester.enterText(find.byKey(const Key('emailField')), email);
    await tester.enterText(find.byKey(const Key('passwordField')), 'password123');
    // Close the on-screen keyboard so it does not cover the button.
    FocusManager.instance.primaryFocus?.unfocus();
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const Key('loginButton')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('loginButton')));
    await tester.pumpAndSettle();
  }

  /// Scrolls the current page until [finder] is visible, then taps it.
  Future<void> scrollTap(WidgetTester tester, Finder finder) async {
    await tester.scrollUntilVisible(finder, 200, scrollable: find.byType(Scrollable).first);
    await tester.pumpAndSettle();
    await tester.tap(finder);
    await tester.pumpAndSettle();
  }

  Future<void> logout(WidgetTester tester) async {
    await tester.tap(find.byKey(const Key('accountMenu')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Sign out'));
    await tester.pumpAndSettle();
  }

  testWidgets('every role can sign in and reach its home', (tester) async {
    final services = await AppServices.demo();
    await tester.pumpWidget(SpacesharksApp(services: services));
    await tester.pumpAndSettle();

    await login(tester, 'owner@spacesharks.test');
    expect(find.text('Client packages'), findsOneWidget);
    await logout(tester);

    await login(tester, 'editor@spacesharks.test');
    expect(find.textContaining('Do first'), findsOneWidget);
    await logout(tester);

    await login(tester, 'client@glowskin.test');
    expect(find.text('Glow Skin Studio'), findsOneWidget);
    await tester.tap(find.byKey(const Key('alertsBell')));
    await tester.pumpAndSettle();
    expect(find.text('Please review: Brand introduction post'), findsOneWidget);
  });

  testWidgets('full workflow: owner assigns -> staff delivers -> client approves -> owner sees it delivered',
      (tester) async {
    final services = await AppServices.demo();
    await tester.pumpWidget(SpacesharksApp(services: services));
    await tester.pumpAndSettle();

    // 1. Owner creates a task for Kopi Kita, assigned to the copywriter.
    //    (Created through the repository so the test does not depend on the
    //    date picker; the form itself is covered by widget tests.)
    final owner = (await services.users.getById('owner'))!;
    final writer = (await services.users.getById('writer'))!;
    final now = DateTime.now();
    final taskId = await services.tasks.create(ContentTask(
      id: '', packageId: 'pkg_kopikita', clientName: 'Kopi Kita Cafe', title: 'Halloween latte post',
      contentType: ContentType.post, assigneeId: writer.id, assigneeName: writer.name,
      dueDate: now.add(const Duration(days: 2)), priority: TaskPriority.high, status: TaskStatus.todo,
      createdById: owner.id, createdAt: now, updatedAt: now,
    ));

    // 2. Staff sees it, starts work, uploads a version and sends it for approval.
    await login(tester, 'writer@spacesharks.test');
    await scrollTap(tester, find.byKey(Key('task_$taskId')));
    await tester.tap(find.byKey(const Key('startButton')));
    await tester.pumpAndSettle();
    expect((await services.tasks.getById(taskId))!.status, TaskStatus.inProgress);
    final task = (await services.tasks.getById(taskId))!;
    await services.files.uploadVersion(
        task: task, uploader: writer, fileName: 'halloween.txt',
        bytes: Uint8List.fromList('Spooky season is here!'.codeUnits), mimeType: 'text/plain');
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('submitButton')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('confirmButton')));
    await tester.pumpAndSettle();
    expect((await services.tasks.getById(taskId))!.status, TaskStatus.awaitingApproval);
    await tester.pageBack();
    await tester.pumpAndSettle();
    await logout(tester);

    // 3. Client approves it.
    await login(tester, 'client@kopikita.test');
    await scrollTap(tester, find.byKey(Key('deliverable_$taskId')));
    await tester.tap(find.byKey(const Key('approveButton')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('dialogConfirm')));
    await tester.pumpAndSettle();
    await tester.pageBack();
    await tester.pumpAndSettle();
    await logout(tester);

    // 4. Owner sees it delivered with a timestamped approval.
    final approved = (await services.tasks.getById(taskId))!;
    expect(approved.status, TaskStatus.approved);
    expect(approved.approvedVersion, 1);
    await login(tester, 'owner@spacesharks.test');
    await scrollTap(tester, find.byKey(const Key('package_pkg_kopikita')));
    final logEntry = find.textContaining('Halloween latte post · v1');
    await tester.scrollUntilVisible(logEntry, 300, scrollable: find.byType(Scrollable).first);
    expect(logEntry, findsOneWidget);
  });
}
