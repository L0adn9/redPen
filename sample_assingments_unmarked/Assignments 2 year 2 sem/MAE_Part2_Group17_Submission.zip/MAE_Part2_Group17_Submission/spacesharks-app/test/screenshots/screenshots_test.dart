// Generates screenshots of every screen for the report and user manual.
// Not part of the normal test run. Run with:
//   flutter test --tags screenshots --update-goldens test/screenshots
// PNGs are written to test/screenshots/goldens/.
@Tags(['screenshots'])
library;

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/app.dart';
import 'package:spacesharks_app/core/data/holiday_service.dart';
import 'package:spacesharks_app/core/models/models.dart';
import 'package:spacesharks_app/core/services/app_services.dart';

Future<void> _loadFonts() async {
  final manifest = jsonDecode(await rootBundle.loadString('FontManifest.json')) as List<dynamic>;
  for (final family in manifest.cast<Map<String, dynamic>>()) {
    final loader = FontLoader(family['family'] as String);
    for (final font in (family['fonts'] as List).cast<Map<String, dynamic>>()) {
      loader.addFont(rootBundle.load(font['asset'] as String));
    }
    await loader.load();
  }
}

final _holidays = HolidayService.fixed([
  Holiday(date: DateTime(2026, 11, 8), name: 'Deepavali', localName: 'Deepavali'),
  Holiday(date: DateTime(2026, 12, 25), name: 'Christmas Day', localName: 'Hari Krismas'),
]);

Future<AppServices> _services() async {
  final services = await AppServices.demo(holidays: _holidays);
  // One post scheduled on a public holiday, so the calendar shows its warning.
  final now = DateTime.now();
  await services.tasks.create(ContentTask(
    id: '', packageId: 'pkg_kopikita', clientName: 'Kopi Kita Cafe', title: 'Deepavali greeting post',
    contentType: ContentType.post, assigneeId: 'designer', assigneeName: 'Nurul Aina',
    dueDate: DateTime(2026, 11, 6, 17), publishDate: DateTime(2026, 11, 8, 10),
    priority: TaskPriority.medium, status: TaskStatus.todo, createdById: 'owner', createdAt: now, updatedAt: now,
  ));
  return services;
}

void _size(WidgetTester tester, double width, double height, {double ratio = 2}) {
  tester.view.physicalSize = Size(width * ratio, height * ratio);
  tester.view.devicePixelRatio = ratio;
}

Future<void> _settle(WidgetTester tester) async {
  await tester.pumpAndSettle();
  await tester.runAsync(() async {
    for (final element in find.byType(Image).evaluate()) {
      final image = element.widget as Image;
      await precacheImage(image.image, element);
    }
    await Future<void>.delayed(const Duration(milliseconds: 50));
  });
  await tester.pumpAndSettle();
}

Future<void> _shot(WidgetTester tester, String name) async {
  await _settle(tester);
  await expectLater(find.byType(MaterialApp), matchesGoldenFile('goldens/$name.png'));
}

Future<void> _start(WidgetTester tester, {double height = 844, double width = 390, double ratio = 2}) async {
  _size(tester, width, height, ratio: ratio);
  addTearDown(tester.view.reset);
  debugDisableShadows = false;
  await tester.runAsync(_loadFonts);
  final services = await tester.runAsync(_services);
  await tester.pumpWidget(SpacesharksApp(services: services!));
  await _settle(tester);
}

Future<void> _login(WidgetTester tester, String email) async {
  await tester.enterText(find.byKey(const Key('emailField')), email);
  await tester.enterText(find.byKey(const Key('passwordField')), 'password123');
  await tester.tap(find.byKey(const Key('loginButton')));
  await _settle(tester);
}

Future<void> _tab(WidgetTester tester, String label) async {
  await tester.tap(find.descendant(of: find.byType(NavigationBar), matching: find.text(label)));
  await _settle(tester);
}

Future<void> _tapText(WidgetTester tester, String text) async {
  final finder = find.text(text).first;
  await tester.scrollUntilVisible(finder, 200, scrollable: find.byType(Scrollable).first);
  await tester.pumpAndSettle();
  await tester.tap(finder);
  await _settle(tester);
}

Future<void> _back(WidgetTester tester) async {
  await tester.pageBack();
  await _settle(tester);
}

/// Like testWidgets, but draws real shadows and restores the setting at the end.
void shotTest(String name, Future<void> Function(WidgetTester tester) body) {
  testWidgets(name, (tester) async {
    try {
      await body(tester);
    } finally {
      debugDisableShadows = true;
    }
  });
}

void main() {
  shotTest('login', (tester) async {
    await _start(tester);
    await _shot(tester, '01_login');
    await tester.tap(find.byKey(const Key('loginButton')));
    await tester.pump();
    await _shot(tester, '02_login_validation');
  });

  shotTest('owner', (tester) async {
    await _start(tester, height: 1500);
    await _login(tester, 'owner@spacesharks.test');
    await _shot(tester, '03_owner_dashboard');

    await tester.tap(find.byKey(const Key('package_pkg_kopikita')));
    await _settle(tester);
    await _shot(tester, '04_owner_package_detail');

    await _tapText(tester, 'Barista day reel');
    await _shot(tester, '05_owner_task_detail');
    await _back(tester);

    await tester.tap(find.byKey(const Key('newTaskButton')));
    await _settle(tester);
    await _shot(tester, '06_owner_new_task_form');
    await tester.tap(find.byKey(const Key('saveTaskButton')));
    await _settle(tester);
    await _shot(tester, '07_owner_new_task_validation');
    await _back(tester);
    await _back(tester);

    await tester.tap(find.byKey(const Key('newPackageButton')));
    await _settle(tester);
    await _shot(tester, '08_owner_new_package_form');
    await _back(tester);

    await _tab(tester, 'Workload');
    await tester.tap(find.byKey(const Key('staff_designer')));
    await _settle(tester);
    await _shot(tester, '09_owner_workload');

    await _tab(tester, 'Calendar');
    await tester.tap(find.byKey(const Key('nextWeek')));
    await _settle(tester);
    await _shot(tester, '10_owner_calendar');

    await tester.tap(find.byKey(const Key('alertsBell')));
    await _settle(tester);
    await _shot(tester, '11_owner_alerts');
  });

  shotTest('staff', (tester) async {
    await _start(tester, height: 1400);
    await _login(tester, 'designer@spacesharks.test');
    await _shot(tester, '12_staff_my_tasks');

    await tester.tap(find.byKey(const Key('task_task_1')));
    await _settle(tester);
    await _shot(tester, '13_staff_task_detail');

    await tester.tap(find.byKey(const Key('statusButton')));
    await _settle(tester);
    await _shot(tester, '14_staff_send_status_dialog');
    await tester.tap(find.text('Cancel'));
    await _settle(tester);
    await _back(tester);

    await _tab(tester, 'My week');
    await tester.tap(find.byKey(const Key('nextWeek')));
    await _settle(tester);
    await _shot(tester, '15_staff_my_week');

    await tester.tap(find.byKey(const Key('flagOverloadButton')));
    await _settle(tester);
    await _shot(tester, '16_staff_flag_overload');
    await tester.tap(find.text('Cancel'));
    await _settle(tester);
  });

  shotTest('staff handovers', (tester) async {
    await _start(tester, height: 1100);
    await _login(tester, 'editor@spacesharks.test');
    await _tab(tester, 'Handovers');
    await _shot(tester, '17_staff_handovers');
  });

  shotTest('client', (tester) async {
    await _start(tester, height: 1400);
    await _login(tester, 'client@kopikita.test');
    await _shot(tester, '18_client_package');

    await tester.tap(find.byKey(const Key('deliverable_task_2')));
    await _settle(tester);
    await _shot(tester, '19_client_deliverable_approval');

    await tester.tap(find.byKey(const Key('requestChangesButton')));
    await _settle(tester);
    await tester.tap(find.byKey(const Key('dialogConfirm')));
    await _settle(tester);
    await _shot(tester, '20_client_request_changes_validation');
    await tester.tap(find.text('Cancel'));
    await _settle(tester);
    await _back(tester);

    await _tab(tester, 'Calendar');
    await tester.tap(find.byKey(const Key('nextWeek')));
    await _settle(tester);
    await _shot(tester, '21_client_calendar');

    await _tab(tester, 'Library');
    await _shot(tester, '22_client_library');

    await tester.tap(find.byKey(const Key('alertsBell')));
    await _settle(tester);
    await _shot(tester, '23_client_alerts');
  });

  shotTest('tablet', (tester) async {
    await _start(tester, width: 1280, height: 860, ratio: 1.5);
    await _login(tester, 'owner@spacesharks.test');
    await _shot(tester, '24_tablet_owner_dashboard');
  });
}
