// Staff tests. Owned by: Muntasir. Add a file per screen you build.
import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/models/models.dart';
import 'package:spacesharks_app/features/staff/tasks/my_tasks_view_model.dart';

import '../helpers/test_helpers.dart';

void main() {
  test('Do first holds overdue and due-soon work, most urgent first', () async {
    final services = await demoServices();
    final designer = (await services.users.getById('designer'))!;
    final vm = MyTasksViewModel(services, designer, clock: () => testNow)..start();
    await settle();

    expect(vm.doFirst.map((t) => t.id).toList(), ['task_1', 'task_6']);
    expect(vm.later.map((t) => t.id).toList(), ['task_10']);
    expect(vm.done.length, 8); // 2 current + 6 delivered earlier this month
    expect(vm.clients, ['Glow Skin Studio', 'Kopi Kita Cafe', 'UrbanFit Gym']);
    vm.dispose();
  });

  test('client filter narrows the list', () async {
    final services = await demoServices();
    final designer = (await services.users.getById('designer'))!;
    final vm = MyTasksViewModel(services, designer, clock: () => testNow)..start();
    await settle();
    vm.setClientFilter('UrbanFit Gym');
    expect(vm.doFirst, isEmpty);
    expect(vm.later.single.id, 'task_10');
    vm.dispose();
  });

  test('compareUrgency: overdue > changes requested > due soon > priority', () {
    ContentTask t(String id, int dueHours, TaskPriority p, [TaskStatus s = TaskStatus.todo]) => ContentTask(
          id: id, packageId: 'p', clientName: 'C', title: id, contentType: ContentType.post,
          assigneeId: 'a', assigneeName: 'A', dueDate: testNow.add(Duration(hours: dueHours)),
          priority: p, status: s, createdAt: testNow, updatedAt: testNow);
    final tasks = [
      t('later-high', 100, TaskPriority.high),
      t('soon-low', 10, TaskPriority.low),
      t('changes', 90, TaskPriority.low, TaskStatus.changesRequested),
      t('overdue', -5, TaskPriority.low),
      t('later-low', 100, TaskPriority.low),
    ]..sort((a, b) => compareUrgency(a, b, testNow));
    expect(tasks.map((x) => x.id).toList(),
        ['overdue', 'changes', 'soon-low', 'later-high', 'later-low']);
  });
}
