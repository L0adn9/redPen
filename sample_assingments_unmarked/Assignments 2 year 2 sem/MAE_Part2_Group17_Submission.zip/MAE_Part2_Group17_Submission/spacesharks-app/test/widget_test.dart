// Smoke test. (This file also stops `flutter create .` from adding its
// default counter-app test, which would not compile against this app.)
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers/test_helpers.dart';

void main() {
  testWidgets('app starts on the login screen', (tester) async {
    final services = await demoServices(now: DateTime.now());
    await pumpApp(tester, services);
    expect(find.text('SPACESHARKS'), findsOneWidget);
    expect(find.byKey(const Key('loginButton')), findsOneWidget);
  });
}
