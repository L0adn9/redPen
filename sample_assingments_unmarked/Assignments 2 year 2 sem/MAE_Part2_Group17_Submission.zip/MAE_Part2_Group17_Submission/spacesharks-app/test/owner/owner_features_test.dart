import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/models/models.dart';
import 'package:spacesharks_app/core/services/app_services.dart';
import 'package:spacesharks_app/features/owner/dashboard/owner_dashboard_view_model.dart';
import 'package:spacesharks_app/features/owner/packages/package_detail_view_model.dart';
import 'package:spacesharks_app/features/owner/tasks/task_form_view_model.dart';
import 'package:spacesharks_app/features/owner/workload/workload_view_model.dart';

import '../helpers/test_helpers.dart';

void main() {
  late AppServices services;
  late AppUser owner;
  setUp(() async {
    services = await demoServices();
    owner = (await services.users.getById('owner'))!;
  });

  group('Task form (create / update)', () {
    test('lists staff with fewest open tasks first', () async {
      final vm = TaskFormViewModel(services, owner, packageId: 'pkg_kopikita');
      await vm.load();
      final counts = vm.staff.map((s) => s.openTasks).toList();
      expect(counts, [...counts]..sort());
      expect(vm.package!.clientName, 'Kopi Kita Cafe');
    });

    test('publish date before due date is rejected', () {
      expect(TaskFormViewModel.checkDates(due: null, publish: null), isNotNull);
      expect(TaskFormViewModel.checkDates(due: DateTime(2026, 11, 5), publish: DateTime(2026, 11, 4)), isNotNull);
      expect(TaskFormViewModel.checkDates(due: DateTime(2026, 11, 5), publish: DateTime(2026, 11, 5, 10)), isNull);
    });

    test('a task due today after 5 PM is due at the end of the day, not already overdue', () {
      final evening = DateTime(2026, 10, 28, 18, 30);
      expect(TaskFormViewModel.dueTimeFor(DateTime(2026, 10, 28), evening), DateTime(2026, 10, 28, 23, 59));
      expect(TaskFormViewModel.dueTimeFor(DateTime(2026, 10, 29), evening), DateTime(2026, 10, 29, 17));
    });

    test('creating a task saves it and alerts the assignee', () async {
      final vm = TaskFormViewModel(services, owner, packageId: 'pkg_glowskin');
      await vm.load();
      final writer = vm.staff.firstWhere((s) => s.user.id == 'writer').user;
      final ok = await vm.save(
        title: 'Year-end promo caption',
        description: 'Warm tone',
        type: ContentType.caption,
        assignee: writer,
        priority: TaskPriority.high,
        due: testNow.add(const Duration(days: 3)),
      );
      expect(ok, isTrue);
      final tasks = await services.tasks.watchForPackage('pkg_glowskin').first;
      final created = tasks.firstWhere((t) => t.title == 'Year-end promo caption');
      expect(created.status, TaskStatus.todo);
      expect(created.clientName, 'Glow Skin Studio');
      final alerts = await services.alerts.watchForUser('writer').first;
      expect(alerts.any((a) => a.taskId == created.id && a.type == AlertType.newTask), isTrue);
    });

    test('reassigning a task alerts the new person', () async {
      final task = (await services.tasks.getById('task_10'))!;
      final vm = TaskFormViewModel(services, owner, packageId: task.packageId, existing: task);
      await vm.load();
      final editor = vm.staff.firstWhere((s) => s.user.id == 'editor').user;
      await vm.save(
          title: task.title, description: task.description, type: task.contentType,
          assignee: editor, priority: task.priority, due: task.dueDate);
      expect((await services.tasks.getById('task_10'))!.assigneeName, 'Daniel Lim');
      final alerts = await services.alerts.watchForUser('editor').first;
      expect(alerts.any((a) => a.taskId == 'task_10' && a.title.startsWith('Task reassigned')), isTrue);
    });
  });

  group('Package detail', () {
    test('changing the phase is saved', () async {
      final vm = PackageDetailViewModel(services, 'pkg_glowskin', clock: () => testNow)..start();
      await settle();
      await vm.setPhase(PackagePhase.buildUp);
      await settle();
      expect(vm.package!.phase, PackagePhase.buildUp);
      vm.dispose();
    });

    test('filters tasks by status and shows the approval log', () async {
      final vm = PackageDetailViewModel(services, 'pkg_kopikita', clock: () => testNow)..start();
      await settle();
      vm.setStatusFilter(TaskStatus.awaitingApproval);
      expect(vm.tasks.map((t) => t.id), ['task_2']);
      expect(vm.approvals, isNotEmpty);
      expect(vm.taskTitle('task_5'), 'Customer story');
      vm.dispose();
    });

    test('deleting a package removes its tasks', () async {
      final vm = PackageDetailViewModel(services, 'pkg_urbanfit')..start();
      await settle();
      await vm.deletePackage();
      expect(await services.packages.getById('pkg_urbanfit'), isNull);
      expect(await services.tasks.watchForPackage('pkg_urbanfit').first, isEmpty);
      vm.dispose();
    });
  });

  group('Package health (OM-UC8)', () {
    ClientPackage pkg({int promised = 10, DateTime? start}) => ClientPackage(
        id: 'p', clientName: 'C', clientUserId: 'c', packageName: 'P', phase: PackagePhase.buildUp,
        managerId: 'o', managerName: 'O', promisedItems: promised, startDate: start ?? DateTime(2026, 1, 1));
    ContentTask t(TaskStatus s, {int dueOffsetDays = 3}) => ContentTask(
        id: '${s.name}$dueOffsetDays', packageId: 'p', clientName: 'C', title: 'T', contentType: ContentType.post,
        assigneeId: 'a', assigneeName: 'A', dueDate: DateTime(2026, 10, 15).add(Duration(days: dueOffsetDays)),
        priority: TaskPriority.medium, status: s, createdAt: DateTime(2026), updatedAt: DateTime(2026));
    final midMonth = DateTime(2026, 10, 15, 12); // about half the month gone

    test('on track when delivery keeps up with the month', () {
      final s = PackageSummary(package: pkg(), tasks: [for (var i = 0; i < 5; i++) t(TaskStatus.approved, dueOffsetDays: -i - 1)], now: midMonth);
      expect(s.health, PackageHealth.onTrack);
    });

    test('at risk when a little behind', () {
      final s = PackageSummary(package: pkg(), tasks: [for (var i = 0; i < 4; i++) t(TaskStatus.approved, dueOffsetDays: -i - 1)], now: midMonth);
      expect(s.health, PackageHealth.atRisk);
    });

    test('a package created today is on track, not behind', () {
      final s = PackageSummary(package: pkg(start: midMonth), tasks: const [], now: midMonth);
      expect(s.health, PackageHealth.onTrack);
    });

    test('behind when two or more items are overdue', () {
      final s = PackageSummary(package: pkg(), tasks: [
        for (var i = 0; i < 6; i++) t(TaskStatus.approved, dueOffsetDays: -i - 1),
        t(TaskStatus.inProgress, dueOffsetDays: -2),
        t(TaskStatus.todo, dueOffsetDays: -3),
      ], now: midMonth);
      expect(s.health, PackageHealth.behind);
    });
  });

  group('Workload (OM-UC4, OM-UC7)', () {
    test('capacity labels follow open and overdue counts', () {
      ContentTask open(int dueDays) => ContentTask(
          id: '$dueDays', packageId: 'p', clientName: 'C', title: 'T', contentType: ContentType.post,
          assigneeId: 'a', assigneeName: 'A', dueDate: testNow.add(Duration(days: dueDays)),
          priority: TaskPriority.medium, status: TaskStatus.inProgress, createdAt: testNow, updatedAt: testNow);
      const u = AppUser(id: 'a', name: 'A', email: 'a@a.a', role: UserRole.staff);
      expect(StaffLoad(user: u, openTasks: [open(2)], now: testNow).capacity, Capacity.hasCapacity);
      expect(StaffLoad(user: u, openTasks: [open(2), open(3), open(4)], now: testNow).capacity, Capacity.busy);
      expect(StaffLoad(user: u, openTasks: [open(-1), open(-2)], now: testNow).capacity, Capacity.overloaded);
      expect(StaffLoad(user: u, openTasks: [for (var i = 1; i <= 5; i++) open(i)], now: testNow).capacity, Capacity.overloaded);
    });

    test('lists every staff member and pending handovers', () async {
      final vm = WorkloadViewModel(services, clock: () => testNow)..start();
      await settle();
      expect(vm.isLoading, isFalse);
      expect(vm.loads.length, 3);
      expect(vm.pendingHandovers.map((h) => h.id), ['hand_2']);
      vm.dispose();
    });
  });

  test('staff overload flag reaches the owner', () async {
    final staff = (await services.users.getById('editor'))!;
    await services.alerts.flagOverload(staff: staff, openTasks: 6, reason: 'Three reels due Friday');
    final alerts = await services.alerts.watchForUser('owner').first;
    expect(alerts.any((a) => a.type == AlertType.overload && a.body.contains('Three reels')), isTrue);
  });
}
