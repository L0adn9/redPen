// Owner tests. Owned by: Kaung. Add a file per screen you build.
import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/models/models.dart';
import 'package:spacesharks_app/features/owner/dashboard/owner_dashboard_view_model.dart';

import '../helpers/test_helpers.dart';

void main() {
  test('dashboard counts active, overdue and awaiting-approval items', () async {
    final services = await demoServices();
    final vm = OwnerDashboardViewModel(services, clock: () => testNow)..start();
    await settle();

    expect(vm.isLoading, isFalse);
    expect(vm.activePackages.length, 3);
    expect(vm.overdueTasks.map((t) => t.id), containsAll(['task_1', 'task_8']));
    expect(vm.overdueTasks.length, 2);
    expect(vm.awaitingApproval.length, 2);

    final kopi = vm.summaries.firstWhere((s) => s.package.id == 'pkg_kopikita');
    expect(kopi.delivered, 7);
    expect(kopi.overdue, 1);
    expect(kopi.deliveryProgress, closeTo(7 / 12, 0.001));
    vm.dispose();
  });

  test('dashboard updates live when a client approves', () async {
    final services = await demoServices();
    final vm = OwnerDashboardViewModel(services, clock: () => testNow)..start();
    await settle();
    final task = (await services.tasks.getById('task_2'))!;
    final client = (await services.users.getById('kopikita'))!;
    await services.feedback.recordDecision(
        task: task, client: client, decision: ApprovalDecision.approved);
    await settle();
    expect(vm.awaitingApproval.length, 1);
    vm.dispose();
  });
}
