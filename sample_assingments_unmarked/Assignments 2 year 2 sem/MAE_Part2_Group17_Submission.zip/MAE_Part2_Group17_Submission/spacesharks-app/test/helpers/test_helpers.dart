import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/app.dart';
import 'package:spacesharks_app/core/data/auth_repository.dart';
import 'package:spacesharks_app/core/services/app_services.dart';

/// A fixed "now" so every test sees the same overdue/upcoming tasks.
/// Seed data is built around this date (12:00, so tasks due "today" at
/// 17:00 are not overdue yet).
final testNow = DateTime(2026, 10, 28, 12);

/// Fresh demo data for one test.
Future<AppServices> demoServices({DateTime? now}) =>
    AppServices.demo(now: now ?? testNow);

/// Lets stream events and async repository calls finish.
Future<void> settle() async {
  for (var i = 0; i < 20; i++) {
    await Future<void>.delayed(Duration.zero);
  }
}

/// Pumps the whole app with demo services.
Future<void> pumpApp(WidgetTester tester, AppServices services) async {
  await tester.pumpWidget(SpacesharksApp(services: services));
  await tester.pumpAndSettle();
}

/// Fills in the login form and signs in.
Future<void> signIn(WidgetTester tester, String email,
    {String password = FakeAuthRepository.demoPassword}) async {
  await tester.enterText(find.byKey(const Key('emailField')), email);
  await tester.enterText(find.byKey(const Key('passwordField')), password);
  await tester.tap(find.byKey(const Key('loginButton')));
  await tester.pumpAndSettle();
}

/// Use a phone-width screen (default test screen is 800x600, a "tablet").
/// It is extra tall so long pages are fully built without scrolling.
void usePhoneSize(WidgetTester tester) {
  tester.view.physicalSize = const Size(1200, 4800);
  tester.view.devicePixelRatio = 3.0;
  addTearDown(tester.view.reset);
}

/// Scrolls the page until [finder] is built and visible, then taps it.
Future<void> scrollAndTap(WidgetTester tester, Finder finder) async {
  await tester.scrollUntilVisible(finder, 200, scrollable: find.byType(Scrollable).first);
  await tester.tap(finder);
  await tester.pumpAndSettle();
}
