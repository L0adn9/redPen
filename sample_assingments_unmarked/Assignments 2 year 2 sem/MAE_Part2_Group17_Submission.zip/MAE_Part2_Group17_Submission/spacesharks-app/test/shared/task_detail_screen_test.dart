// Widget tests for the task detail page (all roles) and the alerts screen.
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/app_scope.dart';
import 'package:spacesharks_app/core/data/doc_store.dart';
import 'package:spacesharks_app/core/models/models.dart';
import 'package:spacesharks_app/core/services/app_services.dart';
import 'package:spacesharks_app/core/services/file_picker_service.dart';
import 'package:spacesharks_app/core/session/session_view_model.dart';
import 'package:spacesharks_app/core/theme/app_theme.dart';
import 'package:spacesharks_app/features/shared/task_detail/task_detail_screen.dart';

import '../helpers/test_helpers.dart';

/// Returns a small PNG instead of opening the phone's file picker.
class FakePicker extends FilePickerService {
  const FakePicker();

  @override
  Future<PickedFile?> pick() async =>
      PickedFile(
          name: 'draft.png',
          bytes: base64Decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='),
          mimeType: 'image/png');
}

void main() {
  late AppServices services;
  setUp(() async => services = await demoServices(now: DateTime.now()));

  Future<void> openTask(WidgetTester tester, String email, String taskId) async {
    usePhoneSize(tester);
    await services.auth.signIn(email: email, password: 'password123');
    final session = SessionViewModel(services.auth);
    addTearDown(session.dispose);
    await tester.pumpWidget(AppScope(
      services: services,
      session: session,
      child: MaterialApp(
        theme: AppTheme.light(),
        home: ListenableBuilder(
          listenable: session,
          builder: (context, _) => session.isReady
              ? TaskDetailScreen(taskId: taskId, filePicker: const FakePicker())
              : const SizedBox(),
        ),
      ),
    ));
    await tester.pumpAndSettle();
  }

  testWidgets('staff upload a new version with a note', (tester) async {
    await openTask(tester, 'designer@spacesharks.test', 'task_1');
    await tester.tap(find.byKey(const Key('uploadButton')));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('dialogTextField')), 'Bigger headline');
    await tester.tap(find.byKey(const Key('dialogConfirm')));
    await tester.pumpAndSettle();
    expect(find.text('Version 2 uploaded.'), findsOneWidget);
    expect((await services.tasks.getById('task_1'))!.latestVersion, 2);
    expect(find.text('draft.png'), findsOneWidget);
  });

  testWidgets('staff send the latest version for approval', (tester) async {
    await openTask(tester, 'designer@spacesharks.test', 'task_1');
    await tester.tap(find.byKey(const Key('submitButton')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('confirmButton')));
    await tester.pumpAndSettle();
    expect((await services.tasks.getById('task_1'))!.status, TaskStatus.awaitingApproval);
    expect(find.byKey(const Key('submitButton')), findsNothing);
  });

  testWidgets('staff hand a task over to a colleague', (tester) async {
    await openTask(tester, 'designer@spacesharks.test', 'task_10');
    await tester.tap(find.byKey(const Key('handOverButton')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Priya Nair'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('dialogTextField')), 'Copy for the schedule graphic');
    await tester.tap(find.byKey(const Key('dialogConfirm')));
    await tester.pumpAndSettle();
    final handovers = await services.store.getCollection(Collections.handovers, whereField: 'taskId', isEqualTo: 'task_10');
    expect(handovers.single.data['toName'], 'Priya Nair');
  });

  testWidgets('staff send a status update to the manager', (tester) async {
    await openTask(tester, 'editor@spacesharks.test', 'task_9');
    await tester.tap(find.byKey(const Key('statusButton')));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('dialogTextField')), 'Colour grading tomorrow');
    await tester.tap(find.byKey(const Key('dialogConfirm')));
    await tester.pumpAndSettle();
    final alerts = await services.alerts.getForUser('owner');
    expect(alerts.any((a) => a.body == 'Colour grading tomorrow'), isTrue);
  });

  testWidgets('owner requests a status update', (tester) async {
    await openTask(tester, 'owner@spacesharks.test', 'task_9');
    await tester.tap(find.byKey(const Key('requestStatusButton')));
    await tester.pumpAndSettle();
    final alerts = await services.alerts.getForUser('editor');
    expect(alerts.any((a) => a.type == AlertType.statusRequest && a.taskId == 'task_9'), isTrue);
  });

  testWidgets('owner deletes a task after confirming', (tester) async {
    await openTask(tester, 'owner@spacesharks.test', 'task_11');
    await tester.tap(find.byKey(const Key('taskMenu')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Delete task'));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('confirmButton')));
    await tester.pumpAndSettle();
    expect(await services.tasks.getById('task_11'), isNull);
  });

  testWidgets('owner opens the edit form from the menu', (tester) async {
    await openTask(tester, 'owner@spacesharks.test', 'task_3');
    await tester.tap(find.byKey(const Key('taskMenu')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Edit task'));
    await tester.pumpAndSettle();
    expect(find.text('Edit task'), findsOneWidget);
    expect(find.text('Weekend promo caption'), findsOneWidget);
  });

  testWidgets('client sees the decision panel only when approval is needed', (tester) async {
    await openTask(tester, 'client@kopikita.test', 'task_1');
    expect(find.byKey(const Key('approveButton')), findsNothing);
    expect(find.byKey(const Key('uploadButton')), findsNothing);
  });

  testWidgets('alerts: open the list and mark everything read', (tester) async {
    usePhoneSize(tester);
    await pumpApp(tester, services);
    await signIn(tester, 'owner@spacesharks.test');
    await tester.tap(find.byKey(const Key('alertsBell')));
    await tester.pumpAndSettle();
    expect(find.text('Overdue: Pumpkin latte launch post'), findsOneWidget);
    await tester.tap(find.text('Mark all read'));
    await tester.pumpAndSettle();
    final alerts = await services.alerts.getForUser('owner');
    expect(alerts.every((a) => a.read), isTrue);
  });
}
