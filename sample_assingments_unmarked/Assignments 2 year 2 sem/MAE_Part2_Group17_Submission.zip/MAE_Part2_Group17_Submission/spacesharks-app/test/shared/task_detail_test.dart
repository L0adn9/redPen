import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/models/models.dart';
import 'package:spacesharks_app/core/services/app_services.dart';
import 'package:spacesharks_app/core/services/file_picker_service.dart';
import 'package:spacesharks_app/features/shared/task_detail/task_detail_view_model.dart';

import '../helpers/test_helpers.dart';

void main() {
  late AppServices services;
  setUp(() async => services = await demoServices());

  Future<TaskDetailViewModel> open(String userId, String taskId) async {
    final user = (await services.users.getById(userId))!;
    final vm = TaskDetailViewModel(services, user, taskId)..start();
    await settle();
    return vm;
  }

  group('who can do what', () {
    test('client can decide only on a deliverable awaiting approval', () async {
      expect((await open('kopikita', 'task_2')).canDecide, isTrue); // awaiting
      expect((await open('kopikita', 'task_1')).canDecide, isFalse); // in progress
    });

    test('staff assignee can upload and hand over; others cannot', () async {
      final mine = await open('designer', 'task_1');
      expect(mine.canUpload, isTrue);
      expect(mine.canHandOver, isTrue);
      expect(mine.canSubmit, isTrue); // in progress with version 1
      final notMine = await open('writer', 'task_1');
      expect(notMine.canUpload, isFalse);
      expect(notMine.canHandOver, isFalse);
    });

    test('only a to-do task can be started', () async {
      expect((await open('writer', 'task_3')).canStart, isTrue);
      expect((await open('designer', 'task_1')).canStart, isFalse);
    });

    test('owner can edit, delete and request status, client cannot', () async {
      final owner = await open('owner', 'task_1');
      expect(owner.canEditOrDelete, isTrue);
      expect(owner.canRequestStatus, isTrue);
      final client = await open('kopikita', 'task_1');
      expect(client.canEditOrDelete, isFalse);
      expect(client.canUpload, isFalse);
    });
  });

  group('actions', () {
    test('client approves: status, final version and history update', () async {
      final vm = await open('kopikita', 'task_2');
      expect(await vm.approve(note: 'Love it'), isNotNull);
      await settle();
      expect(vm.task!.status, TaskStatus.approved);
      expect(vm.task!.approvedVersion, 2);
      final approvals = await services.feedback.watchApprovals('task_2').first;
      expect(approvals.first.note, 'Love it');
    });

    test('client requests changes with a reason', () async {
      final vm = await open('glowskin', 'task_6');
      await vm.requestChanges('Bigger logo');
      await settle();
      expect(vm.task!.status, TaskStatus.changesRequested);
    });

    test('staff upload -> send for approval -> client is alerted', () async {
      final vm = await open('writer', 'task_3');
      await vm.startWork();
      await settle();
      expect(vm.task!.status, TaskStatus.inProgress);
      await vm.upload(PickedFile(name: 'promo.png', bytes: Uint8List(50), mimeType: 'image/png'), note: 'First draft');
      await settle();
      expect(vm.task!.latestVersion, 1);
      expect(vm.canSubmit, isTrue);
      await vm.submitForApproval();
      await settle();
      expect(vm.task!.status, TaskStatus.awaitingApproval);
      final alerts = await services.alerts.watchForUser('kopikita').first;
      expect(alerts.any((a) => a.taskId == 'task_3' && a.type == AlertType.approvalNeeded), isTrue);
    });

    test('a file that is too large shows an error instead of crashing', () async {
      final vm = await open('writer', 'task_3');
      final result = await vm.upload(PickedFile(name: 'huge.mp4', bytes: Uint8List(800 * 1024), mimeType: 'video/mp4'));
      expect(result, isNull);
      expect(vm.error, contains('too large'));
    });

    test('staff hand over to a colleague', () async {
      final vm = await open('designer', 'task_10');
      final colleagues = await vm.colleagues();
      expect(colleagues.map((u) => u.id), isNot(contains('designer')));
      await vm.handOver(colleagues.first, 'Brand fonts attached');
      final handovers = await services.files.watchHandoversTo(colleagues.first.id).first;
      expect(handovers.any((h) => h.taskId == 'task_10' && !h.isReceived), isTrue);
    });

    test('owner requests status, staff replies, owner is alerted', () async {
      final owner = await open('owner', 'task_9');
      await owner.requestStatus();
      final editorAlerts = await services.alerts.watchForUser('editor').first;
      expect(editorAlerts.any((a) => a.type == AlertType.statusRequest && a.taskId == 'task_9'), isTrue);
      final staff = await open('editor', 'task_9');
      await staff.sendStatusUpdate('Editing done, colour grading tomorrow');
      final ownerAlerts = await services.alerts.watchForUser('owner').first;
      expect(ownerAlerts.any((a) => a.body == 'Editing done, colour grading tomorrow'), isTrue);
    });

    test('owner deletes a task', () async {
      final vm = await open('owner', 'task_11');
      await vm.delete();
      await settle();
      expect(vm.notFound, isTrue);
    });
  });

  test('mimeTypeFor picks the type from the extension', () {
    expect(mimeTypeFor('a.PNG'), 'image/png');
    expect(mimeTypeFor('b.jpeg'), 'image/jpeg');
    expect(mimeTypeFor('c.mp4'), 'video/mp4');
    expect(mimeTypeFor('noext'), 'application/octet-stream');
  });
}
