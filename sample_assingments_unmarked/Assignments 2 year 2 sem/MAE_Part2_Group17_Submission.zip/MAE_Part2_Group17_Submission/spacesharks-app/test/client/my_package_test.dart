// Client tests. Owned by: Hassan. Add a file per screen you build.
import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/features/client/package/my_package_view_model.dart';

import '../helpers/test_helpers.dart';

void main() {
  test('client sees only their package and what needs their approval', () async {
    final services = await demoServices();
    final client = (await services.users.getById('kopikita'))!;
    final vm = MyPackageViewModel(services, client, clock: () => testNow)..start();
    await settle();

    expect(vm.package!.clientName, 'Kopi Kita Cafe');
    expect(vm.awaitingMyApproval.map((t) => t.id).toList(), ['task_2']);
    expect(vm.inProgressCount, 3);
    expect(vm.approvedCount, 7);
    expect(vm.nextSevenDays.map((t) => t.id).toList(),
        ['task_1', 'task_2', 'task_3', 'task_5']);
    vm.dispose();
  });

  test('a client with no package gets an empty state', () async {
    final services = await demoServices();
    final owner = (await services.users.getById('owner'))!; // has no package as client
    final vm = MyPackageViewModel(services, owner, clock: () => testNow)..start();
    await settle();
    expect(vm.isLoading, isFalse);
    expect(vm.package, isNull);
    vm.dispose();
  });
}
