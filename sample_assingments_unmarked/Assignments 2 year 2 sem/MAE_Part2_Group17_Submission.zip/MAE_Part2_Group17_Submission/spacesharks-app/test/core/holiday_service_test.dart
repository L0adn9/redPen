import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/data/holiday_service.dart';

const sampleJson = '''
[
  {"date":"2026-11-08","localName":"Deepavali","name":"Deepavali","countryCode":"MY"},
  {"date":"2026-12-25","localName":"Hari Krismas","name":"Christmas Day","countryCode":"MY"}
]
''';

void main() {
  test('parses the Nager.Date JSON response', () {
    final list = HolidayService.parse(sampleJson);
    expect(list.length, 2);
    expect(list.first.name, 'Deepavali');
    expect(list.first.date, DateTime(2026, 11, 8));
  });

  test('calls the right URL and caches the year', () async {
    final calls = <Uri>[];
    final service = HolidayService(fetch: (url) async {
      calls.add(url);
      return sampleJson;
    });
    await service.holidaysFor(2026);
    await service.holidaysFor(2026);
    expect(calls.length, 1);
    expect(calls.single.toString(), 'https://date.nager.at/api/v3/PublicHolidays/2026/MY');
  });

  test('returns an empty list when the API is unreachable', () async {
    final service = HolidayService(fetch: (_) async => throw Exception('offline'));
    expect(await service.holidaysFor(2026), isEmpty);
  });

  test('finds the holidays inside one week', () async {
    final service = HolidayService(fetch: (_) async => sampleJson);
    final week = await service.holidaysInWeek(DateTime(2026, 11, 2)); // Mon 2 - Sun 8 Nov
    expect(week.map((h) => h.name), ['Deepavali']);
  });

  test('Google Calendar link is pre-filled', () {
    final url = googleCalendarLink(title: 'Kopi Kita: Reel', start: DateTime.utc(2026, 11, 2, 2));
    expect(url.host, 'calendar.google.com');
    expect(url.queryParameters['action'], 'TEMPLATE');
    expect(url.queryParameters['text'], 'Kopi Kita: Reel');
    expect(url.queryParameters['dates'], '20261102T020000Z/20261102T030000Z');
  });
}
