import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/utils/formatters.dart';
import 'package:spacesharks_app/core/utils/validators.dart';

void main() {
  group('Validators', () {
    test('email', () {
      expect(Validators.email(''), isNotNull);
      expect(Validators.email('not-an-email'), isNotNull);
      expect(Validators.email('owner@spacesharks.test'), isNull);
      expect(Validators.email('  owner@spacesharks.test  '), isNull);
    });

    test('password needs 6+ characters', () {
      expect(Validators.password(''), isNotNull);
      expect(Validators.password('12345'), isNotNull);
      expect(Validators.password('123456'), isNull);
    });

    test('required and maxLength combine with all()', () {
      final v = Validators.all([Validators.required('Title'), Validators.maxLength('Title', 5)]);
      expect(v(''), 'Title is required.');
      expect(v('toolong'), 'Title must be 5 characters or fewer.');
      expect(v('ok'), isNull);
    });

    test('intInRange', () {
      final v = Validators.intInRange('Promised items', 1, 60);
      expect(v('abc'), isNotNull);
      expect(v('0'), isNotNull);
      expect(v('12'), isNull);
    });

    test('notInPast', () {
      final now = DateTime(2026, 10, 28, 12);
      expect(Validators.notInPast(null, now), isNotNull);
      expect(Validators.notInPast(DateTime(2026, 10, 27), now), isNotNull);
      expect(Validators.notInPast(DateTime(2026, 10, 28), now), isNull);
    });
  });

  group('Formatters', () {
    final now = DateTime(2026, 10, 28, 12);
    test('formatDue', () {
      expect(formatDue(DateTime(2026, 10, 28, 17), now), 'Due today');
      expect(formatDue(DateTime(2026, 10, 29, 17), now), 'Due tomorrow');
      expect(formatDue(DateTime(2026, 10, 31, 17), now), 'Due in 3 days');
      expect(formatDue(DateTime(2026, 10, 26, 17), now), '2 days overdue');
    });

    test('formatDateTime and startOfWeek', () {
      expect(formatDateTime(DateTime(2026, 11, 2, 15, 5)), '2 Nov 2026, 3:05 PM');
      expect(startOfWeek(now), DateTime(2026, 10, 26)); // Monday
      expect(formatDay(DateTime(2026, 11, 2)), 'Mon 2 Nov');
    });
  });
}
