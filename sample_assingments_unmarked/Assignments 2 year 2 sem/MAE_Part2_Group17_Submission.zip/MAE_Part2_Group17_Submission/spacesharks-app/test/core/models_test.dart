import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/models/models.dart';

void main() {
  final now = DateTime(2026, 10, 28, 12);

  ContentTask task({TaskStatus status = TaskStatus.inProgress, DateTime? due}) => ContentTask(
        id: 't1',
        packageId: 'p1',
        clientName: 'Kopi Kita Cafe',
        title: 'Launch post',
        contentType: ContentType.post,
        assigneeId: 'u1',
        assigneeName: 'Nurul',
        dueDate: due ?? now.subtract(const Duration(days: 1)),
        priority: TaskPriority.high,
        status: status,
        createdAt: now,
        updatedAt: now,
        latestVersion: 2,
      );

  group('ContentTask', () {
    test('toMap and fromMap keep every field', () {
      final original = task().copyWith(publishDate: now, approvedVersion: 2, description: 'Notes');
      final copy = ContentTask.fromMap('t1', original.toMap());
      expect(copy.title, original.title);
      expect(copy.status, original.status);
      expect(copy.priority, original.priority);
      expect(copy.contentType, original.contentType);
      expect(copy.dueDate, original.dueDate);
      expect(copy.publishDate, original.publishDate);
      expect(copy.approvedVersion, 2);
      expect(copy.latestVersion, 2);
      expect(copy.description, 'Notes');
    });

    test('is overdue only when open and past the due date', () {
      expect(task().isOverdue(now), isTrue);
      expect(task(status: TaskStatus.approved).isOverdue(now), isFalse);
      expect(task(due: now.add(const Duration(hours: 1))).isOverdue(now), isFalse);
    });

    test('unknown enum values fall back safely', () {
      final map = task().toMap()..['status'] = 'somethingOld';
      expect(ContentTask.fromMap('t1', map).status, TaskStatus.todo);
    });

    test('reads dates stored as ISO strings or milliseconds', () {
      final map = task().toMap()
        ..['dueDate'] = '2026-11-02T23:00:00.000'
        ..['createdAt'] = DateTime(2026, 10, 1).millisecondsSinceEpoch;
      final t = ContentTask.fromMap('t1', map);
      expect(t.dueDate, DateTime(2026, 11, 2, 23));
      expect(t.createdAt, DateTime(2026, 10, 1));
    });
  });

  test('ClientPackage round trip', () {
    final p = ClientPackage(
      id: 'p1',
      clientName: 'Glow Skin Studio',
      clientUserId: 'c1',
      packageName: 'Starter Monthly',
      phase: PackagePhase.buildUp,
      managerId: 'o1',
      managerName: 'Farid',
      promisedItems: 8,
      startDate: now,
    );
    final copy = ClientPackage.fromMap('p1', p.toMap());
    expect(copy.phase, PackagePhase.buildUp);
    expect(copy.phase.step, 2);
    expect(copy.promisedItems, 8);
    expect(copy.active, isTrue);
  });

  test('AppUser initials and role', () {
    const user = AppUser(id: 'u', name: 'Nurul Aina', email: 'a@b.c', role: UserRole.staff);
    expect(user.initials, 'NA');
    expect(AppUser.fromMap('u', user.toMap()).role, UserRole.staff);
  });

  test('FileVersion knows when it is an image', () {
    final v = FileVersion(id: 'v', taskId: 't', versionNumber: 1, fileName: 'a.png', fileUrl: '', mimeType: 'image/png', sizeBytes: 10, uploadedById: 'u', uploadedByName: 'N', createdAt: now);
    expect(v.isImage, isTrue);
  });

  test('Handover is received once receivedAt is set', () {
    final h = Handover(id: 'h', taskId: 't', taskTitle: 'T', fromUserId: 'a', fromName: 'A', toUserId: 'b', toName: 'B', versionNumber: 1, sentAt: now);
    expect(h.isReceived, isFalse);
    expect(Handover.fromMap('h', h.toMap()..['receivedAt'] = now).isReceived, isTrue);
  });
}
