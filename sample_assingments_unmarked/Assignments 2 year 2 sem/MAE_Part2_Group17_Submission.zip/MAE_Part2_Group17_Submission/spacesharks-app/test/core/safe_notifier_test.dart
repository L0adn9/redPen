import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/data/auth_repository.dart';
import 'package:spacesharks_app/features/auth/login_view_model.dart';

import '../helpers/test_helpers.dart';

void main() {
  test('sign-in that finishes after the login screen closed does not throw', () async {
    final services = await demoServices();
    final vm = LoginViewModel(services.auth);
    final pending = vm.signIn('owner@spacesharks.test', FakeAuthRepository.demoPassword);
    vm.dispose(); // the home screen replaced the login screen
    expect(await pending, isTrue);
  });
}
