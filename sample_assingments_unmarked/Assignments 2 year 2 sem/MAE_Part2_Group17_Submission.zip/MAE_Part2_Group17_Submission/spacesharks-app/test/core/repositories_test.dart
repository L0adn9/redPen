import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/data/auth_repository.dart';
import 'package:spacesharks_app/core/data/doc_store.dart';
import 'package:spacesharks_app/core/data/file_storage.dart';
import 'package:spacesharks_app/core/data/memory_doc_store.dart';
import 'package:spacesharks_app/core/models/models.dart';
import 'package:spacesharks_app/core/services/app_services.dart';

import '../helpers/test_helpers.dart';

void main() {
  late AppServices services;

  setUp(() async => services = await demoServices());

  Future<ContentTask> task(String id) async => (await services.tasks.getById(id))!;
  Future<AppUser> user(String id) async => (await services.users.getById(id))!;

  group('MemoryDocStore', () {
    test('watchers get a new list after every change', () async {
      final store = MemoryDocStore();
      final emitted = <int>[];
      final sub = store.watchCollection('things').listen((d) => emitted.add(d.length));
      await settle();
      await store.add('things', {'a': 1});
      await store.add('things', {'a': 2});
      await settle();
      expect(emitted, [0, 1, 2]);
      await sub.cancel();
    });

    test('update of a missing document throws', () {
      expect(MemoryDocStore().update('x', 'nope', {'a': 1}), throwsA(isA<StoreException>()));
    });
  });

  group('Auth (demo)', () {
    test('signs in with the right password and returns the role', () async {
      final u = await services.auth.signIn(email: 'OWNER@spacesharks.test ', password: 'password123');
      expect(u.role, UserRole.owner);
    });

    test('rejects a wrong password', () {
      expect(services.auth.signIn(email: 'owner@spacesharks.test', password: 'wrong123'),
          throwsA(isA<AuthException>()));
    });
  });

  group('Tasks', () {
    test('creating a task alerts the assignee', () async {
      final template = await task('task_3');
      final id = await services.tasks.create(template.copyWith(title: 'Halloween reel', assigneeId: 'editor'));
      final alerts = await services.alerts.watchForUser('editor').first;
      expect(alerts.any((a) => a.taskId == id && a.type == AlertType.newTask), isTrue);
    });

    test('deleting a task removes it', () async {
      await services.tasks.delete(await task('task_11'));
      expect(await services.tasks.getById('task_11'), isNull);
    });

    test('deleting a task also removes its comments, approvals, versions and handovers', () async {
      final t = await task('task_2');
      await services.feedback.addComment(task: t, author: await user('kopikita'), text: 'Hi');
      await services.feedback.recordDecision(
          task: t, client: await user('kopikita'), decision: ApprovalDecision.approved);
      await services.files.handOver(task: t, from: await user('editor'), to: await user('designer'));
      await services.tasks.delete(t);
      for (final c in [Collections.comments, Collections.approvals, Collections.versions, Collections.handovers]) {
        expect(await services.store.getCollection(c, whereField: 'taskId', isEqualTo: 'task_2'), isEmpty, reason: c);
      }
    });
  });

  group('Feedback and approvals', () {
    test('client approval is timestamped and marks the version final', () async {
      final t = await task('task_2');
      await services.feedback.recordDecision(
          task: t, client: await user('kopikita'), decision: ApprovalDecision.approved);
      final updated = await task('task_2');
      expect(updated.status, TaskStatus.approved);
      expect(updated.approvedVersion, t.latestVersion);
      final approvals = await services.feedback.watchApprovals('task_2').first;
      expect(approvals.first.decision, ApprovalDecision.approved);
      expect(approvals.first.byName, 'Hafiz Osman');
    });

    test('change request moves the task back and alerts staff', () async {
      final t = await task('task_6');
      await services.feedback.recordDecision(
          task: t, client: await user('glowskin'), decision: ApprovalDecision.changesRequested, note: 'Bigger logo');
      expect((await task('task_6')).status, TaskStatus.changesRequested);
      final alerts = await services.alerts.watchForUser('designer').first;
      expect(alerts.any((a) => a.body == 'Bigger logo' && a.taskId == 'task_6'), isTrue);
    });

    test('client comment alerts staff and is marked seen when staff open it', () async {
      final t = await task('task_7');
      await services.feedback.addComment(task: t, author: await user('glowskin'), text: 'Use calm music');
      var comments = await services.feedback.watchComments('task_7').first;
      expect(comments.single.seenByAgency, isFalse);
      await services.feedback.markClientCommentsSeen('task_7');
      comments = await services.feedback.watchComments('task_7').first;
      expect(comments.single.seenByAgency, isTrue);
      expect(comments.single.seenAt, isNotNull);
    });

    test('submitting for approval alerts the client', () async {
      await services.feedback.submitForApproval(await task('task_9'));
      expect((await task('task_9')).status, TaskStatus.awaitingApproval);
      final alerts = await services.alerts.watchForUser('urbanfit').first;
      expect(alerts.any((a) => a.type == AlertType.approvalNeeded && a.taskId == 'task_9'), isTrue);
    });
  });

  group('Files and handovers', () {
    test('uploading creates the next version number', () async {
      final t = await task('task_3'); // todo, no files yet
      final v = await services.files.uploadVersion(
        task: t,
        uploader: await user('writer'),
        fileName: 'caption.txt',
        bytes: Uint8List.fromList('Weekend promo!'.codeUnits),
        mimeType: 'text/plain',
      );
      expect(v.versionNumber, 1);
      final updated = await task('task_3');
      expect(updated.latestVersion, 1);
      expect(updated.status, TaskStatus.inProgress);
    });

    test('files over the size limit are refused', () {
      const storage = DataUriFileStorage(maxBytes: 10);
      expect(storage.upload(path: 'x', bytes: Uint8List(11), mimeType: 'image/png'),
          throwsA(isA<FileTooLargeException>()));
    });

    test('handover is pending until the receiver confirms', () async {
      final id = await services.files.handOver(
          task: await task('task_10'), from: await user('designer'), to: await user('writer'));
      var list = await services.files.watchHandoversTo('writer').first;
      expect(list.firstWhere((h) => h.id == id).isReceived, isFalse);
      await services.files.confirmReceived(id);
      list = await services.files.watchHandoversTo('writer').first;
      expect(list.firstWhere((h) => h.id == id).isReceived, isTrue);
    });
  });

  test('alerts can be marked read', () async {
    await services.alerts.markAllRead('owner');
    final alerts = await services.alerts.watchForUser('owner').first;
    expect(alerts.every((a) => a.read), isTrue);
  });
}
