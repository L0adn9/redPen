// Widget tests: each role's main screens and forms, driven like a user.
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/models/models.dart';
import 'package:spacesharks_app/core/services/app_services.dart';

import '../helpers/test_helpers.dart';

void main() {
  late AppServices services;
  setUp(() async => services = await demoServices(now: DateTime.now()));

  Future<void> tab(WidgetTester tester, String label) async {
    await tester.tap(find.descendant(of: find.byType(NavigationBar), matching: find.text(label)));
    await tester.pumpAndSettle();
  }

  testWidgets('client approves a deliverable from the package page', (tester) async {
    usePhoneSize(tester);
    await pumpApp(tester, services);
    await signIn(tester, 'client@kopikita.test');

    await tester.tap(find.byKey(const Key('deliverable_task_2')));
    await tester.pumpAndSettle();
    expect(find.text('Version 2 is waiting for your decision'), findsOneWidget);

    await tester.tap(find.byKey(const Key('approveButton')));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('dialogTextField')), 'Perfect, post it');
    await tester.tap(find.byKey(const Key('dialogConfirm')));
    await tester.pumpAndSettle();

    expect(find.byKey(const Key('approveButton')), findsNothing);
    expect((await services.tasks.getById('task_2'))!.status, TaskStatus.approved);
  });

  testWidgets('request changes needs a reason', (tester) async {
    usePhoneSize(tester);
    await pumpApp(tester, services);
    await signIn(tester, 'client@glowskin.test');
    await tester.tap(find.byKey(const Key('deliverable_task_6')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const Key('requestChangesButton')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('dialogConfirm')));
    await tester.pump();
    expect(find.text('Please write something first.'), findsOneWidget);
  });

  testWidgets('client comment shows in the thread', (tester) async {
    usePhoneSize(tester);
    await pumpApp(tester, services);
    await signIn(tester, 'client@kopikita.test');
    await tester.tap(find.byKey(const Key('deliverable_task_2')));
    await tester.pumpAndSettle();

    final field = find.byKey(const Key('commentField'));
    await tester.ensureVisible(field);
    await tester.enterText(field, 'Can we post at 8pm?');
    await tester.tap(find.byKey(const Key('sendCommentButton')));
    await tester.pumpAndSettle();
    expect(find.text('Can we post at 8pm?'), findsOneWidget);
    expect(find.textContaining('Not seen yet'), findsWidgets);
  });

  testWidgets('owner new task form validates required fields', (tester) async {
    usePhoneSize(tester);
    await pumpApp(tester, services);
    await signIn(tester, 'owner@spacesharks.test');
    await tester.tap(find.byKey(const Key('package_pkg_kopikita')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('newTaskButton')));
    await tester.pumpAndSettle();

    await tester.tap(find.byKey(const Key('saveTaskButton')));
    await tester.pumpAndSettle();
    expect(find.text('Title is required.'), findsOneWidget);
    expect(find.text('Choose who will do this.'), findsOneWidget);
    expect(find.text('Pick a due date.'), findsOneWidget);
  });

  testWidgets('owner new package form validates promised items', (tester) async {
    usePhoneSize(tester);
    await pumpApp(tester, services);
    await signIn(tester, 'owner@spacesharks.test');
    await tester.tap(find.byKey(const Key('newPackageButton')));
    await tester.pumpAndSettle();

    await tester.enterText(find.byKey(const Key('promisedField')), '0');
    await tester.tap(find.byKey(const Key('savePackageButton')));
    await tester.pumpAndSettle();
    expect(find.text('Client name is required.'), findsOneWidget);
    expect(find.text('Promised items must be 1 to 60.'), findsOneWidget);
    expect(find.text('Choose the client account.'), findsOneWidget);
  });

  testWidgets('owner sees workload and pending handovers', (tester) async {
    usePhoneSize(tester);
    await pumpApp(tester, services);
    await signIn(tester, 'owner@spacesharks.test');
    await tab(tester, 'Workload');
    expect(find.text('Team workload'), findsOneWidget);
    expect(find.text('Nurul Aina'), findsOneWidget);
    expect(find.textContaining('Handovers (1 waiting)'), findsOneWidget);
  });

  testWidgets('staff confirm a handover', (tester) async {
    usePhoneSize(tester);
    await pumpApp(tester, services);
    await signIn(tester, 'editor@spacesharks.test');
    await tab(tester, 'Handovers');
    expect(find.text('Handed to me (1 to confirm)'), findsOneWidget);
    await tester.tap(find.byKey(const Key('confirm_hand_2')));
    await tester.pumpAndSettle();
    expect(find.text('Handed to me (0 to confirm)'), findsOneWidget);
  });

  testWidgets('staff flag overload needs a reason, then alerts the owner', (tester) async {
    usePhoneSize(tester);
    await pumpApp(tester, services);
    await signIn(tester, 'designer@spacesharks.test');
    await tab(tester, 'My week');
    await tester.tap(find.byKey(const Key('flagOverloadButton')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('dialogConfirm')));
    await tester.pump();
    expect(find.text('Please write something first.'), findsOneWidget);
    await tester.enterText(find.byKey(const Key('dialogTextField')), 'Two posts due tomorrow');
    await tester.tap(find.byKey(const Key('dialogConfirm')));
    await tester.pumpAndSettle();
    final alerts = await services.alerts.getForUser('owner');
    expect(alerts.any((a) => a.type == AlertType.overload), isTrue);
  });

  testWidgets('tablet layout uses a side navigation rail', (tester) async {
    tester.view.physicalSize = const Size(1280, 800);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
    await pumpApp(tester, services);
    await signIn(tester, 'owner@spacesharks.test');
    expect(find.byType(NavigationRail), findsOneWidget);
    expect(find.byType(NavigationBar), findsNothing);
  });
}
