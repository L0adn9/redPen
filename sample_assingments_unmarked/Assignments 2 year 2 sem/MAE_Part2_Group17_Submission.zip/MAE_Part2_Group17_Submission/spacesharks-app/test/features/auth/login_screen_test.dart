import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:spacesharks_app/core/services/app_services.dart';

import '../../helpers/test_helpers.dart';

void main() {
  late AppServices services;
  setUp(() async => services = await demoServices(now: DateTime.now()));

  testWidgets('shows validation errors for empty fields', (tester) async {
    await pumpApp(tester, services);
    await tester.tap(find.byKey(const Key('loginButton')));
    await tester.pump();
    expect(find.text('Enter your email.'), findsOneWidget);
    expect(find.text('Enter your password.'), findsOneWidget);
  });

  testWidgets('shows an error for a wrong password', (tester) async {
    await pumpApp(tester, services);
    await signIn(tester, 'owner@spacesharks.test', password: 'wrongpass');
    expect(find.byKey(const Key('loginError')), findsOneWidget);
    expect(find.text('Incorrect email or password.'), findsOneWidget);
  });

  testWidgets('each role lands on its own home', (tester) async {
    usePhoneSize(tester);
    await pumpApp(tester, services);

    await signIn(tester, 'owner@spacesharks.test');
    expect(find.text('Client packages'), findsOneWidget);
    await _signOut(tester);

    await signIn(tester, 'designer@spacesharks.test');
    expect(find.textContaining('Do first'), findsOneWidget);
    await _signOut(tester);

    await signIn(tester, 'client@kopikita.test');
    expect(find.text('Kopi Kita Cafe'), findsOneWidget);
    expect(find.textContaining('Waiting for your approval'), findsOneWidget);
  });

  testWidgets('demo chips fill the form', (tester) async {
    await pumpApp(tester, services);
    await tester.tap(find.byKey(const Key('demo_owner')));
    await tester.pump();
    expect(find.text('owner@spacesharks.test'), findsOneWidget);
  });
}

Future<void> _signOut(WidgetTester tester) async {
  await tester.tap(find.byKey(const Key('accountMenu')));
  await tester.pumpAndSettle();
  await tester.tap(find.text('Sign out'));
  await tester.pumpAndSettle();
}
