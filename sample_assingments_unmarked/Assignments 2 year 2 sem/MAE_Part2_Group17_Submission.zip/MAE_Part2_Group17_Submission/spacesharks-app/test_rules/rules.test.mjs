// Automated tests for firestore.rules (run on the Firebase emulator).
// Every query here is one the app really makes (see lib/core/data/repositories.dart).
//   cd test_rules && npm install && npx firebase emulators:exec --only firestore --project demo-spacesharks --config ../firebase.json "npm test"
import { readFileSync } from 'node:fs';
import { test, before, after } from 'node:test';
import {
  initializeTestEnvironment, assertSucceeds, assertFails,
} from '@firebase/rules-unit-testing';
import {
  collection, doc, getDoc, getDocs, query, where, setDoc, addDoc, updateDoc, deleteDoc,
} from 'firebase/firestore';

let env;
const now = new Date();

before(async () => {
  env = await initializeTestEnvironment({
    projectId: 'demo-spacesharks',
    firestore: { rules: readFileSync(new URL('../firestore.rules', import.meta.url), 'utf8'), host: '127.0.0.1', port: 8080 },
  });
  await env.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    const put = (c, id, d) => setDoc(doc(db, c, id), d);
    await put('users', 'owner', { name: 'Owner', role: 'owner', email: 'o@x.test' });
    await put('users', 'writer', { name: 'Writer', role: 'staff', email: 'w@x.test' });
    await put('users', 'designer', { name: 'Designer', role: 'staff', email: 'd@x.test' });
    await put('users', 'kk', { name: 'Kopi', role: 'client', email: 'k@x.test' });
    await put('users', 'gs', { name: 'Glow', role: 'client', email: 'g@x.test' });
    await put('packages', 'pkg_kk', { clientUserId: 'kk', clientName: 'Kopi Kita' });
    await put('packages', 'pkg_gs', { clientUserId: 'gs', clientName: 'Glow Skin' });
    await put('tasks', 't_kk', { packageId: 'pkg_kk', assigneeId: 'writer', title: 'KK post', status: 'awaitingApproval', latestVersion: 1 });
    await put('tasks', 't_gs', { packageId: 'pkg_gs', assigneeId: 'writer', title: 'GS post', status: 'awaitingApproval', latestVersion: 1 });
    await put('comments', 'c_kk', { taskId: 't_kk', packageId: 'pkg_kk', authorId: 'kk', authorRole: 'client', text: 'hi' });
    await put('comments', 'c_gs', { taskId: 't_gs', packageId: 'pkg_gs', authorId: 'gs', authorRole: 'client', text: 'hi' });
    await put('approvals', 'a_kk', { taskId: 't_kk', packageId: 'pkg_kk', byUserId: 'kk', decision: 'approved' });
    await put('approvals', 'a_gs', { taskId: 't_gs', packageId: 'pkg_gs', byUserId: 'gs', decision: 'approved' });
    await put('versions', 'v_kk', { taskId: 't_kk', versionNumber: 1 });
    await put('versions', 'v_gs', { taskId: 't_gs', versionNumber: 1 });
    await put('handovers', 'h1', { taskId: 't_kk', fromUserId: 'writer', toUserId: 'designer' });
    await put('alerts', 'al_kk', { userId: 'kk', title: 'x', read: false });
    await put('alerts', 'al_gs', { userId: 'gs', title: 'x', read: false });
  });
});
after(async () => { await env?.cleanup(); });

const as = (uid) => env.authenticatedContext(uid).firestore();
const q = (db, c, f, v) => getDocs(query(collection(db, c), where(f, '==', v)));
const all = (db, c) => getDocs(collection(db, c));

// ---------- signed out
test('signed out: cannot read anything', async () => {
  const db = env.unauthenticatedContext().firestore();
  await assertFails(all(db, 'packages'));
  await assertFails(getDoc(doc(db, 'tasks', 't_kk')));
  await assertFails(all(db, 'users'));
});

// ---------- owner
test('owner: reads and manages everything', async () => {
  const db = as('owner');
  await assertSucceeds(all(db, 'packages'));
  await assertSucceeds(all(db, 'tasks'));
  await assertSucceeds(all(db, 'handovers'));
  await assertSucceeds(q(db, 'approvals', 'packageId', 'pkg_kk'));
  await assertSucceeds(q(db, 'comments', 'taskId', 't_kk'));
  await assertSucceeds(q(db, 'users', 'role', 'staff'));
  await assertSucceeds(addDoc(collection(db, 'packages'), { clientUserId: 'kk', clientName: 'New' }));
  await assertSucceeds(addDoc(collection(db, 'tasks'), { packageId: 'pkg_kk', assigneeId: 'writer', title: 'New' }));
  await assertSucceeds(updateDoc(doc(db, 'tasks', 't_kk'), { title: 'KK post (edited)' }));
  await assertSucceeds(setDoc(doc(db, 'users', 'newstaff'), { name: 'New', role: 'staff' }));
  await assertSucceeds(updateDoc(doc(db, 'comments', 'c_kk'), { seenByAgency: true }));
});

test('owner: deletes a package task and a task', async () => {
  const db = as('owner');
  const ref = await addDoc(collection(db, 'tasks'), { packageId: 'pkg_kk', assigneeId: 'writer', title: 'Tmp' });
  await assertSucceeds(deleteDoc(ref));
});

// ---------- staff
test('staff: reads work and does their job', async () => {
  const db = as('writer');
  await assertSucceeds(q(db, 'tasks', 'assigneeId', 'writer'));
  await assertSucceeds(all(db, 'packages'));
  await assertSucceeds(getDoc(doc(db, 'packages', 'pkg_kk')));
  await assertSucceeds(q(db, 'comments', 'taskId', 't_kk'));
  await assertSucceeds(q(db, 'approvals', 'taskId', 't_kk'));
  await assertSucceeds(q(db, 'versions', 'taskId', 't_kk'));
  await assertSucceeds(q(db, 'users', 'role', 'staff'));
  await assertSucceeds(q(db, 'handovers', 'fromUserId', 'writer'));
  await assertSucceeds(addDoc(collection(db, 'versions'), { taskId: 't_kk', versionNumber: 2 }));
  await assertSucceeds(updateDoc(doc(db, 'tasks', 't_kk'), { latestVersion: 2, status: 'inProgress' }));
  await assertSucceeds(addDoc(collection(db, 'comments'), { taskId: 't_kk', packageId: 'pkg_kk', authorId: 'writer', authorRole: 'staff', text: 'ok' }));
  await assertSucceeds(updateDoc(doc(db, 'comments', 'c_kk'), { seenByAgency: true }));
  await assertSucceeds(addDoc(collection(db, 'handovers'), { taskId: 't_kk', fromUserId: 'writer', toUserId: 'designer' }));
  await assertSucceeds(addDoc(collection(db, 'alerts'), { userId: 'owner', title: 'Status' }));
});

test('staff: only the receiver confirms a handover', async () => {
  await assertSucceeds(updateDoc(doc(as('designer'), 'handovers', 'h1'), { receivedAt: now }));
  await assertFails(updateDoc(doc(as('writer'), 'handovers', 'h1'), { receivedAt: now }));
});

test('staff: cannot do owner actions', async () => {
  const db = as('writer');
  await assertFails(addDoc(collection(db, 'tasks'), { packageId: 'pkg_kk', title: 'x' }));
  await assertFails(deleteDoc(doc(db, 'tasks', 't_gs')));
  await assertFails(addDoc(collection(db, 'packages'), { clientUserId: 'kk' }));
  await assertFails(updateDoc(doc(db, 'packages', 'pkg_kk'), { clientName: 'x' }));
});

// ---------- client
test('client: sees only their own package and deliverables', async () => {
  const db = as('kk');
  await assertSucceeds(q(db, 'packages', 'clientUserId', 'kk'));
  await assertSucceeds(getDoc(doc(db, 'packages', 'pkg_kk')));
  await assertSucceeds(q(db, 'tasks', 'packageId', 'pkg_kk'));
  await assertSucceeds(getDoc(doc(db, 'tasks', 't_kk')));
  await assertSucceeds(q(db, 'comments', 'taskId', 't_kk'));
  await assertSucceeds(q(db, 'approvals', 'taskId', 't_kk'));
  await assertSucceeds(q(db, 'versions', 'taskId', 't_kk'));
  await assertSucceeds(q(db, 'alerts', 'userId', 'kk'));
  await assertSucceeds(q(db, 'users', 'role', 'owner'));
});

test("client: cannot see another client's data", async () => {
  const db = as('kk');
  await assertFails(all(db, 'packages'));
  await assertFails(getDoc(doc(db, 'packages', 'pkg_gs')));
  await assertFails(q(db, 'tasks', 'packageId', 'pkg_gs'));
  await assertFails(getDoc(doc(db, 'tasks', 't_gs')));
  await assertFails(q(db, 'comments', 'taskId', 't_gs'));
  await assertFails(q(db, 'approvals', 'taskId', 't_gs'));
  await assertFails(q(db, 'versions', 'taskId', 't_gs'));
  await assertFails(q(db, 'alerts', 'userId', 'gs'));
  await assertFails(all(db, 'handovers'));
});

test('client: approves, requests changes and comments on own deliverables', async () => {
  const db = as('kk');
  await assertSucceeds(addDoc(collection(db, 'approvals'), { taskId: 't_kk', packageId: 'pkg_kk', byUserId: 'kk', decision: 'approved' }));
  await assertSucceeds(updateDoc(doc(db, 'tasks', 't_kk'), { status: 'approved', approvedVersion: 1, updatedAt: now }));
  await assertSucceeds(addDoc(collection(db, 'comments'), { taskId: 't_kk', packageId: 'pkg_kk', authorId: 'kk', authorRole: 'client', text: 'Nice' }));
  await assertSucceeds(addDoc(collection(db, 'alerts'), { userId: 'writer', title: 'approved' }));
  await assertSucceeds(updateDoc(doc(db, 'alerts', 'al_kk'), { read: true }));
});

test('client: cannot act on other data or change task details', async () => {
  const db = as('kk');
  await assertFails(addDoc(collection(db, 'approvals'), { taskId: 't_gs', packageId: 'pkg_gs', byUserId: 'kk', decision: 'approved' }));
  await assertFails(addDoc(collection(db, 'approvals'), { taskId: 't_kk', packageId: 'pkg_kk', byUserId: 'gs', decision: 'approved' }));
  await assertFails(updateDoc(doc(db, 'tasks', 't_gs'), { status: 'approved' }));
  await assertFails(updateDoc(doc(db, 'tasks', 't_kk'), { title: 'hacked' }));
  await assertFails(addDoc(collection(db, 'comments'), { taskId: 't_gs', packageId: 'pkg_gs', authorId: 'kk', text: 'x' }));
  await assertFails(addDoc(collection(db, 'comments'), { taskId: 't_kk', packageId: 'pkg_kk', authorId: 'gs', text: 'x' }));
  await assertFails(updateDoc(doc(db, 'comments', 'c_kk'), { seenByAgency: true }));
  await assertFails(addDoc(collection(db, 'versions'), { taskId: 't_kk', versionNumber: 9 }));
  await assertFails(addDoc(collection(db, 'tasks'), { packageId: 'pkg_kk', title: 'x' }));
});

test('nobody can give themselves a role', async () => {
  await assertFails(updateDoc(doc(as('kk'), 'users', 'kk'), { role: 'owner' }));
  await assertFails(updateDoc(doc(as('writer'), 'users', 'writer'), { role: 'owner' }));
  await assertFails(setDoc(doc(as('stranger'), 'users', 'stranger'), { name: 'X', role: 'owner' }));
  await assertSucceeds(updateDoc(doc(as('kk'), 'users', 'kk'), { name: 'Kopi Kita' }));
});

test('owner deleting a task also removes its records', async () => {
  const db = as('owner');
  await assertSucceeds(deleteDoc(doc(db, 'comments', 'c_gs')));
  await assertSucceeds(deleteDoc(doc(db, 'approvals', 'a_gs')));
  await assertSucceeds(deleteDoc(doc(db, 'versions', 'v_gs')));
  await assertSucceeds(q(db, 'handovers', 'taskId', 't_kk'));
  await assertFails(deleteDoc(doc(as('writer'), 'comments', 'c_kk')));
  await assertFails(deleteDoc(doc(as('kk'), 'approvals', 'a_kk')));
  await assertFails(deleteDoc(doc(as('writer'), 'handovers', 'h1')));
});
