#!/usr/bin/env bash
# Publishes the E2E output and screenshots to the ci-e2e branch.
# Run inside the emulator step, so results survive even if the runner is
# lost while the emulator shuts down.
set -u
OUTCOME="${1:-unknown}"
rm -rf /tmp/e2e-out && mkdir -p /tmp/e2e-out/screenshots
cp -f e2e-output.txt /tmp/e2e-out/ 2>/dev/null || echo "no output" > /tmp/e2e-out/e2e-output.txt
cp -f build/e2e_screenshots/*.png /tmp/e2e-out/screenshots/ 2>/dev/null || true
grep -E "E2E STEP|E2E TRACE|failed:|E2E SUMMARY|PASS  |All tests passed|Some tests failed|TestFailure|Timed out|Expected:|Actual:|Exception" e2e-output.txt > /tmp/e2e-out/e2e-summary.txt 2>/dev/null || true
echo "e2e ${OUTCOME} for ${GITHUB_SHA} at $(date -u)" > /tmp/e2e-out/E2E.txt
cd /tmp/e2e-out && git init -q -b ci-e2e && git add -A
git -c user.name=ci -c user.email=ci@users.noreply.github.com commit -q -m "E2E results for ${GITHUB_SHA}"
git push -q -f "https://x-access-token:${GH_TOKEN}@github.com/${GITHUB_REPOSITORY}.git" ci-e2e
