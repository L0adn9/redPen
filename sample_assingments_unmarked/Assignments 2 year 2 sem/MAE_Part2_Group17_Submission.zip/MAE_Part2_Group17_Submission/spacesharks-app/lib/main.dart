import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'app.dart';
import 'core/config/app_config.dart';
import 'core/services/app_services.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(SpacesharksApp(services: await createServices()));
}

Future<AppServices> createServices() async {
  if (AppConfig.backend == Backend.firebase) {
    await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform);
    return AppServices.firebase(useCloudStorage: AppConfig.useCloudStorage);
  }
  return AppServices.demo();
}
