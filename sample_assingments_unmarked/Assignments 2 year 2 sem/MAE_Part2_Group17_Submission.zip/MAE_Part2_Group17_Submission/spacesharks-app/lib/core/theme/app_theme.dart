import 'package:flutter/material.dart';

import '../models/models.dart';

/// SPACESHARKS palette from the proposal (Figure 3): black and white from the
/// logo, greys for cards and secondary text, one orange accent for actions
/// and alerts, and three status colours.
abstract final class AppColors {
  static const ink = Color(0xFF111111);
  static const white = Color(0xFFFFFFFF);
  static const background = Color(0xFFF6F6F7);
  static const card = Color(0xFFFFFFFF);
  static const line = Color(0xFFE4E4E7);
  static const muted = Color(0xFF6E6E73);
  static const orange = Color(0xFFFF7A1A);
  static const green = Color(0xFF2E9E5B); // approved
  static const amber = Color(0xFFE09B12); // pending
  static const red = Color(0xFFD64545); // overdue

  static Color forStatus(TaskStatus status) => switch (status) {
        TaskStatus.approved => green,
        TaskStatus.awaitingApproval => amber,
        TaskStatus.changesRequested => red,
        TaskStatus.inProgress => orange,
        TaskStatus.todo => muted,
      };

  static Color forPriority(TaskPriority priority) => switch (priority) {
        TaskPriority.high => red,
        TaskPriority.medium => amber,
        TaskPriority.low => muted,
      };
}

abstract final class AppTheme {
  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.orange,
      primary: AppColors.orange,
      onPrimary: AppColors.white,
      secondary: AppColors.ink,
      onSecondary: AppColors.white,
      surface: AppColors.card,
      onSurface: AppColors.ink,
      error: AppColors.red,
    );
    final base = ThemeData(
      useMaterial3: true,
      fontFamily: 'Inter',
      colorScheme: scheme,
      scaffoldBackgroundColor: AppColors.background,
    );
    return base.copyWith(
      textTheme: base.textTheme.apply(
          bodyColor: AppColors.ink, displayColor: AppColors.ink),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
            fontFamily: 'Inter',
            color: AppColors.ink, fontSize: 20, fontWeight: FontWeight.w700),
      ),
      cardTheme: CardThemeData(
        color: AppColors.card,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: AppColors.line),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(64, 48),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w600, fontSize: 15),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(64, 48),
          foregroundColor: AppColors.ink,
          side: const BorderSide(color: AppColors.line),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.white,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.line),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.line),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.orange, width: 1.6),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: AppColors.white,
        indicatorColor: AppColors.orange.withValues(alpha: 0.16),
        labelTextStyle: WidgetStateProperty.all(
            const TextStyle(fontFamily: 'Inter', fontSize: 12, fontWeight: FontWeight.w600)),
      ),
      dividerTheme: const DividerThemeData(color: AppColors.line, space: 1),
    );
  }
}
