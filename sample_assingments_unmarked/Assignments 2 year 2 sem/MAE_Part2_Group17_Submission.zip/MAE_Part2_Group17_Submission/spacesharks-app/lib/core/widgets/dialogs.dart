import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../utils/validators.dart';

/// Asks for a short text (a note, a reason). Returns null if cancelled.
/// When [required] is true the field must not be empty.
Future<String?> askForText(
  BuildContext context, {
  required String title,
  required String label,
  String hint = '',
  String confirmLabel = 'Send',
  bool required = false,
  int maxLength = 300,
}) {
  final formKey = GlobalKey<FormState>();
  final controller = TextEditingController();
  return showDialog<String>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: Form(
        key: formKey,
        child: TextFormField(
          key: const Key('dialogTextField'),
          controller: controller,
          autofocus: true,
          minLines: 2,
          maxLines: 5,
          maxLength: maxLength,
          decoration: InputDecoration(labelText: label, hintText: hint, errorMaxLines: 2),
          validator: (value) {
            if (required && (value == null || value.trim().isEmpty)) return 'Please write something first.';
            return Validators.maxLength('This', maxLength)(value);
          },
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          key: const Key('dialogConfirm'),
          onPressed: () {
            if (formKey.currentState!.validate()) Navigator.pop(context, controller.text.trim());
          },
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
}

/// Yes/no confirmation. Returns true when confirmed.
Future<bool> confirmAction(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'Confirm',
  bool destructive = false,
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(
          key: const Key('confirmButton'),
          style: destructive ? FilledButton.styleFrom(backgroundColor: AppColors.red) : null,
          onPressed: () => Navigator.pop(context, true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return result ?? false;
}
