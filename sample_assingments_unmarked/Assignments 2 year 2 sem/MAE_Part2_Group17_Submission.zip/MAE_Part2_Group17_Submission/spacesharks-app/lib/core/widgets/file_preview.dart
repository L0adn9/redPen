import 'package:flutter/material.dart';

import '../data/file_storage.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';

/// Sample files bundled with the app (demo data) use this prefix.
const assetPrefix = 'asset://';

/// Shows an uploaded deliverable: the image itself for image files
/// (data URI or https URL), otherwise an icon for videos/documents.
/// ("Intuitive usage of both textual and image based binary data")
class FilePreview extends StatelessWidget {
  const FilePreview({super.key, required this.version, this.height = 180});
  final FileVersion version;
  final double height;

  @override
  Widget build(BuildContext context) {
    Widget child;
    if (version.isImage && version.fileUrl.isNotEmpty) {
      final bytes = bytesFromDataUri(version.fileUrl);
      final url = version.fileUrl;
      child = url.startsWith(assetPrefix)
          ? Image.asset(url.substring(assetPrefix.length), fit: BoxFit.cover,
              errorBuilder: (context, error, stack) => _icon(Icons.broken_image_outlined))
          : bytes != null
          ? Image.memory(bytes, fit: BoxFit.cover, gaplessPlayback: true,
              errorBuilder: (context, error, stack) => _icon(Icons.broken_image_outlined))
          : Image.network(
              version.fileUrl,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stack) => _icon(Icons.broken_image_outlined),
              loadingBuilder: (context, child, progress) =>
                  progress == null ? child : const Center(child: CircularProgressIndicator()),
            );
    } else {
      child = _icon(version.mimeType.startsWith('video/')
          ? Icons.movie_outlined
          : Icons.description_outlined);
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Container(
        height: height,
        width: double.infinity,
        color: AppColors.background,
        child: child,
      ),
    );
  }

  Widget _icon(IconData icon) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 40, color: AppColors.muted),
          const SizedBox(height: 6),
          Text(version.fileName,
              style: const TextStyle(color: AppColors.muted, fontSize: 12)),
        ]),
      );
}
