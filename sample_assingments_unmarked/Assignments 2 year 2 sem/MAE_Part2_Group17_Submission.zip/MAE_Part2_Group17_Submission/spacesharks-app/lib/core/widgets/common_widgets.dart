import 'package:flutter/material.dart';

import '../models/models.dart';
import '../theme/app_theme.dart';

/// Small coloured label: "Approved", "Awaiting approval"...
class StatusChip extends StatelessWidget {
  const StatusChip(this.status, {super.key});
  final TaskStatus status;

  @override
  Widget build(BuildContext context) =>
      Pill(label: status.label, color: AppColors.forStatus(status));
}

class PriorityChip extends StatelessWidget {
  const PriorityChip(this.priority, {super.key});
  final TaskPriority priority;

  @override
  Widget build(BuildContext context) => Pill(
      label: priority.label, color: AppColors.forPriority(priority), outlined: true);
}

class Pill extends StatelessWidget {
  const Pill({super.key, required this.label, required this.color, this.outlined = false, this.icon});
  final String label;
  final Color color;
  final bool outlined;
  final IconData? icon;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: outlined ? null : color.withValues(alpha: 0.14),
          border: outlined ? Border.all(color: color) : null,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[
            Icon(icon, size: 14, color: color),
            const SizedBox(width: 4),
          ],
          Flexible(
            child: Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: color, fontSize: 12, fontWeight: FontWeight.w600)),
          ),
        ]),
      );
}

/// "Build-up" badge in black, used on package cards.
class PhaseBadge extends StatelessWidget {
  const PhaseBadge(this.phase, {super.key});
  final PackagePhase phase;

  @override
  Widget build(BuildContext context) => Pill(
      label: 'Phase ${phase.step}: ${phase.label}',
      color: AppColors.ink,
      icon: Icons.flag_outlined);
}

/// Introduction -> Build-up -> Accelerated progress (CL-UC2, OM-UC6).
class PhaseStepper extends StatelessWidget {
  const PhaseStepper({super.key, required this.current});
  final PackagePhase current;

  @override
  Widget build(BuildContext context) {
    const phases = PackagePhase.values;
    return Row(children: [
      for (var i = 0; i < phases.length; i++) ...[
        Expanded(
          child: Column(children: [
            Container(
              height: 8,
              decoration: BoxDecoration(
                color: phases[i].index <= current.index
                    ? AppColors.orange
                    : AppColors.line,
                borderRadius: BorderRadius.circular(99),
              ),
            ),
            const SizedBox(height: 6),
            Text(phases[i].label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: phases[i] == current ? FontWeight.w700 : FontWeight.w400,
                  color: phases[i].index <= current.index ? AppColors.ink : AppColors.muted,
                )),
          ]),
        ),
        if (i < phases.length - 1) const SizedBox(width: 6),
      ],
    ]);
  }
}

/// Number tile for dashboards: "3  Overdue".
class StatTile extends StatelessWidget {
  const StatTile({super.key, required this.label, required this.value, required this.icon, this.color = AppColors.ink, this.onTap});
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(height: 8),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(value,
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: color)),
              ),
              Text(label,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: AppColors.muted, fontSize: 13, height: 1.25)),
            ]),
          ),
        ),
      );
}

/// Two to four StatTiles side by side, on phones and tablets alike.
class StatRow extends StatelessWidget {
  const StatRow({super.key, required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) => IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          for (var i = 0; i < children.length; i++) ...[
            if (i > 0) const SizedBox(width: 10),
            Expanded(child: children[i]),
          ],
        ]),
      );
}

class SectionHeader extends StatelessWidget {
  const SectionHeader(this.title, {super.key, this.trailing});
  final String title;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(0, 20, 0, 10),
        child: Row(children: [
          Expanded(
            child: Text(title,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          ),
          ?trailing,
        ]),
      );
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.title, this.message});
  final IconData icon;
  final String title;
  final String? message;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 48, color: AppColors.muted),
            const SizedBox(height: 12),
            Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            if (message != null) ...[
              const SizedBox(height: 6),
              Text(message!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.muted)),
            ],
          ]),
        ),
      );
}

class LoadingView extends StatelessWidget {
  const LoadingView({super.key});

  @override
  Widget build(BuildContext context) =>
      const Center(child: CircularProgressIndicator());
}

class ErrorView extends StatelessWidget {
  const ErrorView({super.key, required this.message, this.onRetry});
  final String message;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.error_outline, color: AppColors.red, size: 40),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center),
            if (onRetry != null) ...[
              const SizedBox(height: 12),
              OutlinedButton(onPressed: onRetry, child: const Text('Try again')),
            ],
          ]),
        ),
      );
}

class UserAvatar extends StatelessWidget {
  const UserAvatar({super.key, required this.name, this.radius = 18});
  final String name;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final parts = name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty);
    final initials = parts.take(2).map((p) => p[0].toUpperCase()).join();
    return CircleAvatar(
      radius: radius,
      backgroundColor: AppColors.ink,
      child: Text(initials,
          style: TextStyle(
              color: AppColors.white, fontSize: radius * 0.75, fontWeight: FontWeight.w700)),
    );
  }
}

/// Shows a SnackBar with a message (green for success, red for errors).
void showMessage(BuildContext context, String message, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(message),
      backgroundColor: error ? AppColors.red : AppColors.ink,
      behavior: SnackBarBehavior.floating,
    ));
}
