// Which backend the app uses. Change it without touching code:
//
//   flutter run                                   -> demo mode (fake data)
//   flutter run --dart-define=BACKEND=firebase    -> real Firebase
//   flutter run --dart-define=BACKEND=firebase --dart-define=CLOUD_STORAGE=true
//        -> real Firebase + Cloud Storage for files (needs the Blaze plan)
//
// Everyone builds features in demo mode, so nobody waits for Firebase.
// For the final APK we build with BACKEND=firebase (see README).

enum Backend { demo, firebase }

abstract final class AppConfig {
  static const String _backend =
      String.fromEnvironment('BACKEND', defaultValue: 'demo');

  static Backend get backend =>
      _backend == 'firebase' ? Backend.firebase : Backend.demo;

  /// true: files go to Firebase Cloud Storage. false: files are stored inside
  /// Firestore as data URIs (works on the free Spark plan, max ~700 KB).
  static const bool useCloudStorage =
      bool.fromEnvironment('CLOUD_STORAGE', defaultValue: false);

  static const String appName = 'SPACESHARKS';
  static const String tagline = 'Business Acceleration Firm';
}
