// Form validators. Use them in TextFormField(validator: ...).
// Each returns an error message, or null when the value is fine.
// Unit-tested in test/core/validators_test.dart.

abstract final class Validators {
  static final _email = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

  static String? email(String? value) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) return 'Enter your email.';
    if (!_email.hasMatch(v)) return 'Enter a valid email address.';
    return null;
  }

  static String? password(String? value) {
    final v = value ?? '';
    if (v.isEmpty) return 'Enter your password.';
    if (v.length < 6) return 'Password must be at least 6 characters.';
    return null;
  }

  static String? Function(String?) required(String fieldName) =>
      (value) => (value == null || value.trim().isEmpty)
          ? '$fieldName is required.'
          : null;

  static String? Function(String?) maxLength(String fieldName, int max) =>
      (value) => (value != null && value.trim().length > max)
          ? '$fieldName must be $max characters or fewer.'
          : null;

  /// Whole number between [min] and [max].
  static String? Function(String?) intInRange(
          String fieldName, int min, int max) =>
      (value) {
        final n = int.tryParse(value?.trim() ?? '');
        if (n == null) return '$fieldName must be a number.';
        if (n < min || n > max) return '$fieldName must be $min to $max.';
        return null;
      };

  /// Runs several validators and returns the first error.
  static String? Function(String?) all(
          List<String? Function(String?)> validators) =>
      (value) {
        for (final validator in validators) {
          final error = validator(value);
          if (error != null) return error;
        }
        return null;
      };

  /// For a due date picked in a form: must not be in the past.
  static String? notInPast(DateTime? date, DateTime now) {
    if (date == null) return 'Pick a date.';
    final today = DateTime(now.year, now.month, now.day);
    if (date.isBefore(today)) return 'The date cannot be in the past.';
    return null;
  }
}
