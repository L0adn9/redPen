import 'package:flutter/foundation.dart';

/// A view model can finish an async action (sign in, save, delete) after its
/// screen has already closed, for example when signing in swaps the login
/// screen for the home screen. Notifying then would throw, so after
/// dispose() notifications are simply ignored.
mixin SafeChangeNotifier on ChangeNotifier {
  bool _disposed = false;

  bool get isDisposed => _disposed;

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }
}
