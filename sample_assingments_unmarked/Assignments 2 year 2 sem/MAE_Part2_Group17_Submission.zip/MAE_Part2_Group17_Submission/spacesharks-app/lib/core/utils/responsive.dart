import 'package:flutter/widgets.dart';

/// Mobile adaptive design helpers (marked criterion: "Mobile Adaptive Design").
/// Phones get one column; tablets/landscape get two or three, and content is
/// kept to a readable width.
abstract final class Responsive {
  static const tabletWidth = 600.0;
  static const wideWidth = 900.0;

  static bool isTablet(BuildContext context) =>
      MediaQuery.sizeOf(context).width >= tabletWidth;

  /// 1 on phones, 2 on tablets, 3 on wide screens.
  static int columns(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    if (width >= wideWidth) return 3;
    if (width >= tabletWidth) return 2;
    return 1;
  }
}

/// Centers [child] and limits its width on big screens.
class MaxWidth extends StatelessWidget {
  const MaxWidth({super.key, required this.child, this.maxWidth = 960});
  final Widget child;
  final double maxWidth;

  @override
  Widget build(BuildContext context) => Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: maxWidth),
          child: child,
        ),
      );
}

/// Lays out [children] in a grid with 1/2/3 columns depending on width.
/// Use for cards (packages, tasks, stats).
class AdaptiveGrid extends StatelessWidget {
  const AdaptiveGrid({super.key, required this.children, this.spacing = 12});
  final List<Widget> children;
  final double spacing;

  @override
  Widget build(BuildContext context) {
    final columns = Responsive.columns(context);
    return LayoutBuilder(builder: (context, constraints) {
      final width =
          (constraints.maxWidth - spacing * (columns - 1)) / columns;
      return Wrap(
        spacing: spacing,
        runSpacing: spacing,
        children: [
          for (final child in children) SizedBox(width: width, child: child),
        ],
      );
    });
  }
}
