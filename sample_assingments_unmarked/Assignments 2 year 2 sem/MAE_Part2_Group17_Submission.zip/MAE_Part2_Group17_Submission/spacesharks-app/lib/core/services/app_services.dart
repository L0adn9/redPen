import '../data/auth_repository.dart';
import '../data/doc_store.dart';
import '../data/file_storage.dart';
import '../data/holiday_service.dart';
import '../data/firestore_doc_store.dart';
import '../data/memory_doc_store.dart';
import '../data/repositories.dart';
import '../data/seed_data.dart';

/// Everything a screen or view model needs to read/write data.
/// Get it anywhere with `AppScope.of(context).services`.
class AppServices {
  AppServices({
    required this.store,
    required this.auth,
    required FileStorage fileStorage,
    HolidayService? holidays,
    this.isDemo = false,
  }) : holidays = holidays ?? HolidayService() {
    users = UserRepository(store);
    alerts = AlertRepository(store, users);
    packages = PackageRepository(store);
    tasks = TaskRepository(store, alerts);
    feedback = FeedbackRepository(store, tasks, packages, alerts);
    files = FileRepository(store, fileStorage, alerts);
  }

  final DocStore store;
  final AuthRepository auth;
  final bool isDemo;

  /// Third-party public holidays API (Nager.Date).
  final HolidayService holidays;

  late final UserRepository users;
  late final AlertRepository alerts;
  late final PackageRepository packages;
  late final TaskRepository tasks;
  late final FeedbackRepository feedback;
  late final FileRepository files;

  /// In-memory data, seeded with the demo agency. Used by `flutter run`
  /// and by every test.
  static Future<AppServices> demo({DateTime? now, HolidayService? holidays}) async {
    final store = MemoryDocStore();
    await seedDemoData(store, now: now);
    return AppServices(
      store: store,
      auth: FakeAuthRepository(store),
      fileStorage: const DataUriFileStorage(),
      holidays: holidays,
      isDemo: true,
    );
  }

  /// Real Firebase. Call only after Firebase.initializeApp().
  static AppServices firebase({required bool useCloudStorage}) {
    final store = FirestoreDocStore();
    return AppServices(
      store: store,
      auth: FirebaseAuthRepository(store),
      fileStorage: useCloudStorage
          ? FirebaseFileStorage()
          : const DataUriFileStorage(),
    );
  }

  /// Firebase mode only: creates the demo accounts and data.
  Future<void> loadDemoDataIntoFirebase() async {
    final firebaseAuth = auth;
    if (firebaseAuth is FirebaseAuthRepository) {
      await seedFirebaseDemo(firebaseAuth, store);
    }
  }
}
