import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';

/// A file chosen by the user, ready to upload.
class PickedFile {
  const PickedFile({required this.name, required this.bytes, required this.mimeType});
  final String name;
  final Uint8List bytes;
  final String mimeType;
}

/// Opens the phone's file/gallery picker. Kept in one place so the rest of
/// the app does not depend on the file_picker package directly.
class FilePickerService {
  const FilePickerService();

  Future<PickedFile?> pick() async {
    final file = await FilePicker.pickFile(
      type: FileType.custom,
      allowedExtensions: const ['png', 'jpg', 'jpeg', 'gif', 'webp', 'mp4', 'mov', 'pdf', 'txt', 'doc', 'docx'],
    );
    if (file == null) return null;
    final bytes = await file.readAsBytes();
    return PickedFile(name: file.name, bytes: bytes, mimeType: mimeTypeFor(file.name));
  }
}

/// Works out a MIME type from the file extension.
String mimeTypeFor(String fileName) {
  final dot = fileName.lastIndexOf('.');
  final ext = dot < 0 ? '' : fileName.substring(dot + 1).toLowerCase();
  return switch (ext) {
    'png' => 'image/png',
    'jpg' || 'jpeg' => 'image/jpeg',
    'gif' => 'image/gif',
    'webp' => 'image/webp',
    'mp4' => 'video/mp4',
    'mov' => 'video/quicktime',
    'pdf' => 'application/pdf',
    'txt' => 'text/plain',
    'doc' => 'application/msword',
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    _ => 'application/octet-stream',
  };
}
