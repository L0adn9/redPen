import 'enums.dart';
import 'map_readers.dart';

/// A client's monthly content package. Stored in `packages/{id}`.
class ClientPackage {
  const ClientPackage({
    required this.id,
    required this.clientName,
    required this.clientUserId,
    required this.packageName,
    required this.phase,
    required this.managerId,
    required this.managerName,
    required this.promisedItems,
    required this.startDate,
    this.goals = '',
    this.active = true,
  });

  final String id;
  final String clientName;

  /// The `users` id of the client account that can see this package.
  final String clientUserId;
  final String packageName;
  final PackagePhase phase;
  final String managerId;
  final String managerName;

  /// Number of deliverables promised to the client this month (OM-UC2).
  final int promisedItems;
  final DateTime startDate;
  final String goals;
  final bool active;

  factory ClientPackage.fromMap(String id, Map<String, dynamic> map) =>
      ClientPackage(
        id: id,
        clientName: readString(map['clientName']),
        clientUserId: readString(map['clientUserId']),
        packageName: readString(map['packageName']),
        phase: enumByName(
            PackagePhase.values, map['phase'], PackagePhase.introduction),
        managerId: readString(map['managerId']),
        managerName: readString(map['managerName']),
        promisedItems: readInt(map['promisedItems']),
        startDate: readDate(map['startDate']),
        goals: readString(map['goals']),
        active: readBool(map['active'], true),
      );

  Map<String, dynamic> toMap() => {
        'clientName': clientName,
        'clientUserId': clientUserId,
        'packageName': packageName,
        'phase': phase.name,
        'managerId': managerId,
        'managerName': managerName,
        'promisedItems': promisedItems,
        'startDate': startDate,
        'goals': goals,
        'active': active,
      };

  ClientPackage copyWith({
    String? id,
    String? clientName,
    String? clientUserId,
    String? packageName,
    PackagePhase? phase,
    String? managerId,
    String? managerName,
    int? promisedItems,
    DateTime? startDate,
    String? goals,
    bool? active,
  }) =>
      ClientPackage(
        id: id ?? this.id,
        clientName: clientName ?? this.clientName,
        clientUserId: clientUserId ?? this.clientUserId,
        packageName: packageName ?? this.packageName,
        phase: phase ?? this.phase,
        managerId: managerId ?? this.managerId,
        managerName: managerName ?? this.managerName,
        promisedItems: promisedItems ?? this.promisedItems,
        startDate: startDate ?? this.startDate,
        goals: goals ?? this.goals,
        active: active ?? this.active,
      );
}
