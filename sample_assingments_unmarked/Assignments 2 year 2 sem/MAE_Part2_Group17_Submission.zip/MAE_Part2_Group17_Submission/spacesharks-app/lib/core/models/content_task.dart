import 'enums.dart';
import 'map_readers.dart';

/// One deliverable (post, reel, graphic...) for a client package.
/// Stored in `tasks/{id}`. Staff see these as tasks, clients as deliverables.
class ContentTask {
  const ContentTask({
    required this.id,
    required this.packageId,
    required this.clientName,
    required this.title,
    required this.contentType,
    required this.assigneeId,
    required this.assigneeName,
    required this.dueDate,
    required this.priority,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    this.description = '',
    this.publishDate,
    this.latestVersion = 0,
    this.approvedVersion,
    this.createdById = '',
  });

  final String id;
  final String packageId;
  final String clientName;
  final String title;
  final String description;
  final ContentType contentType;
  final String assigneeId;
  final String assigneeName;
  final DateTime dueDate;

  /// When the client will see it published (weekly content calendar).
  final DateTime? publishDate;
  final TaskPriority priority;
  final TaskStatus status;

  /// Highest uploaded file version number, 0 if nothing uploaded yet.
  final int latestVersion;

  /// The version the client approved as final (CL-UC6).
  final int? approvedVersion;
  final String createdById;
  final DateTime createdAt;
  final DateTime updatedAt;

  bool isOverdue(DateTime now) => status.isOpen && dueDate.isBefore(now);

  bool isDueWithin(DateTime now, Duration window) =>
      !dueDate.isBefore(DateTime(now.year, now.month, now.day)) &&
      dueDate.isBefore(now.add(window));

  /// The date shown on calendars: publish date if set, otherwise due date.
  DateTime get calendarDate => publishDate ?? dueDate;

  factory ContentTask.fromMap(String id, Map<String, dynamic> map) =>
      ContentTask(
        id: id,
        packageId: readString(map['packageId']),
        clientName: readString(map['clientName']),
        title: readString(map['title']),
        description: readString(map['description']),
        contentType:
            enumByName(ContentType.values, map['contentType'], ContentType.post),
        assigneeId: readString(map['assigneeId']),
        assigneeName: readString(map['assigneeName']),
        dueDate: readDate(map['dueDate']),
        publishDate: readDateOrNull(map['publishDate']),
        priority:
            enumByName(TaskPriority.values, map['priority'], TaskPriority.medium),
        status: enumByName(TaskStatus.values, map['status'], TaskStatus.todo),
        latestVersion: readInt(map['latestVersion']),
        approvedVersion: readIntOrNull(map['approvedVersion']),
        createdById: readString(map['createdById']),
        createdAt: readDate(map['createdAt']),
        updatedAt: readDate(map['updatedAt']),
      );

  Map<String, dynamic> toMap() => {
        'packageId': packageId,
        'clientName': clientName,
        'title': title,
        'description': description,
        'contentType': contentType.name,
        'assigneeId': assigneeId,
        'assigneeName': assigneeName,
        'dueDate': dueDate,
        'publishDate': publishDate,
        'priority': priority.name,
        'status': status.name,
        'latestVersion': latestVersion,
        'approvedVersion': approvedVersion,
        'createdById': createdById,
        'createdAt': createdAt,
        'updatedAt': updatedAt,
      };

  ContentTask copyWith({
    String? id,
    String? packageId,
    String? clientName,
    String? title,
    String? description,
    ContentType? contentType,
    String? assigneeId,
    String? assigneeName,
    DateTime? dueDate,
    DateTime? publishDate,
    TaskPriority? priority,
    TaskStatus? status,
    int? latestVersion,
    int? approvedVersion,
    String? createdById,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) =>
      ContentTask(
        id: id ?? this.id,
        packageId: packageId ?? this.packageId,
        clientName: clientName ?? this.clientName,
        title: title ?? this.title,
        description: description ?? this.description,
        contentType: contentType ?? this.contentType,
        assigneeId: assigneeId ?? this.assigneeId,
        assigneeName: assigneeName ?? this.assigneeName,
        dueDate: dueDate ?? this.dueDate,
        publishDate: publishDate ?? this.publishDate,
        priority: priority ?? this.priority,
        status: status ?? this.status,
        latestVersion: latestVersion ?? this.latestVersion,
        approvedVersion: approvedVersion ?? this.approvedVersion,
        createdById: createdById ?? this.createdById,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
}
