import 'enums.dart';
import 'map_readers.dart';

/// A message in a deliverable's feedback thread. Stored in `comments/{id}`.
class TaskComment {
  const TaskComment({
    required this.id,
    required this.taskId,
    required this.packageId,
    required this.authorId,
    required this.authorName,
    required this.authorRole,
    required this.text,
    required this.createdAt,
    this.seenByAgency = false,
    this.seenAt,
  });

  final String id;
  final String taskId;
  final String packageId;
  final String authorId;
  final String authorName;
  final UserRole authorRole;
  final String text;
  final DateTime createdAt;

  /// For client comments: has someone at the agency read it? (CL-UC7)
  final bool seenByAgency;
  final DateTime? seenAt;

  bool get isFromClient => authorRole == UserRole.client;

  factory TaskComment.fromMap(String id, Map<String, dynamic> map) =>
      TaskComment(
        id: id,
        taskId: readString(map['taskId']),
        packageId: readString(map['packageId']),
        authorId: readString(map['authorId']),
        authorName: readString(map['authorName']),
        authorRole:
            enumByName(UserRole.values, map['authorRole'], UserRole.client),
        text: readString(map['text']),
        createdAt: readDate(map['createdAt']),
        seenByAgency: readBool(map['seenByAgency']),
        seenAt: readDateOrNull(map['seenAt']),
      );

  Map<String, dynamic> toMap() => {
        'taskId': taskId,
        'packageId': packageId,
        'authorId': authorId,
        'authorName': authorName,
        'authorRole': authorRole.name,
        'text': text,
        'createdAt': createdAt,
        'seenByAgency': seenByAgency,
        'seenAt': seenAt,
      };
}

/// A timestamped client decision on one version of a deliverable.
/// Stored in `approvals/{id}` (OM-UC5, CL-UC5, ST-UC7).
class Approval {
  const Approval({
    required this.id,
    required this.taskId,
    required this.packageId,
    required this.decision,
    required this.byUserId,
    required this.byName,
    required this.versionNumber,
    required this.createdAt,
    this.note = '',
  });

  final String id;
  final String taskId;
  final String packageId;
  final ApprovalDecision decision;
  final String byUserId;
  final String byName;
  final int versionNumber;
  final String note;
  final DateTime createdAt;

  factory Approval.fromMap(String id, Map<String, dynamic> map) => Approval(
        id: id,
        taskId: readString(map['taskId']),
        packageId: readString(map['packageId']),
        decision: enumByName(ApprovalDecision.values, map['decision'],
            ApprovalDecision.changesRequested),
        byUserId: readString(map['byUserId']),
        byName: readString(map['byName']),
        versionNumber: readInt(map['versionNumber']),
        note: readString(map['note']),
        createdAt: readDate(map['createdAt']),
      );

  Map<String, dynamic> toMap() => {
        'taskId': taskId,
        'packageId': packageId,
        'decision': decision.name,
        'byUserId': byUserId,
        'byName': byName,
        'versionNumber': versionNumber,
        'note': note,
        'createdAt': createdAt,
      };
}
