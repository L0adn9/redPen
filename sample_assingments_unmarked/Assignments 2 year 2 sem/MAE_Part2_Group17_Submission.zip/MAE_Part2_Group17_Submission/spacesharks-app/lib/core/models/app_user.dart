import 'enums.dart';
import 'map_readers.dart';

/// A signed-in person. Stored in `users/{uid}`; the document id is the
/// Firebase Auth uid, and [role] decides which home screen they see.
class AppUser {
  const AppUser({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    this.jobTitle = '',
    this.company = '',
  });

  final String id;
  final String name;
  final String email;
  final UserRole role;

  /// Staff only, e.g. "Graphic Designer".
  final String jobTitle;

  /// Client only, e.g. "Kopi Kita Cafe".
  final String company;

  String get initials {
    final parts = name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty);
    return parts.take(2).map((p) => p[0].toUpperCase()).join();
  }

  factory AppUser.fromMap(String id, Map<String, dynamic> map) => AppUser(
        id: id,
        name: readString(map['name']),
        email: readString(map['email']),
        role: enumByName(UserRole.values, map['role'], UserRole.client),
        jobTitle: readString(map['jobTitle']),
        company: readString(map['company']),
      );

  Map<String, dynamic> toMap() => {
        'name': name,
        'email': email,
        'role': role.name,
        'jobTitle': jobTitle,
        'company': company,
      };

  @override
  bool operator ==(Object other) => other is AppUser && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
