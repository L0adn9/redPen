// Small helpers so every model reads Firestore/demo maps the same way.
// The data layer already turns Firestore Timestamps into DateTime.

DateTime readDate(Object? value, {DateTime? fallback}) =>
    readDateOrNull(value) ?? fallback ?? DateTime.fromMillisecondsSinceEpoch(0);

DateTime? readDateOrNull(Object? value) {
  if (value is DateTime) return value;
  if (value is int) return DateTime.fromMillisecondsSinceEpoch(value);
  if (value is String) return DateTime.tryParse(value);
  return null;
}

String readString(Object? value, [String fallback = '']) =>
    value is String ? value : (value?.toString() ?? fallback);

String? readStringOrNull(Object? value) =>
    value == null ? null : readString(value);

int readInt(Object? value, [int fallback = 0]) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.tryParse(value) ?? fallback;
  return fallback;
}

int? readIntOrNull(Object? value) => value == null ? null : readInt(value);

bool readBool(Object? value, [bool fallback = false]) =>
    value is bool ? value : fallback;
