// Shared enums for every role. Owned by: Hassan (core). Change only via a PR to main.

/// Reads an enum value from its stored name, falling back when the value is
/// missing or unknown (for example an old document in Firestore).
T enumByName<T extends Enum>(List<T> values, Object? name, T fallback) {
  for (final value in values) {
    if (value.name == name) return value;
  }
  return fallback;
}

enum UserRole {
  owner('Owner / Manager'),
  staff('Content Creator / Staff'),
  client('Client');

  const UserRole(this.label);
  final String label;
}

/// SPACESHARKS engagement phases (proposal: Introduction, Build-up, Accelerated).
enum PackagePhase {
  introduction('Introduction'),
  buildUp('Build-up'),
  accelerated('Accelerated');

  const PackagePhase(this.label);
  final String label;

  /// 1, 2 or 3, used for progress steppers.
  int get step => index + 1;
}

enum TaskStatus {
  todo('To do'),
  inProgress('In progress'),
  awaitingApproval('Awaiting approval'),
  changesRequested('Changes requested'),
  approved('Approved');

  const TaskStatus(this.label);
  final String label;

  bool get isOpen => this != TaskStatus.approved;
}

enum TaskPriority {
  high('High'),
  medium('Medium'),
  low('Low');

  const TaskPriority(this.label);
  final String label;
}

enum ContentType {
  post('Post'),
  reel('Reel'),
  graphic('Graphic'),
  story('Story'),
  caption('Caption');

  const ContentType(this.label);
  final String label;
}

enum ApprovalDecision {
  approved('Approved'),
  changesRequested('Changes requested');

  const ApprovalDecision(this.label);
  final String label;
}

enum AlertType {
  overdue('Overdue'),
  approvalNeeded('Approval needed'),
  newTask('New task'),
  taskChanged('Task changed'),
  statusRequest('Status request'),
  feedback('Feedback'),
  handover('Handover'),
  overload('Overload flag'),
  general('Notice');

  const AlertType(this.label);
  final String label;
}
