import 'enums.dart';
import 'map_readers.dart';

/// An in-app notification for one user. Stored in `alerts/{id}`.
/// (Replaces push notifications: OM-UC3, ST-UC2, CL-UC8.)
class AppAlert {
  const AppAlert({
    required this.id,
    required this.userId,
    required this.type,
    required this.title,
    required this.body,
    required this.createdAt,
    this.taskId,
    this.packageId,
    this.fromUserId,
    this.read = false,
  });

  final String id;

  /// Who receives the alert.
  final String userId;
  final AlertType type;
  final String title;
  final String body;
  final String? taskId;
  final String? packageId;
  final String? fromUserId;
  final bool read;
  final DateTime createdAt;

  factory AppAlert.fromMap(String id, Map<String, dynamic> map) => AppAlert(
        id: id,
        userId: readString(map['userId']),
        type: enumByName(AlertType.values, map['type'], AlertType.general),
        title: readString(map['title']),
        body: readString(map['body']),
        taskId: readStringOrNull(map['taskId']),
        packageId: readStringOrNull(map['packageId']),
        fromUserId: readStringOrNull(map['fromUserId']),
        read: readBool(map['read']),
        createdAt: readDate(map['createdAt']),
      );

  Map<String, dynamic> toMap() => {
        'userId': userId,
        'type': type.name,
        'title': title,
        'body': body,
        'taskId': taskId,
        'packageId': packageId,
        'fromUserId': fromUserId,
        'read': read,
        'createdAt': createdAt,
      };
}
