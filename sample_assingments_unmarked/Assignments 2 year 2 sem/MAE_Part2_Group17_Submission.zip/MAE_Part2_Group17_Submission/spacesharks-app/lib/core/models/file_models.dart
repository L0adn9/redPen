import 'map_readers.dart';

/// One uploaded file version of a deliverable. Stored in `versions/{id}`
/// (ST-UC5). [fileUrl] is either an https download URL (Firebase Storage)
/// or a `data:` URI (demo mode / Firestore-inline storage).
class FileVersion {
  const FileVersion({
    required this.id,
    required this.taskId,
    required this.versionNumber,
    required this.fileName,
    required this.fileUrl,
    required this.mimeType,
    required this.sizeBytes,
    required this.uploadedById,
    required this.uploadedByName,
    required this.createdAt,
    this.note = '',
  });

  final String id;
  final String taskId;
  final int versionNumber;
  final String fileName;
  final String fileUrl;
  final String mimeType;
  final int sizeBytes;
  final String uploadedById;
  final String uploadedByName;
  final String note;
  final DateTime createdAt;

  bool get isImage => mimeType.startsWith('image/');

  factory FileVersion.fromMap(String id, Map<String, dynamic> map) =>
      FileVersion(
        id: id,
        taskId: readString(map['taskId']),
        versionNumber: readInt(map['versionNumber']),
        fileName: readString(map['fileName']),
        fileUrl: readString(map['fileUrl']),
        mimeType: readString(map['mimeType'], 'application/octet-stream'),
        sizeBytes: readInt(map['sizeBytes']),
        uploadedById: readString(map['uploadedById']),
        uploadedByName: readString(map['uploadedByName']),
        note: readString(map['note']),
        createdAt: readDate(map['createdAt']),
      );

  Map<String, dynamic> toMap() => {
        'taskId': taskId,
        'versionNumber': versionNumber,
        'fileName': fileName,
        'fileUrl': fileUrl,
        'mimeType': mimeType,
        'sizeBytes': sizeBytes,
        'uploadedById': uploadedById,
        'uploadedByName': uploadedByName,
        'note': note,
        'createdAt': createdAt,
      };
}

/// A file handed from one staff member to another. Stored in `handovers/{id}`
/// (ST-UC6, OM-UC7). [receivedAt] is null until the receiver confirms.
class Handover {
  const Handover({
    required this.id,
    required this.taskId,
    required this.taskTitle,
    required this.fromUserId,
    required this.fromName,
    required this.toUserId,
    required this.toName,
    required this.versionNumber,
    required this.sentAt,
    this.note = '',
    this.receivedAt,
  });

  final String id;
  final String taskId;
  final String taskTitle;
  final String fromUserId;
  final String fromName;
  final String toUserId;
  final String toName;
  final int versionNumber;
  final String note;
  final DateTime sentAt;
  final DateTime? receivedAt;

  bool get isReceived => receivedAt != null;

  factory Handover.fromMap(String id, Map<String, dynamic> map) => Handover(
        id: id,
        taskId: readString(map['taskId']),
        taskTitle: readString(map['taskTitle']),
        fromUserId: readString(map['fromUserId']),
        fromName: readString(map['fromName']),
        toUserId: readString(map['toUserId']),
        toName: readString(map['toName']),
        versionNumber: readInt(map['versionNumber']),
        note: readString(map['note']),
        sentAt: readDate(map['sentAt']),
        receivedAt: readDateOrNull(map['receivedAt']),
      );

  Map<String, dynamic> toMap() => {
        'taskId': taskId,
        'taskTitle': taskTitle,
        'fromUserId': fromUserId,
        'fromName': fromName,
        'toUserId': toUserId,
        'toName': toName,
        'versionNumber': versionNumber,
        'note': note,
        'sentAt': sentAt,
        'receivedAt': receivedAt,
      };
}
