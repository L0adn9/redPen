import 'dart:async';

import 'package:flutter/foundation.dart';

import '../data/auth_repository.dart';
import '../models/models.dart';
import '../utils/safe_notifier.dart';

/// Who is signed in. The AuthGate listens to this to pick the role's home.
class SessionViewModel extends ChangeNotifier with SafeChangeNotifier {
  SessionViewModel(this._auth) {
    _sub = _auth.authStateChanges().listen((user) {
      _user = user;
      _ready = true;
      notifyListeners();
    });
  }

  final AuthRepository _auth;
  late final StreamSubscription<AppUser?> _sub;
  AppUser? _user;
  bool _ready = false;

  AppUser? get user => _user;

  /// Use inside role screens, where someone is always signed in.
  AppUser get requireUser => _user!;
  bool get isReady => _ready;
  bool get isSignedIn => _user != null;

  Future<void> signOut() => _auth.signOut();

  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }
}
