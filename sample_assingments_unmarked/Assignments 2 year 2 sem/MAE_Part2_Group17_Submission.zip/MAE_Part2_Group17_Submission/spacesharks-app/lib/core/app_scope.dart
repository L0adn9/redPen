import 'package:flutter/widgets.dart';

import 'models/models.dart';
import 'services/app_services.dart';
import 'session/session_view_model.dart';

/// Makes the services and the session available to every screen:
///
///   final scope = AppScope.of(context);
///   scope.services.tasks.watchForAssignee(scope.user.id)
class AppScope extends InheritedWidget {
  const AppScope({
    super.key,
    required this.services,
    required this.session,
    required super.child,
  });

  final AppServices services;
  final SessionViewModel session;

  /// The signed-in user. Only call inside role screens.
  AppUser get user => session.requireUser;

  static AppScope of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'No AppScope above this widget.');
    return scope!;
  }

  @override
  bool updateShouldNotify(AppScope oldWidget) =>
      services != oldWidget.services || session != oldWidget.session;
}
