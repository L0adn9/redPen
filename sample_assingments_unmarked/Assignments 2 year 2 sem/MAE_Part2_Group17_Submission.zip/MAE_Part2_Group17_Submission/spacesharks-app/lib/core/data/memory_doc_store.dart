import 'dart:async';

import 'doc_store.dart';

/// In-memory database used in demo mode and in tests.
/// Behaves like Firestore: watchers get a new list whenever data changes.
class MemoryDocStore implements DocStore {
  final Map<String, Map<String, Map<String, dynamic>>> _data = {};
  final StreamController<void> _changes = StreamController<void>.broadcast();
  int _counter = 0;

  Map<String, Map<String, dynamic>> _col(String name) =>
      _data.putIfAbsent(name, () => <String, Map<String, dynamic>>{});

  List<Doc> _query(String collection, String? whereField, Object? isEqualTo) {
    return _col(collection)
        .entries
        .where((e) => whereField == null || e.value[whereField] == isEqualTo)
        .map((e) => Doc(e.key, Map<String, dynamic>.of(e.value)))
        .toList();
  }

  Doc? _get(String collection, String id) {
    final data = _col(collection)[id];
    return data == null ? null : Doc(id, Map<String, dynamic>.of(data));
  }

  Stream<T> _watch<T>(T Function() read) {
    late final StreamController<T> controller;
    StreamSubscription<void>? sub;
    controller = StreamController<T>(
      onListen: () {
        controller.add(read());
        sub = _changes.stream.listen((_) {
          if (!controller.isClosed) controller.add(read());
        });
      },
      onCancel: () => sub?.cancel(),
    );
    return controller.stream;
  }

  void _notify() => _changes.add(null);

  @override
  Stream<List<Doc>> watchCollection(String collection,
          {String? whereField, Object? isEqualTo}) =>
      _watch(() => _query(collection, whereField, isEqualTo));

  @override
  Stream<Doc?> watchDoc(String collection, String id) =>
      _watch(() => _get(collection, id));

  @override
  Future<List<Doc>> getCollection(String collection,
          {String? whereField, Object? isEqualTo}) async =>
      _query(collection, whereField, isEqualTo);

  @override
  Future<Doc?> getDoc(String collection, String id) async =>
      _get(collection, id);

  @override
  Future<String> add(String collection, Map<String, dynamic> data) async {
    final id = '${collection}_${++_counter}';
    _col(collection)[id] = Map<String, dynamic>.of(data);
    _notify();
    return id;
  }

  @override
  Future<void> set(
      String collection, String id, Map<String, dynamic> data) async {
    _col(collection)[id] = Map<String, dynamic>.of(data);
    _notify();
  }

  @override
  Future<void> update(
      String collection, String id, Map<String, dynamic> data) async {
    final existing = _col(collection)[id];
    if (existing == null) {
      throw StoreException('No document $collection/$id to update.');
    }
    existing.addAll(data);
    _notify();
  }

  @override
  Future<void> delete(String collection, String id) async {
    _col(collection).remove(id);
    _notify();
  }

  /// Number of documents in a collection (handy in tests).
  int count(String collection) => _col(collection).length;
}
