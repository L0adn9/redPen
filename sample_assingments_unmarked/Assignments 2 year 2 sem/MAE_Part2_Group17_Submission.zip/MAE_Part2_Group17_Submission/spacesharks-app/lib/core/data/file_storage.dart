import 'dart:convert';
import 'dart:typed_data';

import 'package:firebase_storage/firebase_storage.dart';

/// Where uploaded deliverable files (images, videos, captions) go.
abstract class FileStorage {
  /// Saves [bytes] and returns a URL the app can display or open later.
  Future<String> upload({
    required String path,
    required Uint8List bytes,
    required String mimeType,
  });
}

class FileTooLargeException implements Exception {
  const FileTooLargeException(this.maxBytes);
  final int maxBytes;

  @override
  String toString() =>
      'File is too large. Please choose a file under ${maxBytes ~/ 1024} KB.';
}

/// Keeps the file inside the database as a `data:` URI.
/// Used in demo mode, and in Firebase mode when the project has no
/// Cloud Storage bucket (Storage needs the Blaze plan on new projects).
/// Firestore documents max out at 1 MB, so files are limited to ~700 KB.
class DataUriFileStorage implements FileStorage {
  const DataUriFileStorage({this.maxBytes = 700 * 1024});
  final int maxBytes;

  @override
  Future<String> upload({
    required String path,
    required Uint8List bytes,
    required String mimeType,
  }) async {
    if (bytes.length > maxBytes) throw FileTooLargeException(maxBytes);
    return 'data:$mimeType;base64,${base64Encode(bytes)}';
  }
}

/// Firebase Cloud Storage. Owned by: Kaung / Muntasir.
class FirebaseFileStorage implements FileStorage {
  FirebaseFileStorage([FirebaseStorage? storage])
      : _storage = storage ?? FirebaseStorage.instance;

  final FirebaseStorage _storage;

  @override
  Future<String> upload({
    required String path,
    required Uint8List bytes,
    required String mimeType,
  }) async {
    final ref = _storage.ref().child(path);
    final snapshot = await ref.putData(bytes, SettableMetadata(contentType: mimeType));
    return snapshot.ref.getDownloadURL();
  }
}

/// Decodes a `data:` URI back into bytes (null for normal URLs).
Uint8List? bytesFromDataUri(String url) {
  if (!url.startsWith('data:')) return null;
  final comma = url.indexOf(',');
  if (comma < 0) return null;
  return base64Decode(url.substring(comma + 1));
}
