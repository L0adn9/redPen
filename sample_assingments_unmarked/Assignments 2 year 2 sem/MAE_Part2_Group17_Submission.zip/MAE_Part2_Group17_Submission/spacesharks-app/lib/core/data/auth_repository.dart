import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';

import '../models/models.dart';
import 'doc_store.dart';

class AuthException implements Exception {
  const AuthException(this.message);
  final String message;

  @override
  String toString() => message;
}

/// Login for all three roles (one login screen, role decides the home page).
abstract class AuthRepository {
  /// Emits the signed-in user (with role) or null when signed out.
  Stream<AppUser?> authStateChanges();

  Future<AppUser> signIn({required String email, required String password});

  Future<void> signOut();
}

/// Demo-mode login against the seeded `users` collection.
/// Every demo account uses the password [demoPassword].
class FakeAuthRepository implements AuthRepository {
  FakeAuthRepository(this._store);

  static const demoPassword = 'password123';

  final DocStore _store;
  final StreamController<AppUser?> _controller =
      StreamController<AppUser?>.broadcast();
  AppUser? _current;

  @override
  Stream<AppUser?> authStateChanges() async* {
    yield _current;
    yield* _controller.stream;
  }

  @override
  Future<AppUser> signIn(
      {required String email, required String password}) async {
    final matches = await _store.getCollection(Collections.users,
        whereField: 'email', isEqualTo: email.trim().toLowerCase());
    if (matches.isEmpty || password != demoPassword) {
      throw const AuthException('Incorrect email or password.');
    }
    final user = AppUser.fromMap(matches.first.id, matches.first.data);
    _current = user;
    _controller.add(user);
    return user;
  }

  @override
  Future<void> signOut() async {
    _current = null;
    _controller.add(null);
  }
}

/// Firebase Authentication + the `users/{uid}` profile for the role.
/// Owned by: Kaung (Firebase).
class FirebaseAuthRepository implements AuthRepository {
  FirebaseAuthRepository(this._store, [FirebaseAuth? auth])
      : _auth = auth ?? FirebaseAuth.instance;

  final DocStore _store;
  final FirebaseAuth _auth;

  Future<AppUser?> _profile(String uid) async {
    final doc = await _store.getDoc(Collections.users, uid);
    return doc == null ? null : AppUser.fromMap(doc.id, doc.data);
  }

  @override
  Stream<AppUser?> authStateChanges() => _auth
      .authStateChanges()
      .asyncMap((user) async => user == null ? null : _profile(user.uid));

  @override
  Future<AppUser> signIn(
      {required String email, required String password}) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
          email: email.trim(), password: password);
      final uid = credential.user?.uid;
      final profile = uid == null ? null : await _profile(uid);
      if (profile == null) {
        await _auth.signOut();
        throw const AuthException(
            'This account has no SPACESHARKS profile yet. Ask the owner to add you.');
      }
      return profile;
    } on FirebaseAuthException catch (e) {
      throw AuthException(_message(e.code));
    }
  }

  /// Creates a Firebase Auth account and its profile (used by the demo-data
  /// seeder). Returns the new uid, or signs in and returns the existing uid.
  Future<String> ensureAccount(AppUser profile, String password) async {
    String uid;
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
          email: profile.email, password: password);
      uid = credential.user!.uid;
    } on FirebaseAuthException catch (e) {
      if (e.code != 'email-already-in-use') rethrow;
      final credential = await _auth.signInWithEmailAndPassword(
          email: profile.email, password: password);
      uid = credential.user!.uid;
    }
    await _store.set(Collections.users, uid, profile.toMap());
    return uid;
  }

  @override
  Future<void> signOut() => _auth.signOut();

  static String _message(String code) => switch (code) {
        'invalid-email' => 'That email address is not valid.',
        'user-disabled' => 'This account has been disabled.',
        'too-many-requests' => 'Too many attempts. Please wait and try again.',
        'network-request-failed' => 'No internet connection.',
        _ => 'Incorrect email or password.',
      };
}
