// Demo data so every screen has something real to show from day one.
// Used automatically in demo mode, and by the "Load demo data" button in
// Firebase mode (creates the demo accounts in Firebase Auth too).
//
// Demo logins (password for all: password123):
//   owner@spacesharks.test      Owner / Manager
//   designer@spacesharks.test   Staff (Graphic Designer)
//   editor@spacesharks.test     Staff (Video Editor)
//   writer@spacesharks.test     Staff (Copywriter)
//   client@kopikita.test        Client (Kopi Kita Cafe)
//   client@glowskin.test        Client (Glow Skin Studio)
//   client@urbanfit.test        Client (UrbanFit Gym)

import '../models/models.dart';
import 'auth_repository.dart';
import 'doc_store.dart';

/// Demo accounts. The [AppUser.id] here is a key; the real id comes from
/// Firebase Auth in Firebase mode.
const demoAccounts = <AppUser>[
  AppUser(id: 'owner', name: 'Farid Rahman', email: 'owner@spacesharks.test', role: UserRole.owner, jobTitle: 'Managing Partner'),
  AppUser(id: 'designer', name: 'Nurul Aina', email: 'designer@spacesharks.test', role: UserRole.staff, jobTitle: 'Graphic Designer'),
  AppUser(id: 'editor', name: 'Daniel Lim', email: 'editor@spacesharks.test', role: UserRole.staff, jobTitle: 'Video Editor'),
  AppUser(id: 'writer', name: 'Priya Nair', email: 'writer@spacesharks.test', role: UserRole.staff, jobTitle: 'Copywriter'),
  AppUser(id: 'kopikita', name: 'Hafiz Osman', email: 'client@kopikita.test', role: UserRole.client, company: 'Kopi Kita Cafe'),
  AppUser(id: 'glowskin', name: 'Mei Ling Tan', email: 'client@glowskin.test', role: UserRole.client, company: 'Glow Skin Studio'),
  AppUser(id: 'urbanfit', name: 'Arif Hakim', email: 'client@urbanfit.test', role: UserRole.client, company: 'UrbanFit Gym'),
];

/// Writes the demo data. [ids] maps each demo key (e.g. 'designer') to the
/// real user id. Uses fixed document ids, so running it twice is safe.
/// Sample images bundled in assets/samples (shown by FilePreview).
String _sample(String name) => 'asset://assets/samples/$name.jpg';

Future<void> seedDemoData(DocStore store,
    {Map<String, String>? ids, DateTime? now}) async {
  final today = now ?? DateTime.now();
  String id(String key) => ids?[key] ?? key;
  AppUser user(String key) => demoAccounts.firstWhere((u) => u.id == key);
  DateTime day(int offset, [int hour = 17]) =>
      DateTime(today.year, today.month, today.day + offset, hour);

  for (final account in demoAccounts) {
    await store.set(Collections.users, id(account.id), account.toMap());
  }

  final owner = user('owner');
  final packages = {
    'pkg_kopikita': ClientPackage(id: 'pkg_kopikita', clientName: 'Kopi Kita Cafe', clientUserId: id('kopikita'), packageName: 'Growth Monthly', phase: PackagePhase.buildUp, managerId: id('owner'), managerName: owner.name, promisedItems: 12, startDate: day(-40), goals: 'Grow weekday foot traffic with a new seasonal menu.'),
    'pkg_glowskin': ClientPackage(id: 'pkg_glowskin', clientName: 'Glow Skin Studio', clientUserId: id('glowskin'), packageName: 'Starter Monthly', phase: PackagePhase.introduction, managerId: id('owner'), managerName: owner.name, promisedItems: 8, startDate: day(-10), goals: 'Introduce the brand and build trust with first-time customers.'),
    'pkg_urbanfit': ClientPackage(id: 'pkg_urbanfit', clientName: 'UrbanFit Gym', clientUserId: id('urbanfit'), packageName: 'Accelerator Monthly', phase: PackagePhase.accelerated, managerId: id('owner'), managerName: owner.name, promisedItems: 16, startDate: day(-95), goals: 'Convert trial members into yearly memberships.'),
  };
  for (final entry in packages.entries) {
    await store.set(Collections.packages, entry.key, entry.value.toMap());
  }

  ContentTask task(String taskId, String pkg, String title, ContentType type,
          String staffKey, int due, TaskPriority priority, TaskStatus status,
          {int latest = 0, int? approved, int? publish, String description = ''}) =>
      ContentTask(
        id: taskId,
        packageId: pkg,
        clientName: packages[pkg]!.clientName,
        title: title,
        description: description,
        contentType: type,
        assigneeId: id(staffKey),
        assigneeName: user(staffKey).name,
        dueDate: day(due),
        publishDate: publish == null ? null : day(publish, 10),
        priority: priority,
        status: status,
        latestVersion: latest,
        approvedVersion: approved,
        createdById: id('owner'),
        createdAt: day(-14),
        updatedAt: day(-1),
      );

  final tasks = [
    task('task_1', 'pkg_kopikita', 'Pumpkin latte launch post', ContentType.graphic, 'designer', -2, TaskPriority.high, TaskStatus.inProgress, latest: 1, publish: 1, description: 'Square post for the seasonal latte. Use the orange brand colour.'),
    task('task_2', 'pkg_kopikita', 'Barista day reel', ContentType.reel, 'editor', 1, TaskPriority.high, TaskStatus.awaitingApproval, latest: 2, publish: 3, description: '30-second reel showing a day behind the counter.'),
    task('task_3', 'pkg_kopikita', 'Weekend promo caption', ContentType.caption, 'writer', 2, TaskPriority.medium, TaskStatus.todo, publish: 4),
    task('task_4', 'pkg_kopikita', 'New menu carousel', ContentType.post, 'designer', -5, TaskPriority.medium, TaskStatus.approved, latest: 1, approved: 1, publish: -3),
    task('task_5', 'pkg_kopikita', 'Customer story', ContentType.story, 'editor', 5, TaskPriority.medium, TaskStatus.changesRequested, latest: 1, publish: 6),
    task('task_6', 'pkg_glowskin', 'Brand introduction post', ContentType.post, 'designer', 0, TaskPriority.high, TaskStatus.awaitingApproval, latest: 1, publish: 2),
    task('task_7', 'pkg_glowskin', 'Skincare routine reel', ContentType.reel, 'editor', 4, TaskPriority.medium, TaskStatus.todo, publish: 5),
    task('task_8', 'pkg_glowskin', 'Welcome caption set', ContentType.caption, 'writer', -1, TaskPriority.high, TaskStatus.inProgress, publish: 1),
    task('task_9', 'pkg_urbanfit', 'Member transformation reel', ContentType.reel, 'editor', 2, TaskPriority.high, TaskStatus.inProgress, publish: 3),
    task('task_10', 'pkg_urbanfit', 'Class schedule graphic', ContentType.graphic, 'designer', 3, TaskPriority.low, TaskStatus.todo, publish: 4),
    task('task_11', 'pkg_urbanfit', 'Member spotlight post', ContentType.post, 'writer', 6, TaskPriority.low, TaskStatus.todo, publish: 7),
    task('task_12', 'pkg_urbanfit', 'Merdeka challenge story', ContentType.story, 'designer', -8, TaskPriority.medium, TaskStatus.approved, latest: 2, approved: 2, publish: -6),
  ];
  for (final t in tasks) {
    await store.set(Collections.tasks, t.id, t.toMap());
  }

  // Delivered earlier this month, so "promised vs delivered", the health
  // indicator and the client's approved library have real history.
  const history = {
    'pkg_kopikita': ['Monday coffee tip', 'Behind the bar story', 'Iced latte reel', 'Loyalty card post', 'Pastry of the week', 'Rainy day promo'],
    'pkg_glowskin': ['Meet the therapist', 'Opening hours graphic'],
    'pkg_urbanfit': ['HIIT class teaser', 'Coach spotlight', 'Protein shake post', 'Members of the month', 'Leg day reel', 'Yoga Sunday graphic', 'Open gym hours', 'Nutrition tip carousel', 'Challenge leaderboard', 'Recovery tips story', 'New equipment reel', 'Testimonial post'],
  };
  const staffKeys = ['designer', 'editor', 'writer'];
  const samplesFor = {
    'pkg_kopikita': ['cafe_latte', 'cafe_menu', 'cafe_barista'],
    'pkg_glowskin': ['glow_intro', 'glow_routine'],
    'pkg_urbanfit': ['gym_hiit', 'gym_member'],
  };
  const types = [ContentType.post, ContentType.reel, ContentType.graphic, ContentType.story];
  var n = 0;
  for (final entry in history.entries) {
    for (var i = 0; i < entry.value.length; i++) {
      n++;
      final taskId = 'hist_$n';
      final staffKey = staffKeys[n % 3];
      final due = -3 - (i * 22 ~/ entry.value.length);
      final client = entry.key == 'pkg_kopikita' ? 'kopikita' : entry.key == 'pkg_glowskin' ? 'glowskin' : 'urbanfit';
      final t = task(taskId, entry.key, entry.value[i], types[n % types.length], staffKey, due,
          TaskPriority.medium, TaskStatus.approved, latest: 1, approved: 1, publish: due + 1);
      await store.set(Collections.tasks, taskId, t.toMap());
      await store.set(
          Collections.versions,
          'hver_$n',
          FileVersion(id: 'hver_$n', taskId: taskId, versionNumber: 1, fileName: '${taskId}_final.jpg', fileUrl: _sample(samplesFor[entry.key]![i % samplesFor[entry.key]!.length]), mimeType: 'image/jpeg', sizeBytes: 27000, uploadedById: id(staffKey), uploadedByName: user(staffKey).name, createdAt: day(due - 1, 11))
              .toMap());
      await store.set(
          Collections.approvals,
          'hapr_$n',
          Approval(id: 'hapr_$n', taskId: taskId, packageId: entry.key, decision: ApprovalDecision.approved, byUserId: id(client), byName: user(client).name, versionNumber: 1, createdAt: day(due, 15))
              .toMap());
    }
  }

  Future<void> version(String docId, String taskId, int n, String staffKey,
      String fileName, String mime, String url, int ago) async {
    await store.set(
        Collections.versions,
        docId,
        FileVersion(id: docId, taskId: taskId, versionNumber: n, fileName: fileName, fileUrl: url, mimeType: mime, sizeBytes: url.length, uploadedById: id(staffKey), uploadedByName: user(staffKey).name, createdAt: day(-ago, 11))
            .toMap());
  }

  await version('ver_1', 'task_1', 1, 'designer', 'latte_post_v1.jpg', 'image/jpeg', _sample('cafe_latte'), 2);
  await version('ver_2', 'task_2', 1, 'editor', 'barista_reel_v1.mp4', 'video/mp4', '', 4);
  await version('ver_3', 'task_2', 2, 'editor', 'barista_reel_v2.mp4', 'video/mp4', '', 1);
  await version('ver_4', 'task_4', 1, 'designer', 'menu_carousel.jpg', 'image/jpeg', _sample('cafe_menu'), 6);
  await version('ver_5', 'task_5', 1, 'editor', 'customer_story_v1.jpg', 'image/jpeg', _sample('cafe_barista'), 2);
  await version('ver_6', 'task_6', 1, 'designer', 'brand_intro_v1.jpg', 'image/jpeg', _sample('glow_intro'), 1);
  await version('ver_7', 'task_12', 1, 'designer', 'merdeka_v1.jpg', 'image/jpeg', _sample('gym_hiit'), 11);
  await version('ver_8', 'task_12', 2, 'designer', 'merdeka_v2.jpg', 'image/jpeg', _sample('gym_member'), 9);

  Future<void> comment(String docId, String taskId, String pkg, String key,
      String text, int ago, {bool seen = false}) async {
    final author = user(key);
    await store.set(
        Collections.comments,
        docId,
        TaskComment(id: docId, taskId: taskId, packageId: pkg, authorId: id(key), authorName: author.name, authorRole: author.role, text: text, createdAt: day(-ago, 9), seenByAgency: seen, seenAt: seen ? day(-ago, 12) : null)
            .toMap());
  }

  await comment('com_1', 'task_2', 'pkg_kopikita', 'kopikita', 'Can the reel open with the latte art shot?', 3, seen: true);
  await comment('com_2', 'task_2', 'pkg_kopikita', 'editor', 'Yes, done in version 2. Please have a look.', 1);
  await comment('com_3', 'task_5', 'pkg_kopikita', 'kopikita', 'Please use the photo of Kak Ani instead.', 1, seen: true);
  await comment('com_4', 'task_6', 'pkg_glowskin', 'glowskin', 'Love the colours! Can the logo be a little bigger?', 0);

  Future<void> approval(String docId, String taskId, String pkg, String key,
      ApprovalDecision decision, int versionNo, int ago, [String note = '']) async {
    await store.set(
        Collections.approvals,
        docId,
        Approval(id: docId, taskId: taskId, packageId: pkg, decision: decision, byUserId: id(key), byName: user(key).name, versionNumber: versionNo, note: note, createdAt: day(-ago, 15))
            .toMap());
  }

  await approval('apr_1', 'task_4', 'pkg_kopikita', 'kopikita', ApprovalDecision.approved, 1, 4);
  await approval('apr_2', 'task_5', 'pkg_kopikita', 'kopikita', ApprovalDecision.changesRequested, 1, 1, 'Use a different customer photo.');
  await approval('apr_3', 'task_12', 'pkg_urbanfit', 'urbanfit', ApprovalDecision.changesRequested, 1, 10, 'Make the date bigger.');
  await approval('apr_4', 'task_12', 'pkg_urbanfit', 'urbanfit', ApprovalDecision.approved, 2, 8);

  Future<void> handover(String docId, String taskId, String title, String from,
      String to, int versionNo, int ago, {int? receivedAgo, String note = ''}) async {
    await store.set(
        Collections.handovers,
        docId,
        Handover(id: docId, taskId: taskId, taskTitle: title, fromUserId: id(from), fromName: user(from).name, toUserId: id(to), toName: user(to).name, versionNumber: versionNo, note: note, sentAt: day(-ago, 10), receivedAt: receivedAgo == null ? null : day(-receivedAgo, 14))
            .toMap());
  }

  await handover('hand_1', 'task_2', 'Barista day reel', 'writer', 'editor', 0, 5, receivedAgo: 5, note: 'Script and voice-over text.');
  await handover('hand_2', 'task_9', 'Member transformation reel', 'designer', 'editor', 0, 1, note: 'Thumbnail and end card.');
  await handover('hand_3', 'task_1', 'Pumpkin latte launch post', 'writer', 'designer', 0, 3, receivedAgo: 2, note: 'Caption copy for the post.');

  Future<void> alert(String docId, String to, AlertType type, String title,
      String body, int hoursAgo, {String? taskId, String? pkg}) async {
    await store.set(
        Collections.alerts,
        docId,
        AppAlert(id: docId, userId: id(to), type: type, title: title, body: body, taskId: taskId, packageId: pkg, createdAt: today.subtract(Duration(hours: hoursAgo)))
            .toMap());
  }

  await alert('alert_1', 'owner', AlertType.overdue, 'Overdue: Pumpkin latte launch post', 'Kopi Kita Cafe - was due 2 days ago (Nurul Aina).', 3, taskId: 'task_1', pkg: 'pkg_kopikita');
  await alert('alert_2', 'owner', AlertType.approvalNeeded, '2 deliverables waiting for clients', 'Barista day reel, Brand introduction post.', 5);
  await alert('alert_3', 'designer', AlertType.newTask, 'New task: Class schedule graphic', 'UrbanFit Gym - low priority.', 20, taskId: 'task_10', pkg: 'pkg_urbanfit');
  await alert('alert_4', 'editor', AlertType.handover, 'Nurul Aina handed you Member transformation reel', 'Thumbnail and end card. Please confirm you received it.', 22, taskId: 'task_9', pkg: 'pkg_urbanfit');
  await alert('alert_5', 'kopikita', AlertType.approvalNeeded, 'Please review: Barista day reel', 'Version 2 is ready for your approval.', 2, taskId: 'task_2', pkg: 'pkg_kopikita');
  await alert('alert_6', 'glowskin', AlertType.approvalNeeded, 'Please review: Brand introduction post', 'Version 1 is ready for your approval.', 6, taskId: 'task_6', pkg: 'pkg_glowskin');
}

/// Firebase mode: creates every demo account in Firebase Auth (or signs in
/// if it exists), writes the profiles, then writes the demo data as the
/// owner and signs out. Needs Email/Password sign-in enabled in Firebase.
Future<void> seedFirebaseDemo(FirebaseAuthRepository auth, DocStore store) async {
  final ids = <String, String>{};
  // Owner last, so the data is written while signed in as the owner.
  final ordered = [
    ...demoAccounts.where((a) => a.role != UserRole.owner),
    ...demoAccounts.where((a) => a.role == UserRole.owner),
  ];
  for (final account in ordered) {
    ids[account.id] =
        await auth.ensureAccount(account, FakeAuthRepository.demoPassword);
  }
  await seedDemoData(store, ids: ids);
  await auth.signOut();
}
