// The one database interface every repository uses.
//
// Two implementations:
//   * MemoryDocStore     - demo mode, in-memory, seeded with sample data.
//                          Everyone develops against this, no Firebase needed.
//   * FirestoreDocStore  - real Cloud Firestore (Kaung sets it up).
//
// Queries only ever use ONE equality filter, and sorting is done in Dart,
// so Firestore never asks us to create composite indexes.

/// A document id plus its data.
class Doc {
  const Doc(this.id, this.data);
  final String id;
  final Map<String, dynamic> data;
}

/// Thrown by a store when something cannot be read or written.
class StoreException implements Exception {
  const StoreException(this.message);
  final String message;

  @override
  String toString() => message;
}

abstract class DocStore {
  /// Live list of documents in [collection], optionally where
  /// `field == isEqualTo`. Emits again whenever the data changes.
  Stream<List<Doc>> watchCollection(String collection,
      {String? whereField, Object? isEqualTo});

  /// Live single document, or null if it does not exist.
  Stream<Doc?> watchDoc(String collection, String id);

  Future<List<Doc>> getCollection(String collection,
      {String? whereField, Object? isEqualTo});

  Future<Doc?> getDoc(String collection, String id);

  /// Adds a document with a generated id and returns the id.
  Future<String> add(String collection, Map<String, dynamic> data);

  /// Creates or fully replaces the document [id].
  Future<void> set(String collection, String id, Map<String, dynamic> data);

  /// Changes only the given fields of an existing document.
  Future<void> update(String collection, String id, Map<String, dynamic> data);

  Future<void> delete(String collection, String id);
}

/// Collection names, in one place so nobody mistypes them.
abstract final class Collections {
  static const users = 'users';
  static const packages = 'packages';
  static const tasks = 'tasks';
  static const comments = 'comments';
  static const approvals = 'approvals';
  static const versions = 'versions';
  static const handovers = 'handovers';
  static const alerts = 'alerts';
}
