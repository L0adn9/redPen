import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'doc_store.dart';

/// Cloud Firestore implementation of [DocStore].
/// Owned by: Kaung (Firebase). Timestamps are converted to DateTime here so
/// models never import Firestore.
class FirestoreDocStore implements DocStore {
  FirestoreDocStore([FirebaseFirestore? db])
      : _db = db ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  static Map<String, dynamic> _clean(Map<String, dynamic> data) =>
      data.map((key, value) =>
          MapEntry(key, value is Timestamp ? value.toDate() : value));

  Query<Map<String, dynamic>> _query(
      String collection, String? whereField, Object? isEqualTo) {
    Query<Map<String, dynamic>> query = _db.collection(collection);
    if (whereField != null) {
      query = query.where(whereField, isEqualTo: isEqualTo);
    }
    return query;
  }

  /// Firestore errors only say "permission-denied"; this names the collection
  /// and filter so a refused query can be found quickly.
  static StoreException _named(Object e, String what) =>
      StoreException('Firestore refused $what: $e');

  static String _what(String op, String collection, String? field, Object? value) =>
      field == null ? '$op $collection' : '$op $collection where $field == $value';

  static Stream<T> _namedStream<T>(Stream<T> stream, String what) =>
      stream.transform(StreamTransformer<T, T>.fromHandlers(
          handleError: (e, st, sink) => sink.addError(_named(e, what), st)));

  static Future<T> _namedFuture<T>(Future<T> future, String what) =>
      future.catchError((Object e) => throw _named(e, what));

  List<Doc> _docs(QuerySnapshot<Map<String, dynamic>> snapshot) =>
      snapshot.docs.map((d) => Doc(d.id, _clean(d.data()))).toList();

  Doc? _doc(DocumentSnapshot<Map<String, dynamic>> snapshot) {
    final data = snapshot.data();
    return data == null ? null : Doc(snapshot.id, _clean(data));
  }

  @override
  Stream<List<Doc>> watchCollection(String collection,
          {String? whereField, Object? isEqualTo}) =>
      _namedStream(_query(collection, whereField, isEqualTo).snapshots().map(_docs),
          _what('watch', collection, whereField, isEqualTo));

  @override
  Stream<Doc?> watchDoc(String collection, String id) =>
      _namedStream(_db.collection(collection).doc(id).snapshots().map(_doc), 'watch $collection/$id');

  @override
  Future<List<Doc>> getCollection(String collection,
      {String? whereField, Object? isEqualTo}) async {
    final snapshot = await _namedFuture(_query(collection, whereField, isEqualTo).get(),
        _what('read', collection, whereField, isEqualTo));
    return _docs(snapshot);
  }

  @override
  Future<Doc?> getDoc(String collection, String id) async =>
      _doc(await _namedFuture(_db.collection(collection).doc(id).get(), 'read $collection/$id'));

  @override
  Future<String> add(String collection, Map<String, dynamic> data) async {
    final ref = await _namedFuture(_db.collection(collection).add(data), 'add to $collection');
    return ref.id;
  }

  @override
  Future<void> set(String collection, String id, Map<String, dynamic> data) =>
      _namedFuture(_db.collection(collection).doc(id).set(data), 'set $collection/$id');

  @override
  Future<void> update(
          String collection, String id, Map<String, dynamic> data) =>
      _namedFuture(_db.collection(collection).doc(id).update(data), 'update $collection/$id');

  @override
  Future<void> delete(String collection, String id) =>
      _namedFuture(_db.collection(collection).doc(id).delete(), 'delete $collection/$id');
}
