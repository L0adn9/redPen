// All repositories in one file so the data rules are easy to find.
// Owned by: Hassan (core). Each role can ADD a method here through a small
// PR to main, but never rename/remove one another role is using.
//
// Business rules live here (not in screens), for example:
//   * recording a client decision also updates the task status and alerts staff
//   * uploading a file creates the next version number
//   * a handover alerts the receiver until they confirm

import 'dart:typed_data';

import '../models/models.dart';
import 'doc_store.dart';
import 'file_storage.dart';

List<T> _sorted<T>(List<T> items, int Function(T a, T b) compare) =>
    [...items]..sort(compare);

/// Deletes a task together with its comments, approvals, file versions and
/// handovers, so nothing is left pointing at a task that no longer exists.
Future<void> _deleteTaskWithRecords(DocStore store, String taskId) async {
  // The task goes first, so every screen shows it as removed straight away.
  await store.delete(Collections.tasks, taskId);
  for (final collection in [
    Collections.comments,
    Collections.approvals,
    Collections.versions,
    Collections.handovers,
  ]) {
    final docs = await store.getCollection(collection, whereField: 'taskId', isEqualTo: taskId);
    for (final doc in docs) {
      await store.delete(collection, doc.id);
    }
  }
}

// ---------------------------------------------------------------- users

class UserRepository {
  UserRepository(this._store);
  final DocStore _store;

  Stream<List<AppUser>> watchByRole(UserRole role) => _store
      .watchCollection(Collections.users, whereField: 'role', isEqualTo: role.name)
      .map((docs) => _sorted(
          docs.map((d) => AppUser.fromMap(d.id, d.data)).toList(),
          (a, b) => a.name.compareTo(b.name)));

  Future<List<AppUser>> getByRole(UserRole role) async {
    final docs = await _store.getCollection(Collections.users,
        whereField: 'role', isEqualTo: role.name);
    return docs.map((d) => AppUser.fromMap(d.id, d.data)).toList();
  }

  Future<AppUser?> getById(String id) async {
    final doc = await _store.getDoc(Collections.users, id);
    return doc == null ? null : AppUser.fromMap(doc.id, doc.data);
  }

  Future<void> save(AppUser user) =>
      _store.set(Collections.users, user.id, user.toMap());
}

// ---------------------------------------------------------------- alerts

class AlertRepository {
  AlertRepository(this._store, this._users);
  final DocStore _store;
  final UserRepository _users;

  /// Newest first.
  Stream<List<AppAlert>> watchForUser(String userId) => _store
      .watchCollection(Collections.alerts, whereField: 'userId', isEqualTo: userId)
      .map((docs) => _sorted(
          docs.map((d) => AppAlert.fromMap(d.id, d.data)).toList(),
          (a, b) => b.createdAt.compareTo(a.createdAt)));

  /// One-off read of a user's alerts, newest first.
  Future<List<AppAlert>> getForUser(String userId) async => _sorted(
      (await _store.getCollection(Collections.alerts, whereField: 'userId', isEqualTo: userId))
          .map((d) => AppAlert.fromMap(d.id, d.data))
          .toList(),
      (a, b) => b.createdAt.compareTo(a.createdAt));

  Future<String> send({
    required String userId,
    required AlertType type,
    required String title,
    required String body,
    String? taskId,
    String? packageId,
    String? fromUserId,
  }) =>
      _store.add(
          Collections.alerts,
          AppAlert(
            id: '',
            userId: userId,
            type: type,
            title: title,
            body: body,
            taskId: taskId,
            packageId: packageId,
            fromUserId: fromUserId,
            createdAt: DateTime.now(),
          ).toMap());

  /// Sends the same alert to everyone with [role] (e.g. all owners).
  Future<void> sendToRole(
    UserRole role, {
    required AlertType type,
    required String title,
    required String body,
    String? taskId,
    String? packageId,
    String? fromUserId,
  }) async {
    for (final user in await _users.getByRole(role)) {
      await send(
          userId: user.id,
          type: type,
          title: title,
          body: body,
          taskId: taskId,
          packageId: packageId,
          fromUserId: fromUserId);
    }
  }

  /// Owner asks the assignee for a status update (OM-UC9).
  Future<void> requestStatus({required ContentTask task, required AppUser owner}) => send(
        userId: task.assigneeId,
        type: AlertType.statusRequest,
        title: 'Status update requested: ${task.title}',
        body: '${owner.name} asked for an update on this ${task.contentType.label.toLowerCase()} for ${task.clientName}.',
        taskId: task.id,
        packageId: task.packageId,
        fromUserId: owner.id,
      );

  /// Staff reply to a status request; every owner receives it (OM-UC9).
  Future<void> sendStatusUpdate(
          {required ContentTask task, required AppUser staff, required String message}) =>
      sendToRole(
        UserRole.owner,
        type: AlertType.general,
        title: 'Status from ${staff.name}: ${task.title}',
        body: message.trim(),
        taskId: task.id,
        packageId: task.packageId,
        fromUserId: staff.id,
      );

  /// Staff flag that they are overloaded (ST-UC8).
  Future<void> flagOverload({required AppUser staff, required int openTasks, required String reason}) =>
      sendToRole(
        UserRole.owner,
        type: AlertType.overload,
        title: '${staff.name} is overloaded',
        body: '$openTasks open tasks. ${reason.trim()}',
        fromUserId: staff.id,
      );

  Future<void> markRead(String alertId) =>
      _store.update(Collections.alerts, alertId, {'read': true});

  Future<void> markAllRead(String userId) async {
    final docs = await _store.getCollection(Collections.alerts,
        whereField: 'userId', isEqualTo: userId);
    for (final doc in docs.where((d) => d.data['read'] != true)) {
      await markRead(doc.id);
    }
  }

  Future<void> delete(String alertId) =>
      _store.delete(Collections.alerts, alertId);
}

// ---------------------------------------------------------------- packages

class PackageRepository {
  PackageRepository(this._store);
  final DocStore _store;

  List<ClientPackage> _map(List<Doc> docs) => _sorted(
      docs.map((d) => ClientPackage.fromMap(d.id, d.data)).toList(),
      (a, b) => a.clientName.compareTo(b.clientName));

  /// Owner: every package.
  Stream<List<ClientPackage>> watchAll() =>
      _store.watchCollection(Collections.packages).map(_map);

  /// Client: only their own package(s).
  Stream<List<ClientPackage>> watchForClient(String clientUserId) => _store
      .watchCollection(Collections.packages,
          whereField: 'clientUserId', isEqualTo: clientUserId)
      .map(_map);

  Stream<ClientPackage?> watchById(String id) => _store
      .watchDoc(Collections.packages, id)
      .map((d) => d == null ? null : ClientPackage.fromMap(d.id, d.data));

  Future<ClientPackage?> getById(String id) async {
    final doc = await _store.getDoc(Collections.packages, id);
    return doc == null ? null : ClientPackage.fromMap(doc.id, doc.data);
  }

  Future<String> create(ClientPackage package) =>
      _store.add(Collections.packages, package.toMap());

  Future<void> update(ClientPackage package) =>
      _store.set(Collections.packages, package.id, package.toMap());

  Future<void> delete(String id) => _store.delete(Collections.packages, id);

  /// Deletes a package, all of its tasks and their records.
  Future<void> deleteWithTasks(String id) async {
    final tasks = await _store.getCollection(Collections.tasks,
        whereField: 'packageId', isEqualTo: id);
    for (final t in tasks) {
      await _deleteTaskWithRecords(_store, t.id);
    }
    await delete(id);
  }
}

// ---------------------------------------------------------------- tasks

class TaskRepository {
  TaskRepository(this._store, this._alerts);
  final DocStore _store;
  final AlertRepository _alerts;

  /// Sorted by due date, earliest first.
  List<ContentTask> _map(List<Doc> docs) => _sorted(
      docs.map((d) => ContentTask.fromMap(d.id, d.data)).toList(),
      (a, b) => a.dueDate.compareTo(b.dueDate));

  Stream<List<ContentTask>> watchAll() =>
      _store.watchCollection(Collections.tasks).map(_map);

  /// One-off read of every task.
  Future<List<ContentTask>> getAll() async =>
      _map(await _store.getCollection(Collections.tasks));

  Stream<List<ContentTask>> watchForPackage(String packageId) => _store
      .watchCollection(Collections.tasks,
          whereField: 'packageId', isEqualTo: packageId)
      .map(_map);

  Stream<List<ContentTask>> watchForAssignee(String userId) => _store
      .watchCollection(Collections.tasks,
          whereField: 'assigneeId', isEqualTo: userId)
      .map(_map);

  Stream<ContentTask?> watchById(String id) => _store
      .watchDoc(Collections.tasks, id)
      .map((d) => d == null ? null : ContentTask.fromMap(d.id, d.data));

  Future<ContentTask?> getById(String id) async {
    final doc = await _store.getDoc(Collections.tasks, id);
    return doc == null ? null : ContentTask.fromMap(doc.id, doc.data);
  }

  /// Creates a task and alerts the assignee (ST-UC2).
  Future<String> create(ContentTask task) async {
    final now = DateTime.now();
    final id = await _store.add(Collections.tasks,
        task.copyWith(createdAt: now, updatedAt: now).toMap());
    await _alerts.send(
      userId: task.assigneeId,
      type: AlertType.newTask,
      title: 'New task: ${task.title}',
      body: '${task.clientName} - due ${_short(task.dueDate)}',
      taskId: id,
      packageId: task.packageId,
      fromUserId: task.createdById,
    );
    return id;
  }

  /// Saves edits and alerts the assignee that the task changed (ST-UC2).
  /// If the task was reassigned, the new person gets a "new task" alert.
  Future<void> update(ContentTask task, {bool notifyAssignee = true}) async {
    final before = await getById(task.id);
    await _store.set(Collections.tasks, task.id,
        task.copyWith(updatedAt: DateTime.now()).toMap());
    if (before != null && before.assigneeId != task.assigneeId) {
      await _alerts.send(
        userId: task.assigneeId,
        type: AlertType.newTask,
        title: 'Task reassigned to you: ${task.title}',
        body: '${task.clientName} - due ${_short(task.dueDate)}',
        taskId: task.id,
        packageId: task.packageId,
      );
    } else if (notifyAssignee) {
      await _alerts.send(
        userId: task.assigneeId,
        type: AlertType.taskChanged,
        title: 'Task updated: ${task.title}',
        body: 'Due ${_short(task.dueDate)} - priority ${task.priority.label}',
        taskId: task.id,
        packageId: task.packageId,
      );
    }
  }

  Future<void> updateStatus(String taskId, TaskStatus status) =>
      _store.update(Collections.tasks, taskId,
          {'status': status.name, 'updatedAt': DateTime.now()});

  /// Deletes a task (with its comments, approvals, versions and handovers)
  /// and tells the assignee (ST-UC2).
  Future<void> delete(ContentTask task) async {
    await _deleteTaskWithRecords(_store, task.id);
    await _alerts.send(
      userId: task.assigneeId,
      type: AlertType.taskChanged,
      title: 'Task removed: ${task.title}',
      body: '${task.clientName} no longer needs this item.',
      packageId: task.packageId,
    );
  }

  static String _short(DateTime d) => '${d.day}/${d.month}';
}

// ---------------------------------------------------------------- feedback

class FeedbackRepository {
  FeedbackRepository(this._store, this._tasks, this._packages, this._alerts);
  final DocStore _store;
  final TaskRepository _tasks;
  final PackageRepository _packages;
  final AlertRepository _alerts;

  /// Oldest first, like a chat.
  Stream<List<TaskComment>> watchComments(String taskId) => _store
      .watchCollection(Collections.comments, whereField: 'taskId', isEqualTo: taskId)
      .map((docs) => _sorted(
          docs.map((d) => TaskComment.fromMap(d.id, d.data)).toList(),
          (a, b) => a.createdAt.compareTo(b.createdAt)));

  /// Adds a comment. Client comments alert the assignee; agency comments
  /// alert the client (ST-UC4, CL-UC4).
  Future<void> addComment({
    required ContentTask task,
    required AppUser author,
    required String text,
  }) async {
    await _store.add(
        Collections.comments,
        TaskComment(
          id: '',
          taskId: task.id,
          packageId: task.packageId,
          authorId: author.id,
          authorName: author.name,
          authorRole: author.role,
          text: text.trim(),
          createdAt: DateTime.now(),
        ).toMap());
    if (author.role == UserRole.client) {
      await _alerts.send(
        userId: task.assigneeId,
        type: AlertType.feedback,
        title: 'Client feedback on ${task.title}',
        body: text.trim(),
        taskId: task.id,
        packageId: task.packageId,
        fromUserId: author.id,
      );
    } else {
      final package = await _packages.getById(task.packageId);
      if (package != null) {
        await _alerts.send(
          userId: package.clientUserId,
          type: AlertType.feedback,
          title: 'Reply on ${task.title}',
          body: '${author.name}: ${text.trim()}',
          taskId: task.id,
          packageId: task.packageId,
          fromUserId: author.id,
        );
      }
    }
  }

  /// Agency opened the thread: mark client comments as seen (CL-UC7).
  Future<void> markClientCommentsSeen(String taskId) async {
    final docs = await _store.getCollection(Collections.comments,
        whereField: 'taskId', isEqualTo: taskId);
    final now = DateTime.now();
    for (final doc in docs) {
      if (doc.data['authorRole'] == UserRole.client.name &&
          doc.data['seenByAgency'] != true) {
        await _store.update(Collections.comments, doc.id,
            {'seenByAgency': true, 'seenAt': now});
      }
    }
  }

  /// Newest first.
  Stream<List<Approval>> watchApprovals(String taskId) => _store
      .watchCollection(Collections.approvals, whereField: 'taskId', isEqualTo: taskId)
      .map(_mapApprovals);

  Stream<List<Approval>> watchApprovalsForPackage(String packageId) => _store
      .watchCollection(Collections.approvals,
          whereField: 'packageId', isEqualTo: packageId)
      .map(_mapApprovals);

  List<Approval> _mapApprovals(List<Doc> docs) => _sorted(
      docs.map((d) => Approval.fromMap(d.id, d.data)).toList(),
      (a, b) => b.createdAt.compareTo(a.createdAt));

  /// Staff send the latest version to the client for approval.
  Future<void> submitForApproval(ContentTask task) async {
    await _tasks.updateStatus(task.id, TaskStatus.awaitingApproval);
    final package = await _packages.getById(task.packageId);
    if (package != null) {
      await _alerts.send(
        userId: package.clientUserId,
        type: AlertType.approvalNeeded,
        title: 'Please review: ${task.title}',
        body: 'Version ${task.latestVersion} is ready for your approval.',
        taskId: task.id,
        packageId: task.packageId,
        fromUserId: task.assigneeId,
      );
    }
  }

  /// Client approves or asks for changes. Saves a timestamped record,
  /// updates the task and alerts the assignee (CL-UC5, OM-UC5).
  Future<void> recordDecision({
    required ContentTask task,
    required AppUser client,
    required ApprovalDecision decision,
    String note = '',
  }) async {
    final now = DateTime.now();
    await _store.add(
        Collections.approvals,
        Approval(
          id: '',
          taskId: task.id,
          packageId: task.packageId,
          decision: decision,
          byUserId: client.id,
          byName: client.name,
          versionNumber: task.latestVersion,
          note: note.trim(),
          createdAt: now,
        ).toMap());
    await _store.update(Collections.tasks, task.id, {
      'status': decision == ApprovalDecision.approved
          ? TaskStatus.approved.name
          : TaskStatus.changesRequested.name,
      if (decision == ApprovalDecision.approved)
        'approvedVersion': task.latestVersion,
      'updatedAt': now,
    });
    await _alerts.send(
      userId: task.assigneeId,
      type: AlertType.feedback,
      title: decision == ApprovalDecision.approved
          ? '${task.title} approved'
          : 'Changes requested: ${task.title}',
      body: note.trim().isEmpty ? 'By ${client.name}' : note.trim(),
      taskId: task.id,
      packageId: task.packageId,
      fromUserId: client.id,
    );
  }
}

// ---------------------------------------------------------------- files

class FileRepository {
  FileRepository(this._store, this._storage, this._alerts);
  final DocStore _store;
  final FileStorage _storage;
  final AlertRepository _alerts;

  /// Newest version first.
  Stream<List<FileVersion>> watchVersions(String taskId) => _store
      .watchCollection(Collections.versions, whereField: 'taskId', isEqualTo: taskId)
      .map((docs) => _sorted(
          docs.map((d) => FileVersion.fromMap(d.id, d.data)).toList(),
          (a, b) => b.versionNumber.compareTo(a.versionNumber)));

  /// Uploads a new version of a deliverable (ST-UC5). Returns the version.
  Future<FileVersion> uploadVersion({
    required ContentTask task,
    required AppUser uploader,
    required String fileName,
    required Uint8List bytes,
    required String mimeType,
    String note = '',
  }) async {
    final number = task.latestVersion + 1;
    final url = await _storage.upload(
      path: 'tasks/${task.id}/v${number}_$fileName',
      bytes: bytes,
      mimeType: mimeType,
    );
    final version = FileVersion(
      id: '',
      taskId: task.id,
      versionNumber: number,
      fileName: fileName,
      fileUrl: url,
      mimeType: mimeType,
      sizeBytes: bytes.length,
      uploadedById: uploader.id,
      uploadedByName: uploader.name,
      note: note.trim(),
      createdAt: DateTime.now(),
    );
    final id = await _store.add(Collections.versions, version.toMap());
    await _store.update(Collections.tasks, task.id, {
      'latestVersion': number,
      if (task.status == TaskStatus.todo ||
          task.status == TaskStatus.changesRequested)
        'status': TaskStatus.inProgress.name,
      'updatedAt': DateTime.now(),
    });
    return FileVersion.fromMap(id, version.toMap());
  }

  Stream<List<Handover>> watchAllHandovers() => _store
      .watchCollection(Collections.handovers)
      .map(_mapHandovers);

  Stream<List<Handover>> watchHandoversTo(String userId) => _store
      .watchCollection(Collections.handovers, whereField: 'toUserId', isEqualTo: userId)
      .map(_mapHandovers);

  Stream<List<Handover>> watchHandoversFrom(String userId) => _store
      .watchCollection(Collections.handovers,
          whereField: 'fromUserId', isEqualTo: userId)
      .map(_mapHandovers);

  List<Handover> _mapHandovers(List<Doc> docs) => _sorted(
      docs.map((d) => Handover.fromMap(d.id, d.data)).toList(),
      (a, b) => b.sentAt.compareTo(a.sentAt));

  /// Hands a file to another staff member and alerts them (ST-UC6).
  Future<String> handOver({
    required ContentTask task,
    required AppUser from,
    required AppUser to,
    String note = '',
  }) async {
    final id = await _store.add(
        Collections.handovers,
        Handover(
          id: '',
          taskId: task.id,
          taskTitle: task.title,
          fromUserId: from.id,
          fromName: from.name,
          toUserId: to.id,
          toName: to.name,
          versionNumber: task.latestVersion,
          note: note.trim(),
          sentAt: DateTime.now(),
        ).toMap());
    await _alerts.send(
      userId: to.id,
      type: AlertType.handover,
      title: '${from.name} handed you ${task.title}',
      body: note.trim().isEmpty
          ? 'Version ${task.latestVersion}. Please confirm you received it.'
          : note.trim(),
      taskId: task.id,
      packageId: task.packageId,
      fromUserId: from.id,
    );
    return id;
  }

  /// Receiver confirms the handover (ST-UC6, OM-UC7).
  Future<void> confirmReceived(String handoverId) => _store.update(
      Collections.handovers, handoverId, {'receivedAt': DateTime.now()});
}
