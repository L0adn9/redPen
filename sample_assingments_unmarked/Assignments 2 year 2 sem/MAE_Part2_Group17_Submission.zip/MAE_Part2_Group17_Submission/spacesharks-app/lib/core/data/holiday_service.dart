import 'dart:convert';

import 'package:http/http.dart' as http;

/// A public holiday from the Nager.Date API.
class Holiday {
  const Holiday({required this.date, required this.name, required this.localName});
  final DateTime date;
  final String name;
  final String localName;

  factory Holiday.fromJson(Map<String, dynamic> json) => Holiday(
        date: DateTime.parse(json['date'] as String),
        name: (json['name'] ?? '') as String,
        localName: (json['localName'] ?? '') as String,
      );
}

/// Third-party data API: public holidays from https://date.nager.at
/// (free, no API key). Used by the weekly content calendar to show holidays
/// and warn when a post is scheduled on one.
class HolidayService {
  HolidayService({Future<String> Function(Uri url)? fetch, this.country = 'MY'})
      : _fetch = fetch ?? _httpGet;

  /// A service that returns fixed holidays without the network (tests,
  /// screenshots).
  factory HolidayService.fixed(List<Holiday> holidays) {
    final service = HolidayService(fetch: (_) async => '[]');
    for (final h in holidays) {
      service._cache.putIfAbsent(h.date.year, () => []).add(h);
    }
    return service;
  }

  static const baseUrl = 'https://date.nager.at/api/v3/PublicHolidays';

  final Future<String> Function(Uri url) _fetch;
  final String country;
  final Map<int, List<Holiday>> _cache = {};

  static Future<String> _httpGet(Uri url) async {
    final response = await http.get(url).timeout(const Duration(seconds: 10));
    if (response.statusCode != 200) {
      throw Exception('Holiday API returned ${response.statusCode}');
    }
    return response.body;
  }

  /// Parses the API's JSON list.
  static List<Holiday> parse(String body) => (jsonDecode(body) as List)
      .cast<Map<String, dynamic>>()
      .map(Holiday.fromJson)
      .toList();

  /// Holidays for [year]. Cached; returns an empty list when offline, so the
  /// calendar still works without the API.
  Future<List<Holiday>> holidaysFor(int year) async {
    final cached = _cache[year];
    if (cached != null) return cached;
    try {
      final list = parse(await _fetch(Uri.parse('$baseUrl/$year/$country')));
      _cache[year] = list;
      return list;
    } catch (_) {
      return const [];
    }
  }

  /// Holidays in the 7 days starting at [weekStart] (may span two years).
  Future<List<Holiday>> holidaysInWeek(DateTime weekStart) async {
    final end = weekStart.add(const Duration(days: 7));
    final years = {weekStart.year, end.year};
    final all = [for (final y in years) ...await holidaysFor(y)];
    return all.where((h) => !h.date.isBefore(weekStart) && h.date.isBefore(end)).toList();
  }
}

/// Link that opens Google Calendar with the event pre-filled
/// ("Add to Google Calendar"). No sign-in or API key needed.
Uri googleCalendarLink({required String title, required DateTime start, Duration length = const Duration(hours: 1), String details = ''}) {
  String stamp(DateTime d) {
    final u = d.toUtc();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${u.year}${two(u.month)}${two(u.day)}T${two(u.hour)}${two(u.minute)}00Z';
  }

  return Uri.https('calendar.google.com', '/calendar/render', {
    'action': 'TEMPLATE',
    'text': title,
    'dates': '${stamp(start)}/${stamp(start.add(length))}',
    'details': details,
  });
}
