import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/models/models.dart';
import '../../core/widgets/common_widgets.dart';
import '../client/client_home.dart';
import '../owner/owner_home.dart';
import '../staff/staff_home.dart';
import 'login_screen.dart';

/// Shows the login screen, or the signed-in user's role home.
/// Owned by: Hassan.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final session = AppScope.of(context).session;
    return ListenableBuilder(
      listenable: session,
      builder: (context, _) {
        if (!session.isReady) return const Scaffold(body: LoadingView());
        final user = session.user;
        if (user == null) return const LoginScreen();
        return switch (user.role) {
          UserRole.owner => OwnerHome(key: ValueKey(user.id)),
          UserRole.staff => StaffHome(key: ValueKey(user.id)),
          UserRole.client => ClientHome(key: ValueKey(user.id)),
        };
      },
    );
  }
}
