import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/config/app_config.dart';
import '../../core/data/auth_repository.dart';
import '../../core/data/seed_data.dart';
import '../../core/models/models.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/common_widgets.dart';
import 'login_view_model.dart';

/// One login screen for all roles (proposal Figure 4). Owned by: Hassan.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _obscure = true;
  bool _seeding = false;
  LoginViewModel? _vm;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _vm ??= LoginViewModel(AppScope.of(context).services.auth);
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _vm?.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    await _vm!.signIn(_email.text, _password.text);
    // On success the AuthGate swaps this screen for the role home.
  }

  void _fill(AppUser account) {
    _email.text = account.email;
    _password.text = FakeAuthRepository.demoPassword;
  }

  Future<void> _seedFirebase() async {
    setState(() => _seeding = true);
    try {
      await AppScope.of(context).services.loadDemoDataIntoFirebase();
      if (mounted) showMessage(context, 'Demo accounts and data loaded.');
    } catch (e) {
      if (mounted) showMessage(context, 'Could not load demo data: $e', error: true);
    } finally {
      if (mounted) setState(() => _seeding = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final services = AppScope.of(context).services;
    final vm = _vm!;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: ListenableBuilder(
                listenable: vm,
                builder: (context, _) => Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const _Logo(),
                      const SizedBox(height: 32),
                      const Text('Sign in',
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      const Text('Owners, staff and clients all sign in here.',
                          style: TextStyle(color: AppColors.muted)),
                      const SizedBox(height: 24),
                      TextFormField(
                        key: const Key('emailField'),
                        controller: _email,
                        keyboardType: TextInputType.emailAddress,
                        autofillHints: const [AutofillHints.email],
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                            labelText: 'Email', prefixIcon: Icon(Icons.mail_outline)),
                        validator: Validators.email,
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        key: const Key('passwordField'),
                        controller: _password,
                        obscureText: _obscure,
                        autofillHints: const [AutofillHints.password],
                        onFieldSubmitted: (_) => _submit(),
                        decoration: InputDecoration(
                          labelText: 'Password',
                          prefixIcon: const Icon(Icons.lock_outline),
                          suffixIcon: IconButton(
                            tooltip: _obscure ? 'Show password' : 'Hide password',
                            icon: Icon(_obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                            onPressed: () => setState(() => _obscure = !_obscure),
                          ),
                        ),
                        validator: Validators.password,
                      ),
                      if (vm.error != null) ...[
                        const SizedBox(height: 14),
                        Text(vm.error!,
                            key: const Key('loginError'),
                            style: const TextStyle(color: AppColors.red)),
                      ],
                      const SizedBox(height: 22),
                      FilledButton(
                        key: const Key('loginButton'),
                        onPressed: vm.isLoading ? null : _submit,
                        child: vm.isLoading
                            ? const SizedBox(
                                height: 20, width: 20,
                                child: CircularProgressIndicator(strokeWidth: 2.4, color: AppColors.white))
                            : const Text('Sign in'),
                      ),
                      if (services.isDemo) ...[
                        const SizedBox(height: 28),
                        const Text('Demo accounts (password: password123)',
                            style: TextStyle(color: AppColors.muted, fontSize: 13)),
                        const SizedBox(height: 8),
                        Wrap(spacing: 8, runSpacing: 8, children: [
                          for (final account in demoAccounts)
                            ActionChip(
                              key: Key('demo_${account.id}'),
                              label: Text(switch (account.role) {
                                UserRole.owner => 'Owner',
                                UserRole.staff => account.jobTitle,
                                UserRole.client => account.company,
                              }),
                              onPressed: () => _fill(account),
                            ),
                        ]),
                      ],
                      if (!services.isDemo && kDebugMode && AppConfig.backend == Backend.firebase) ...[
                        const SizedBox(height: 24),
                        TextButton.icon(
                          onPressed: _seeding ? null : _seedFirebase,
                          icon: const Icon(Icons.cloud_upload_outlined),
                          label: Text(_seeding ? 'Loading...' : 'Developer: load demo data into Firebase'),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Logo extends StatelessWidget {
  const _Logo();

  @override
  Widget build(BuildContext context) => Column(children: [
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            color: AppColors.ink,
            borderRadius: BorderRadius.circular(20),
          ),
          alignment: Alignment.center,
          child: const Text('SS',
              style: TextStyle(color: AppColors.white, fontSize: 28, fontWeight: FontWeight.w900)),
        ),
        const SizedBox(height: 12),
        const Text(AppConfig.appName,
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 2)),
        const Text(AppConfig.tagline, style: TextStyle(color: AppColors.muted)),
      ]);
}
