import 'package:flutter/foundation.dart';

import '../../core/data/auth_repository.dart';
import '../../core/utils/safe_notifier.dart';

class LoginViewModel extends ChangeNotifier with SafeChangeNotifier {
  LoginViewModel(this._auth);
  final AuthRepository _auth;

  bool _isLoading = false;
  String? _error;

  bool get isLoading => _isLoading;
  String? get error => _error;

  /// Returns true on success. On failure [error] holds a readable message.
  Future<bool> signIn(String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      await _auth.signIn(email: email, password: password);
      return true;
    } on AuthException catch (e) {
      _error = e.message;
      return false;
    } catch (e) {
      _error = 'Something went wrong. Please try again.';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
