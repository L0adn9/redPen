import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../../core/widgets/file_preview.dart';
import '../../shared/task_detail/task_detail_screen.dart';

/// Client approved library: every approved deliverable in one place, showing
/// the final approved version (CL-UC6, CL-UC9).
class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scope = AppScope.of(context);
    final services = scope.services;
    return StreamBuilder<List<ClientPackage>>(
      stream: services.packages.watchForClient(scope.user.id),
      builder: (context, packages) {
        if (!packages.hasData) return const LoadingView();
        if (packages.data!.isEmpty) {
          return const EmptyState(icon: Icons.photo_library_outlined, title: 'No package yet');
        }
        return StreamBuilder<List<ContentTask>>(
          stream: services.tasks.watchForPackage(packages.data!.first.id),
          builder: (context, tasks) {
            if (!tasks.hasData) return const LoadingView();
            final approved = tasks.data!.where((t) => t.status == TaskStatus.approved).toList()
              ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
            if (approved.isEmpty) {
              return const EmptyState(
                  icon: Icons.photo_library_outlined,
                  title: 'Nothing approved yet',
                  message: 'Approved posts, reels and graphics will appear here.');
            }
            return MaxWidth(
              child: GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: Responsive.columns(context) + 1,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 0.78,
                ),
                itemCount: approved.length,
                itemBuilder: (context, i) => _LibraryTile(task: approved[i]),
              ),
            );
          },
        );
      },
    );
  }
}

class _LibraryTile extends StatelessWidget {
  const _LibraryTile({required this.task});
  final ContentTask task;

  @override
  Widget build(BuildContext context) {
    final files = AppScope.of(context).services.files;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => TaskDetailScreen.open(context, task.id),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            child: StreamBuilder<List<FileVersion>>(
              stream: files.watchVersions(task.id),
              builder: (context, snapshot) {
                final versions = snapshot.data ?? const <FileVersion>[];
                final finalVersion = versions.where((v) => v.versionNumber == task.approvedVersion).firstOrNull ??
                    versions.firstOrNull;
                if (finalVersion == null) {
                  return const ColoredBox(color: AppColors.background, child: Icon(Icons.image_outlined, color: AppColors.muted));
                }
                return FilePreview(version: finalVersion, height: double.infinity);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(task.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text('${task.contentType.label} · v${task.approvedVersion ?? task.latestVersion} final',
                  style: const TextStyle(color: AppColors.muted, fontSize: 12)),
              if (task.publishDate != null)
                Text(formatDay(task.publishDate!), style: const TextStyle(color: AppColors.muted, fontSize: 12)),
            ]),
          ),
        ]),
      ),
    );
  }
}
