import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../shared/task_detail/task_detail_screen.dart';
import '../../shared/task_card.dart';
import 'my_package_view_model.dart';

/// Client package page (proposal Figure 9): phase progress (CL-UC1, CL-UC2),
/// what is waiting for approval (CL-UC5, CL-UC8) and the next 7 days (CL-UC3).
class MyPackageScreen extends StatefulWidget {
  const MyPackageScreen({super.key});

  @override
  State<MyPackageScreen> createState() => _MyPackageScreenState();
}

class _MyPackageScreenState extends State<MyPackageScreen> {
  MyPackageViewModel? _vm;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final scope = AppScope.of(context);
    _vm ??= MyPackageViewModel(scope.services, scope.user)..start();
  }

  @override
  void dispose() {
    _vm?.dispose();
    super.dispose();
  }

  void _openDeliverable(ContentTask task) => TaskDetailScreen.open(context, task.id);

  @override
  Widget build(BuildContext context) {
    final vm = _vm!;
    return ListenableBuilder(
      listenable: vm,
      builder: (context, _) {
        if (vm.error != null) return ErrorView(message: vm.error!);
        if (vm.isLoading) return const LoadingView();
        final package = vm.package;
        if (package == null) {
          return const EmptyState(
            icon: Icons.inventory_2_outlined,
            title: 'No package yet',
            message: 'Your SPACESHARKS manager will add your package here.',
          );
        }
        return MaxWidth(
          maxWidth: 760,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(package.clientName,
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                    Text('${package.packageName} · Manager: ${package.managerName}',
                        style: const TextStyle(color: AppColors.muted)),
                    const SizedBox(height: 16),
                    PhaseStepper(current: package.phase),
                    if (package.goals.isNotEmpty) ...[
                      const SizedBox(height: 14),
                      Text(package.goals),
                    ],
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              StatRow(children: [
                StatTile(label: 'Waiting for you', value: '${vm.awaitingMyApproval.length}', icon: Icons.fact_check_outlined, color: AppColors.amber),
                StatTile(label: 'In progress', value: '${vm.inProgressCount}', icon: Icons.autorenew, color: AppColors.orange),
                StatTile(label: 'Approved', value: '${vm.approvedCount} of ${package.promisedItems}', icon: Icons.verified_outlined, color: AppColors.green),
              ]),
              SectionHeader('Waiting for your approval (${vm.awaitingMyApproval.length})'),
              if (vm.awaitingMyApproval.isEmpty)
                const Text('Nothing to review right now.', style: TextStyle(color: AppColors.muted)),
              for (final t in vm.awaitingMyApproval)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: TaskCard(key: Key('deliverable_${t.id}'), task: t, now: vm.now, showClient: false, onTap: () => _openDeliverable(t)),
                ),
              const SectionHeader('Coming up in the next 7 days'),
              if (vm.nextSevenDays.isEmpty)
                const Text('Nothing scheduled.', style: TextStyle(color: AppColors.muted)),
              for (final t in vm.nextSevenDays)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(contentTypeIcon(t.contentType)),
                  title: Text(t.title),
                  subtitle: Text(formatDay(t.calendarDate)),
                  trailing: StatusChip(t.status),
                  onTap: () => _openDeliverable(t),
                ),
            ],
          ),
        );
      },
    );
  }
}
