import 'package:flutter/material.dart';

import '../shared/role_shell.dart';
import 'calendar/client_calendar_screen.dart';
import 'library/library_screen.dart';
import 'package/my_package_screen.dart';

/// Client home: my package, content calendar, approved library.
class ClientHome extends StatelessWidget {
  const ClientHome({super.key});

  @override
  Widget build(BuildContext context) => RoleShell(tabs: [
        RoleTab(
          label: 'My package',
          icon: Icons.inventory_2_outlined,
          selectedIcon: Icons.inventory_2,
          builder: (_) => const MyPackageScreen(),
        ),
        RoleTab(
          label: 'Calendar',
          icon: Icons.calendar_month_outlined,
          selectedIcon: Icons.calendar_month,
          builder: (_) => const ClientCalendarScreen(),
        ),
        RoleTab(
          label: 'Library',
          icon: Icons.photo_library_outlined,
          selectedIcon: Icons.photo_library,
          builder: (_) => const LibraryScreen(),
        ),
      ]);
}
