import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../../core/models/models.dart';
import '../../../core/services/app_services.dart';
import '../../../core/utils/safe_notifier.dart';

/// Client "My package" state. Owned by: Hassan (starter written for the base).
class MyPackageViewModel extends ChangeNotifier with SafeChangeNotifier {
  MyPackageViewModel(this._services, this._user, {DateTime Function()? clock})
      : _clock = clock ?? DateTime.now;

  final AppServices _services;
  final AppUser _user;
  final DateTime Function() _clock;
  StreamSubscription<List<ClientPackage>>? _packageSub;
  StreamSubscription<List<ContentTask>>? _taskSub;

  ClientPackage? _package;
  List<ContentTask> _tasks = [];
  bool _loaded = false;
  String? _error;

  bool get isLoading => !_loaded && _error == null;
  String? get error => _error;
  ClientPackage? get package => _package;
  DateTime get now => _clock();

  void start() {
    _packageSub = _services.packages.watchForClient(_user.id).listen((packages) {
      final next = packages.isEmpty ? null : packages.first;
      if (next?.id != _package?.id) _watchTasks(next);
      _package = next;
      if (next == null) _loaded = true;
      notifyListeners();
    }, onError: _onError);
  }

  void _watchTasks(ClientPackage? package) {
    _taskSub?.cancel();
    _tasks = [];
    if (package == null) return;
    _taskSub = _services.tasks.watchForPackage(package.id).listen((tasks) {
      _tasks = tasks;
      _loaded = true;
      notifyListeners();
    }, onError: _onError);
  }

  void _onError(Object e) {
    _error = 'Could not load your package: $e';
    notifyListeners();
  }

  /// Deliverables the client must look at (CL-UC5, CL-UC8).
  List<ContentTask> get awaitingMyApproval =>
      _tasks.where((t) => t.status == TaskStatus.awaitingApproval).toList();

  int get inProgressCount => _tasks
      .where((t) =>
          t.status == TaskStatus.todo ||
          t.status == TaskStatus.inProgress ||
          t.status == TaskStatus.changesRequested)
      .length;

  int get approvedCount => _tasks.where((t) => t.status == TaskStatus.approved).length;

  /// Content planned to go out in the next 7 days (CL-UC3).
  List<ContentTask> get nextSevenDays {
    final start = DateTime(now.year, now.month, now.day);
    final end = start.add(const Duration(days: 8));
    return _tasks
        .where((t) => !t.calendarDate.isBefore(start) && t.calendarDate.isBefore(end))
        .toList()
      ..sort((a, b) => a.calendarDate.compareTo(b.calendarDate));
  }

  @override
  void dispose() {
    _packageSub?.cancel();
    _taskSub?.cancel();
    super.dispose();
  }
}
