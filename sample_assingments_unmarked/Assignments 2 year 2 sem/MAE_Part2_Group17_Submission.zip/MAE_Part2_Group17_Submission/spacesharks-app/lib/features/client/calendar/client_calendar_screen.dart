import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../shared/calendar/weekly_calendar.dart';
import '../../shared/task_detail/task_detail_screen.dart';

/// Client: what is planned for the coming weeks (CL-UC3).
class ClientCalendarScreen extends StatelessWidget {
  const ClientCalendarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scope = AppScope.of(context);
    return StreamBuilder<List<ClientPackage>>(
      stream: scope.services.packages.watchForClient(scope.user.id),
      builder: (context, packages) {
        if (!packages.hasData) return const LoadingView();
        if (packages.data!.isEmpty) return const EmptyState(icon: Icons.calendar_month_outlined, title: 'No package yet');
        final package = packages.data!.first;
        return StreamBuilder<List<ContentTask>>(
          stream: scope.services.tasks.watchForPackage(package.id),
          builder: (context, tasks) {
            if (!tasks.hasData) return const LoadingView();
            return MaxWidth(
              maxWidth: 820,
              child: ListView(padding: const EdgeInsets.all(16), children: [
                PhaseStepper(current: package.phase),
                const SizedBox(height: 8),
                WeeklyCalendar(
                  tasks: tasks.data!,
                  showAssignee: false,
                  onTaskTap: (t) => TaskDetailScreen.open(context, t.id),
                ),
              ]),
            );
          },
        );
      },
    );
  }
}
