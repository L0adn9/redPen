import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/app_scope.dart';
import '../../../core/data/holiday_service.dart';
import '../../../core/models/models.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/common_widgets.dart';
import '../task_card.dart';

/// Weekly content calendar shared by all three roles
/// (OM-UC6, ST-UC8, CL-UC3).
///
/// Third-party API: public holidays come from the Nager.Date API
/// (HolidayService). Holidays are shown on their day, and a task scheduled
/// on a holiday gets a warning. Each task can be added to Google Calendar.
class WeeklyCalendar extends StatefulWidget {
  const WeeklyCalendar({super.key, required this.tasks, this.onTaskTap, this.initialWeek, this.showAssignee = true});

  final List<ContentTask> tasks;
  final void Function(ContentTask task)? onTaskTap;

  /// Any day in the week to show first (defaults to this week).
  final DateTime? initialWeek;
  final bool showAssignee;

  @override
  State<WeeklyCalendar> createState() => _WeeklyCalendarState();
}

class _WeeklyCalendarState extends State<WeeklyCalendar> {
  late DateTime _weekStart = startOfWeek(widget.initialWeek ?? DateTime.now());
  Future<List<Holiday>>? _holidays;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _holidays ??= _load();
  }

  Future<List<Holiday>> _load() =>
      AppScope.of(context).services.holidays.holidaysInWeek(_weekStart);

  void _move(int weeks) => setState(() {
        _weekStart = _weekStart.add(Duration(days: 7 * weeks));
        _holidays = _load();
      });

  Future<void> _addToGoogle(ContentTask t) async {
    final url = googleCalendarLink(
      title: '${t.clientName}: ${t.title}',
      start: t.calendarDate,
      details: '${t.contentType.label} for ${t.clientName}. Assigned to ${t.assigneeName}. Status: ${t.status.label}.',
    );
    final ok = await launchUrl(url, mode: LaunchMode.externalApplication);
    if (!ok && mounted) showMessage(context, 'Could not open Google Calendar.', error: true);
  }

  @override
  Widget build(BuildContext context) {
    final days = [for (var i = 0; i < 7; i++) _weekStart.add(Duration(days: i))];
    final today = dateOnly(DateTime.now());
    return FutureBuilder<List<Holiday>>(
      future: _holidays,
      builder: (context, snapshot) {
        final holidays = snapshot.data ?? const <Holiday>[];
        List<Holiday> holidaysOn(DateTime day) => holidays.where((h) => dateOnly(h.date) == day).toList();
        final weekTasks = widget.tasks.where((t) {
          final d = dateOnly(t.calendarDate);
          return !d.isBefore(days.first) && !d.isAfter(days.last);
        }).length;
        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            IconButton(key: const Key('prevWeek'), tooltip: 'Previous week', onPressed: () => _move(-1), icon: const Icon(Icons.chevron_left)),
            Expanded(
              child: Column(children: [
                Text('${formatDay(days.first)} - ${formatDay(days.last)}',
                    textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
                Text('$weekTasks planned${holidays.isEmpty ? '' : ' · ${holidays.length} public holiday${holidays.length == 1 ? '' : 's'}'}',
                    style: const TextStyle(color: AppColors.muted, fontSize: 12)),
              ]),
            ),
            IconButton(key: const Key('nextWeek'), tooltip: 'Next week', onPressed: () => _move(1), icon: const Icon(Icons.chevron_right)),
          ]),
          for (final day in days) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 14, 4, 6),
              child: Row(children: [
                Text(formatDay(day) + (day == today ? '  ·  Today' : ''),
                    style: TextStyle(fontWeight: FontWeight.w700, color: day == today ? AppColors.orange : AppColors.ink)),
                const SizedBox(width: 8),
                for (final h in holidaysOn(day))
                  Flexible(child: Pill(label: h.name, color: AppColors.red, icon: Icons.celebration_outlined)),
              ]),
            ),
            for (final t in widget.tasks.where((t) => dateOnly(t.calendarDate) == day))
              Card(
                margin: const EdgeInsets.only(bottom: 6),
                child: ListTile(
                  dense: true,
                  leading: Icon(contentTypeIcon(t.contentType)),
                  title: Text(t.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text([t.clientName, if (widget.showAssignee) t.assigneeName].join(' · ')),
                    const SizedBox(height: 4),
                    Wrap(spacing: 6, runSpacing: 4, children: [
                      StatusChip(t.status),
                      if (holidaysOn(day).isNotEmpty)
                        const Pill(label: 'Posting on a holiday', color: AppColors.red, icon: Icons.warning_amber_rounded),
                    ]),
                  ]),
                  trailing: IconButton(
                    tooltip: 'Add to Google Calendar',
                    icon: const Icon(Icons.edit_calendar_outlined),
                    onPressed: () => _addToGoogle(t),
                  ),
                  onTap: widget.onTaskTap == null ? null : () => widget.onTaskTap!(t),
                ),
              ),
            if (!widget.tasks.any((t) => dateOnly(t.calendarDate) == day))
              const Padding(
                padding: EdgeInsets.only(left: 4),
                child: Text('Nothing planned', style: TextStyle(color: AppColors.muted, fontSize: 13)),
              ),
          ],
          const SizedBox(height: 12),
          const Text('Public holidays: Nager.Date API (date.nager.at)',
              textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 11)),
        ]);
      },
    );
  }
}
