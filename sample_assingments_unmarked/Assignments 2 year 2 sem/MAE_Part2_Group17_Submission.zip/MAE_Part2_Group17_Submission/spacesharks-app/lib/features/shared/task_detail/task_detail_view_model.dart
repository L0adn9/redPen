import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../../core/data/file_storage.dart';
import '../../../core/models/models.dart';
import '../../../core/services/app_services.dart';
import '../../../core/services/file_picker_service.dart';
import '../../../core/utils/safe_notifier.dart';

/// State and actions for one task/deliverable. The same screen is used by
/// all three roles; what each role can do is decided here (can... getters)
/// so the rules are testable.
class TaskDetailViewModel extends ChangeNotifier with SafeChangeNotifier {
  TaskDetailViewModel(this._services, this.user, this.taskId);

  final AppServices _services;
  final AppUser user;
  final String taskId;
  StreamSubscription<ContentTask?>? _sub;

  ContentTask? _task;
  bool _loaded = false;
  bool _busy = false;
  String? _error;

  ContentTask? get task => _task;
  bool get isLoading => !_loaded;
  bool get notFound => _loaded && _task == null;
  bool get isBusy => _busy;
  String? get error => _error;

  void start() {
    _sub = _services.tasks.watchById(taskId).listen((t) {
      _task = t;
      _loaded = true;
      notifyListeners();
    }, onError: (Object e) {
      _error = 'Could not load this task: $e';
      _loaded = true;
      notifyListeners();
    });
  }

  bool get _isOwner => user.role == UserRole.owner;
  bool get _isStaff => user.role == UserRole.staff;
  bool get _isAssignee => _task?.assigneeId == user.id;

  // ----- what this user may do -----

  /// Client decides only when a version is waiting for them (CL-UC5).
  bool get canDecide =>
      user.role == UserRole.client && _task?.status == TaskStatus.awaitingApproval;

  bool get canStart => (_isStaff && _isAssignee) && _task?.status == TaskStatus.todo;

  bool get canUpload =>
      (_isStaff && _isAssignee || _isOwner) && _task?.status != TaskStatus.approved;

  bool get canSubmit =>
      (_isStaff && _isAssignee || _isOwner) &&
      (_task?.latestVersion ?? 0) > 0 &&
      (_task?.status == TaskStatus.inProgress || _task?.status == TaskStatus.changesRequested);

  bool get canHandOver => _isStaff && _isAssignee && _task?.status.isOpen == true;

  bool get canSendStatus => _isStaff && _isAssignee;

  bool get canEditOrDelete => _isOwner;

  bool get canRequestStatus => _isOwner && _task?.status.isOpen == true;

  // ----- actions; each returns a message for the screen, null on error -----

  Future<String?> _run(Future<void> Function() action, String success) async {
    _busy = true;
    _error = null;
    notifyListeners();
    try {
      await action();
      return success;
    } on FileTooLargeException catch (e) {
      _error = e.toString();
      return null;
    } catch (e) {
      _error = 'Something went wrong: $e';
      return null;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  Future<String?> approve({String note = ''}) => _run(
      () => _services.feedback.recordDecision(
          task: _task!, client: user, decision: ApprovalDecision.approved, note: note),
      'Approved. The team has been notified.');

  Future<String?> requestChanges(String note) => _run(
      () => _services.feedback.recordDecision(
          task: _task!, client: user, decision: ApprovalDecision.changesRequested, note: note),
      'Change request sent.');

  Future<String?> startWork() => _run(
      () => _services.tasks.updateStatus(taskId, TaskStatus.inProgress), 'Marked as in progress.');

  Future<String?> upload(PickedFile file, {String note = ''}) => _run(
      () => _services.files.uploadVersion(
            task: _task!,
            uploader: user,
            fileName: file.name,
            bytes: file.bytes,
            mimeType: file.mimeType,
            note: note,
          ),
      'Version ${(_task?.latestVersion ?? 0) + 1} uploaded.');

  Future<String?> submitForApproval() =>
      _run(() => _services.feedback.submitForApproval(_task!), 'Sent to the client for approval.');

  Future<String?> handOver(AppUser to, String note) => _run(
      () => _services.files.handOver(task: _task!, from: user, to: to, note: note),
      'Handed over to ${to.name}.');

  Future<String?> sendStatusUpdate(String message) => _run(
      () => _services.alerts.sendStatusUpdate(task: _task!, staff: user, message: message),
      'Status update sent to the manager.');

  Future<String?> requestStatus() => _run(
      () => _services.alerts.requestStatus(task: _task!, owner: user),
      'Status update requested from ${_task?.assigneeName}.');

  Future<String?> delete() =>
      _run(() => _services.tasks.delete(_task!), 'Task deleted.');

  /// Colleagues this user can hand work to.
  Future<List<AppUser>> colleagues() async =>
      (await _services.users.getByRole(UserRole.staff)).where((u) => u.id != user.id).toList()
        ..sort((a, b) => a.name.compareTo(b.name));

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
