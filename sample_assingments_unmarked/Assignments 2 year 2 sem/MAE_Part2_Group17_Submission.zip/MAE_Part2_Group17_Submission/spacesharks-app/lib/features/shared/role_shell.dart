import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/models/models.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/responsive.dart';
import '../../core/widgets/common_widgets.dart';
import 'alerts_screen.dart';

/// One tab of a role's home.
class RoleTab {
  const RoleTab({required this.label, required this.icon, required this.selectedIcon, required this.builder});
  final String label;
  final IconData icon;
  final IconData selectedIcon;
  final WidgetBuilder builder;
}

/// The frame every role home uses: app bar with alerts bell and account
/// menu, bottom navigation on phones, side rail on tablets (adaptive design).
/// Owned by: Hassan. Roles only pass their tabs.
class RoleShell extends StatefulWidget {
  const RoleShell({super.key, required this.tabs});
  final List<RoleTab> tabs;

  @override
  State<RoleShell> createState() => _RoleShellState();
}

class _RoleShellState extends State<RoleShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final tablet = Responsive.isTablet(context);
    final tab = widget.tabs[_index];
    final body = IndexedStack(
      index: _index,
      children: [for (final t in widget.tabs) Builder(builder: t.builder)],
    );
    return Scaffold(
      appBar: AppBar(
        title: Text(tab.label),
        actions: const [AlertsBell(), _AccountMenu(), SizedBox(width: 8)],
      ),
      body: tablet
          ? Row(children: [
              NavigationRail(
                selectedIndex: _index,
                onDestinationSelected: (i) => setState(() => _index = i),
                labelType: NavigationRailLabelType.all,
                indicatorColor: AppColors.orange.withValues(alpha: 0.16),
                destinations: [
                  for (final t in widget.tabs)
                    NavigationRailDestination(
                        icon: Icon(t.icon), selectedIcon: Icon(t.selectedIcon), label: Text(t.label)),
                ],
              ),
              const VerticalDivider(width: 1),
              Expanded(child: body),
            ])
          : body,
      bottomNavigationBar: tablet
          ? null
          : NavigationBar(
              selectedIndex: _index,
              onDestinationSelected: (i) => setState(() => _index = i),
              destinations: [
                for (final t in widget.tabs)
                  NavigationDestination(
                      icon: Icon(t.icon), selectedIcon: Icon(t.selectedIcon), label: t.label),
              ],
            ),
    );
  }
}

/// Bell with the number of unread alerts. Opens the alerts list.
class AlertsBell extends StatelessWidget {
  const AlertsBell({super.key});

  @override
  Widget build(BuildContext context) {
    final scope = AppScope.of(context);
    return StreamBuilder<List<AppAlert>>(
      stream: scope.services.alerts.watchForUser(scope.user.id),
      builder: (context, snapshot) {
        final unread = (snapshot.data ?? const []).where((a) => !a.read).length;
        return IconButton(
          key: const Key('alertsBell'),
          tooltip: 'Alerts',
          onPressed: () => Navigator.of(context)
              .push(MaterialPageRoute<void>(builder: (_) => const AlertsScreen())),
          icon: Badge(
            isLabelVisible: unread > 0,
            label: Text('$unread'),
            backgroundColor: AppColors.orange,
            child: const Icon(Icons.notifications_outlined),
          ),
        );
      },
    );
  }
}

class _AccountMenu extends StatelessWidget {
  const _AccountMenu();

  @override
  Widget build(BuildContext context) {
    final scope = AppScope.of(context);
    final user = scope.user;
    return PopupMenuButton<String>(
      key: const Key('accountMenu'),
      tooltip: 'Account',
      icon: UserAvatar(name: user.name, radius: 16),
      onSelected: (value) {
        if (value == 'logout') scope.session.signOut();
      },
      itemBuilder: (context) => [
        PopupMenuItem<String>(
          enabled: false,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(user.name, style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.ink)),
            Text(user.role.label, style: const TextStyle(fontSize: 12, color: AppColors.muted)),
          ]),
        ),
        const PopupMenuDivider(),
        const PopupMenuItem<String>(
          key: Key('logoutItem'),
          value: 'logout',
          child: ListTile(leading: Icon(Icons.logout), title: Text('Sign out'), contentPadding: EdgeInsets.zero),
        ),
      ],
    );
  }
}
