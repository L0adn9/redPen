import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/models/models.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/responsive.dart';
import '../../core/widgets/common_widgets.dart';
import 'task_detail/task_detail_screen.dart';

/// In-app alerts for whoever is signed in (OM-UC3, ST-UC2, CL-UC8).
/// Owned by: Hassan. Roles create alerts through AlertRepository.send().
class AlertsScreen extends StatelessWidget {
  const AlertsScreen({super.key});

  static IconData iconFor(AlertType type) => switch (type) {
        AlertType.overdue => Icons.warning_amber_rounded,
        AlertType.approvalNeeded => Icons.fact_check_outlined,
        AlertType.newTask => Icons.add_task,
        AlertType.taskChanged => Icons.edit_calendar_outlined,
        AlertType.statusRequest => Icons.help_outline,
        AlertType.feedback => Icons.forum_outlined,
        AlertType.handover => Icons.swap_horiz,
        AlertType.overload => Icons.local_fire_department_outlined,
        AlertType.general => Icons.notifications_outlined,
      };

  @override
  Widget build(BuildContext context) {
    final scope = AppScope.of(context);
    final alerts = scope.services.alerts;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alerts'),
        actions: [
          TextButton(
            onPressed: () => alerts.markAllRead(scope.user.id),
            child: const Text('Mark all read'),
          ),
        ],
      ),
      body: StreamBuilder<List<AppAlert>>(
        stream: alerts.watchForUser(scope.user.id),
        builder: (context, snapshot) {
          if (snapshot.hasError) return ErrorView(message: '${snapshot.error}');
          if (!snapshot.hasData) return const LoadingView();
          final items = snapshot.data!;
          if (items.isEmpty) {
            return const EmptyState(
                icon: Icons.notifications_none, title: 'No alerts', message: 'You are all caught up.');
          }
          final now = DateTime.now();
          return MaxWidth(
            maxWidth: 720,
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: items.length,
              separatorBuilder: (context, index) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final a = items[i];
                final urgent = a.type == AlertType.overdue || a.type == AlertType.overload;
                return Card(
                  color: a.read ? AppColors.card : AppColors.orange.withValues(alpha: 0.06),
                  child: ListTile(
                    leading: Icon(iconFor(a.type), color: urgent ? AppColors.red : AppColors.orange),
                    title: Text(a.title,
                        style: TextStyle(fontWeight: a.read ? FontWeight.w500 : FontWeight.w700)),
                    subtitle: Text('${a.body}\n${a.type.label} · ${formatAgo(a.createdAt, now)}'),
                    isThreeLine: true,
                    onTap: () {
                      if (!a.read) alerts.markRead(a.id);
                      if (a.taskId != null) TaskDetailScreen.open(context, a.taskId!);
                    },
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
