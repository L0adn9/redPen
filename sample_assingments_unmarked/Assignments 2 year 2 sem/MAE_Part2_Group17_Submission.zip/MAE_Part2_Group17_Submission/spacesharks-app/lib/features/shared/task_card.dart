import 'package:flutter/material.dart';

import '../../core/models/models.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/common_widgets.dart';

IconData contentTypeIcon(ContentType type) => switch (type) {
      ContentType.post => Icons.image_outlined,
      ContentType.reel => Icons.movie_outlined,
      ContentType.graphic => Icons.brush_outlined,
      ContentType.story => Icons.amp_stories_outlined,
      ContentType.caption => Icons.short_text,
    };

/// One task/deliverable row, used by all three roles.
class TaskCard extends StatelessWidget {
  const TaskCard({super.key, required this.task, required this.now, this.onTap, this.showAssignee = false, this.showClient = true});
  final ContentTask task;
  final DateTime now;
  final VoidCallback? onTap;
  final bool showAssignee;
  final bool showClient;

  @override
  Widget build(BuildContext context) {
    final overdue = task.isOverdue(now);
    final meta = [
      if (showClient) task.clientName,
      if (showAssignee) task.assigneeName,
      task.contentType.label,
    ].join(' · ');
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppColors.background,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(contentTypeIcon(task.contentType), color: AppColors.ink),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(task.title,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                const SizedBox(height: 2),
                Text(meta, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                const SizedBox(height: 8),
                Wrap(spacing: 6, runSpacing: 6, crossAxisAlignment: WrapCrossAlignment.center, children: [
                  StatusChip(task.status),
                  if (task.status.isOpen) PriorityChip(task.priority),
                  if (task.status.isOpen)
                    Text(formatDue(task.dueDate, now),
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: overdue ? AppColors.red : AppColors.muted,
                        )),
                ]),
              ]),
            ),
            if (onTap != null) const Icon(Icons.chevron_right, color: AppColors.muted),
          ]),
        ),
      ),
    );
  }
}
