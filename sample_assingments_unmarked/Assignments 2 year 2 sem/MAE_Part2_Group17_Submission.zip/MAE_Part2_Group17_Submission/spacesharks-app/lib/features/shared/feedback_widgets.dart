import 'package:flutter/material.dart';

import '../../core/app_scope.dart';
import '../../core/models/models.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/utils/validators.dart';
import '../../core/widgets/common_widgets.dart';
import '../../core/widgets/file_preview.dart';

// Ready-made building blocks for any task/deliverable detail screen.
// Staff task detail (Muntasir), client deliverable page (Hassan) and owner
// package detail (Kaung) all drop these in, so nobody waits on anybody.

/// Feedback thread with a reply box (ST-UC4, CL-UC4, CL-UC7).
/// When agency staff open it, client comments are marked as seen.
class CommentThread extends StatefulWidget {
  const CommentThread({super.key, required this.task});
  final ContentTask task;

  @override
  State<CommentThread> createState() => _CommentThreadState();
}

class _CommentThreadState extends State<CommentThread> {
  final _formKey = GlobalKey<FormState>();
  final _text = TextEditingController();
  bool _sending = false;
  bool _markedSeen = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final scope = AppScope.of(context);
    if (!_markedSeen && scope.user.role != UserRole.client) {
      _markedSeen = true;
      scope.services.feedback.markClientCommentsSeen(widget.task.id);
    }
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (!_formKey.currentState!.validate()) return;
    final scope = AppScope.of(context);
    setState(() => _sending = true);
    try {
      await scope.services.feedback
          .addComment(task: widget.task, author: scope.user, text: _text.text);
      _text.clear();
    } catch (e) {
      if (mounted) showMessage(context, 'Could not send: $e', error: true);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scope = AppScope.of(context);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      StreamBuilder<List<TaskComment>>(
        stream: scope.services.feedback.watchComments(widget.task.id),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Padding(padding: EdgeInsets.all(16), child: LoadingView());
          final comments = snapshot.data!;
          if (comments.isEmpty) {
            return const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Text('No feedback yet.', style: TextStyle(color: AppColors.muted)),
            );
          }
          return Column(children: [
            for (final c in comments) _Bubble(comment: c, mine: c.authorId == scope.user.id),
          ]);
        },
      ),
      const SizedBox(height: 8),
      Form(
        key: _formKey,
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: TextFormField(
              key: const Key('commentField'),
              controller: _text,
              minLines: 1,
              maxLines: 4,
              decoration: const InputDecoration(hintText: 'Write feedback or a reply'),
              validator: Validators.all([
                Validators.required('Message'),
                Validators.maxLength('Message', 500),
              ]),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filled(
            key: const Key('sendCommentButton'),
            tooltip: 'Send',
            onPressed: _sending ? null : _send,
            icon: const Icon(Icons.send),
          ),
        ]),
      ),
    ]);
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.comment, required this.mine});
  final TaskComment comment;
  final bool mine;

  @override
  Widget build(BuildContext context) {
    final c = comment;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(12),
        constraints: const BoxConstraints(maxWidth: 480),
        decoration: BoxDecoration(
          color: mine ? AppColors.orange.withValues(alpha: 0.12) : AppColors.background,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${c.authorName} · ${c.authorRole.label}',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(c.text),
          const SizedBox(height: 4),
          Text(
            [
              formatDateTime(c.createdAt),
              if (c.isFromClient)
                c.seenByAgency
                    ? 'Seen by agency${c.seenAt == null ? '' : ' ${formatTime(c.seenAt!)}'}'
                    : 'Not seen yet',
            ].join(' · '),
            style: const TextStyle(fontSize: 11, color: AppColors.muted),
          ),
        ]),
      ),
    );
  }
}

/// All uploaded versions, newest first, with a preview of the latest and the
/// approved one marked "Final" (ST-UC5, CL-UC6).
class VersionList extends StatelessWidget {
  const VersionList({super.key, required this.task});
  final ContentTask task;

  @override
  Widget build(BuildContext context) {
    final files = AppScope.of(context).services.files;
    return StreamBuilder<List<FileVersion>>(
      stream: files.watchVersions(task.id),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const LoadingView();
        final versions = snapshot.data!;
        if (versions.isEmpty) {
          return const Text('No files uploaded yet.', style: TextStyle(color: AppColors.muted));
        }
        return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          FilePreview(version: versions.first),
          const SizedBox(height: 8),
          for (final v in versions)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                backgroundColor: AppColors.background,
                child: Text('v${v.versionNumber}',
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.ink)),
              ),
              title: Text(v.fileName),
              subtitle: Text('${v.uploadedByName} · ${formatDateTime(v.createdAt)}'
                  '${v.note.isEmpty ? '' : '\n${v.note}'}'),
              trailing: task.approvedVersion == v.versionNumber
                  ? const Pill(label: 'Final', color: AppColors.green, icon: Icons.verified)
                  : null,
            ),
        ]);
      },
    );
  }
}

/// Timestamped approvals and change requests (OM-UC5, ST-UC7, CL-UC5).
class ApprovalHistory extends StatelessWidget {
  const ApprovalHistory({super.key, required this.task});
  final ContentTask task;

  @override
  Widget build(BuildContext context) {
    final feedback = AppScope.of(context).services.feedback;
    return StreamBuilder<List<Approval>>(
      stream: feedback.watchApprovals(task.id),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const LoadingView();
        final approvals = snapshot.data!;
        if (approvals.isEmpty) {
          return const Text('No decisions yet.', style: TextStyle(color: AppColors.muted));
        }
        return Column(children: [
          for (final a in approvals)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(
                a.decision == ApprovalDecision.approved ? Icons.check_circle : Icons.change_circle,
                color: a.decision == ApprovalDecision.approved ? AppColors.green : AppColors.red,
              ),
              title: Text('${a.decision.label} · v${a.versionNumber}'),
              subtitle: Text('${a.byName} · ${formatDateTime(a.createdAt)}'
                  '${a.note.isEmpty ? '' : '\n"${a.note}"'}'),
            ),
        ]);
      },
    );
  }
}
