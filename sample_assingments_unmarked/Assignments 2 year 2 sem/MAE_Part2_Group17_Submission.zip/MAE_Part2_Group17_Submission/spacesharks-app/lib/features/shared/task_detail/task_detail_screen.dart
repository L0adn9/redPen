import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/services/file_picker_service.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../../core/widgets/dialogs.dart';
import '../../owner/tasks/task_form_screen.dart';
import '../feedback_widgets.dart';
import '../task_card.dart';
import 'task_detail_view_model.dart';

/// One deliverable, seen by any role (proposal Figure 8).
/// Everyone sees the details, files, approval history and feedback thread;
/// the action buttons depend on the role:
///   Client - approve / request changes (CL-UC5)
///   Staff  - start, upload a version, send for approval, hand over, status
///   Owner  - edit, delete, request a status update, upload
class TaskDetailScreen extends StatefulWidget {
  const TaskDetailScreen({super.key, required this.taskId, this.filePicker = const FilePickerService()});
  final String taskId;
  final FilePickerService filePicker;

  static Future<void> open(BuildContext context, String taskId) => Navigator.of(context)
      .push(MaterialPageRoute<void>(builder: (_) => TaskDetailScreen(taskId: taskId)));

  @override
  State<TaskDetailScreen> createState() => _TaskDetailScreenState();
}

class _TaskDetailScreenState extends State<TaskDetailScreen> {
  TaskDetailViewModel? _vm;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final scope = AppScope.of(context);
    _vm ??= TaskDetailViewModel(scope.services, scope.user, widget.taskId)..start();
  }

  @override
  void dispose() {
    _vm?.dispose();
    super.dispose();
  }

  void _done(String? message) {
    if (!mounted) return;
    if (message != null) {
      showMessage(context, message);
    } else if (_vm!.error != null) {
      showMessage(context, _vm!.error!, error: true);
    }
  }

  Future<void> _approve() async {
    final note = await askForText(context,
        title: 'Approve this version?', label: 'Comment (optional)', confirmLabel: 'Approve');
    if (note != null) _done(await _vm!.approve(note: note));
  }

  Future<void> _requestChanges() async {
    final note = await askForText(context,
        title: 'Request changes',
        label: 'What should change?',
        hint: 'e.g. Make the logo bigger',
        confirmLabel: 'Send request',
        required: true);
    if (note != null) _done(await _vm!.requestChanges(note));
  }

  Future<void> _upload() async {
    final file = await widget.filePicker.pick();
    if (file == null || !mounted) return;
    final note = await askForText(context,
        title: 'Upload ${file.name}', label: 'What changed? (optional)', confirmLabel: 'Upload');
    if (note != null) _done(await _vm!.upload(file, note: note));
  }

  Future<void> _submit() async {
    final ok = await confirmAction(context,
        title: 'Send for approval?',
        message: 'The client will be asked to review version ${_vm!.task!.latestVersion}.',
        confirmLabel: 'Send');
    if (ok) _done(await _vm!.submitForApproval());
  }

  Future<void> _handOver() async {
    final people = await _vm!.colleagues();
    if (!mounted) return;
    final to = await showModalBottomSheet<AppUser>(
      context: context,
      builder: (context) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const ListTile(title: Text('Hand over to', style: TextStyle(fontWeight: FontWeight.w700))),
          for (final p in people)
            ListTile(
              leading: UserAvatar(name: p.name),
              title: Text(p.name),
              subtitle: Text(p.jobTitle),
              onTap: () => Navigator.pop(context, p),
            ),
        ]),
      ),
    );
    if (to == null || !mounted) return;
    final note = await askForText(context,
        title: 'Hand over to ${to.name}', label: 'Note (what are you handing over?)', required: true);
    if (note != null) _done(await _vm!.handOver(to, note));
  }

  Future<void> _sendStatus() async {
    final text = await askForText(context,
        title: 'Send a status update',
        label: 'Status',
        hint: 'e.g. 80% done, final version tomorrow 10am',
        required: true);
    if (text != null) _done(await _vm!.sendStatusUpdate(text));
  }

  Future<void> _delete() async {
    final ok = await confirmAction(context,
        title: 'Delete this task?',
        message: '"${_vm!.task!.title}" will be removed and ${_vm!.task!.assigneeName} will be told.',
        confirmLabel: 'Delete',
        destructive: true);
    if (!ok) return;
    final message = await _vm!.delete();
    if (!mounted) return;
    if (message != null) Navigator.of(context).pop();
    _done(message);
  }

  @override
  Widget build(BuildContext context) {
    final vm = _vm!;
    return ListenableBuilder(
      listenable: vm,
      builder: (context, _) {
        final task = vm.task;
        return Scaffold(
          appBar: AppBar(
            title: Text(task?.title ?? 'Task'),
            actions: [
              if (task != null && vm.canEditOrDelete)
                PopupMenuButton<String>(
                  key: const Key('taskMenu'),
                  onSelected: (v) {
                    if (v == 'edit') {
                      Navigator.of(context).push(MaterialPageRoute<void>(
                          builder: (_) => TaskFormScreen(packageId: task.packageId, existing: task)));
                    } else if (v == 'delete') {
                      _delete();
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: ListTile(leading: Icon(Icons.edit_outlined), title: Text('Edit task'), contentPadding: EdgeInsets.zero)),
                    PopupMenuItem(value: 'delete', child: ListTile(leading: Icon(Icons.delete_outline, color: AppColors.red), title: Text('Delete task'), contentPadding: EdgeInsets.zero)),
                  ],
                ),
            ],
          ),
          body: () {
            if (vm.isLoading) return const LoadingView();
            if (vm.notFound) {
              return const EmptyState(icon: Icons.search_off, title: 'This task no longer exists');
            }
            return MaxWidth(
              maxWidth: 820,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _InfoCard(task: task!),
                  if (vm.canDecide) ...[
                    const SizedBox(height: 12),
                    _DecisionPanel(busy: vm.isBusy, onApprove: _approve, onRequestChanges: _requestChanges, version: task.latestVersion),
                  ],
                  if (_hasActions(vm)) ...[
                    const SizedBox(height: 12),
                    _ActionBar(vm: vm, onStart: () async => _done(await vm.startWork()), onUpload: _upload, onSubmit: _submit, onHandOver: _handOver, onSendStatus: _sendStatus, onRequestStatus: () async => _done(await vm.requestStatus())),
                  ],
                  const SectionHeader('Files'),
                  VersionList(task: task),
                  const SectionHeader('Approval history'),
                  ApprovalHistory(task: task),
                  const SectionHeader('Feedback'),
                  CommentThread(task: task),
                  const SizedBox(height: 24),
                ],
              ),
            );
          }(),
        );
      },
    );
  }

  bool _hasActions(TaskDetailViewModel vm) =>
      vm.canStart || vm.canUpload || vm.canSubmit || vm.canHandOver || vm.canSendStatus || vm.canRequestStatus;
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.task});
  final ContentTask task;

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    Widget row(IconData icon, String label, String value, {Color? color}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [
            Icon(icon, size: 18, color: AppColors.muted),
            const SizedBox(width: 10),
            SizedBox(width: 92, child: Text(label, style: const TextStyle(color: AppColors.muted))),
            Expanded(child: Text(value, style: TextStyle(fontWeight: FontWeight.w600, color: color))),
          ]),
        );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Wrap(spacing: 6, runSpacing: 6, children: [
            StatusChip(task.status),
            PriorityChip(task.priority),
            Pill(label: task.contentType.label, color: AppColors.ink, icon: contentTypeIcon(task.contentType)),
          ]),
          const SizedBox(height: 12),
          row(Icons.storefront_outlined, 'Client', task.clientName),
          row(Icons.person_outline, 'Assigned to', task.assigneeName),
          row(Icons.event_outlined, 'Due', '${formatDay(task.dueDate)} · ${formatTime(task.dueDate)}'
              '${task.status.isOpen ? '  (${formatDue(task.dueDate, now)})' : ''}',
              color: task.isOverdue(now) ? AppColors.red : null),
          if (task.publishDate != null)
            row(Icons.campaign_outlined, 'Publishing', formatDay(task.publishDate!)),
          row(Icons.layers_outlined, 'Version', task.latestVersion == 0
              ? 'No files yet'
              : 'v${task.latestVersion}${task.approvedVersion != null ? ' (v${task.approvedVersion} approved)' : ''}'),
          if (task.description.isNotEmpty) ...[
            const Divider(height: 24),
            Text(task.description),
          ],
        ]),
      ),
    );
  }
}

class _DecisionPanel extends StatelessWidget {
  const _DecisionPanel({required this.busy, required this.onApprove, required this.onRequestChanges, required this.version});
  final bool busy;
  final VoidCallback onApprove;
  final VoidCallback onRequestChanges;
  final int version;

  @override
  Widget build(BuildContext context) => Card(
        color: AppColors.amber.withValues(alpha: 0.08),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('Version $version is waiting for your decision',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            const SizedBox(height: 4),
            const Text('Your decision is saved with the date and time.', style: TextStyle(color: AppColors.muted)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  key: const Key('requestChangesButton'),
                  onPressed: busy ? null : onRequestChanges,
                  icon: const Icon(Icons.edit_note),
                  label: const Text('Request changes'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  key: const Key('approveButton'),
                  style: FilledButton.styleFrom(backgroundColor: AppColors.green),
                  onPressed: busy ? null : onApprove,
                  icon: const Icon(Icons.check),
                  label: const Text('Approve'),
                ),
              ),
            ]),
          ]),
        ),
      );
}

class _ActionBar extends StatelessWidget {
  const _ActionBar({required this.vm, required this.onStart, required this.onUpload, required this.onSubmit, required this.onHandOver, required this.onSendStatus, required this.onRequestStatus});
  final TaskDetailViewModel vm;
  final VoidCallback onStart;
  final VoidCallback onUpload;
  final VoidCallback onSubmit;
  final VoidCallback onHandOver;
  final VoidCallback onSendStatus;
  final VoidCallback onRequestStatus;

  @override
  Widget build(BuildContext context) {
    final busy = vm.isBusy;
    return Wrap(spacing: 8, runSpacing: 8, children: [
      if (vm.canStart)
        FilledButton.icon(key: const Key('startButton'), onPressed: busy ? null : onStart, icon: const Icon(Icons.play_arrow), label: const Text('Start work')),
      if (vm.canUpload)
        OutlinedButton.icon(key: const Key('uploadButton'), onPressed: busy ? null : onUpload, icon: const Icon(Icons.upload_file), label: const Text('Upload version')),
      if (vm.canSubmit)
        FilledButton.icon(key: const Key('submitButton'), onPressed: busy ? null : onSubmit, icon: const Icon(Icons.send), label: const Text('Send for approval')),
      if (vm.canHandOver)
        OutlinedButton.icon(key: const Key('handOverButton'), onPressed: busy ? null : onHandOver, icon: const Icon(Icons.swap_horiz), label: const Text('Hand over')),
      if (vm.canSendStatus)
        OutlinedButton.icon(key: const Key('statusButton'), onPressed: busy ? null : onSendStatus, icon: const Icon(Icons.chat_outlined), label: const Text('Send status')),
      if (vm.canRequestStatus)
        OutlinedButton.icon(key: const Key('requestStatusButton'), onPressed: busy ? null : onRequestStatus, icon: const Icon(Icons.help_outline), label: const Text('Request status')),
    ]);
  }
}
