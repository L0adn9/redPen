import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../../core/widgets/dialogs.dart';
import '../../shared/task_card.dart';
import '../../shared/task_detail/task_detail_screen.dart';
import '../dashboard/owner_dashboard_view_model.dart';
import '../tasks/task_form_screen.dart';
import 'package_detail_view_model.dart';
import 'package_form_screen.dart';

Color healthColor(PackageHealth h) => switch (h) {
      PackageHealth.onTrack => AppColors.green,
      PackageHealth.atRisk => AppColors.amber,
      PackageHealth.behind => AppColors.red,
    };

/// Owner view of one client package.
class PackageDetailScreen extends StatefulWidget {
  const PackageDetailScreen({super.key, required this.packageId});
  final String packageId;

  @override
  State<PackageDetailScreen> createState() => _PackageDetailScreenState();
}

class _PackageDetailScreenState extends State<PackageDetailScreen> {
  PackageDetailViewModel? _vm;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _vm ??= PackageDetailViewModel(AppScope.of(context).services, widget.packageId)..start();
  }

  @override
  void dispose() {
    _vm?.dispose();
    super.dispose();
  }

  Future<void> _delete() async {
    final p = _vm!.package!;
    final ok = await confirmAction(context,
        title: 'Delete ${p.clientName}?',
        message: 'This removes the package and all of its tasks. This cannot be undone.',
        confirmLabel: 'Delete',
        destructive: true);
    if (!ok) return;
    await _vm!.deletePackage();
    if (!mounted) return;
    Navigator.of(context).pop();
    showMessage(context, 'Package deleted.');
  }

  @override
  Widget build(BuildContext context) {
    final vm = _vm!;
    return ListenableBuilder(
      listenable: vm,
      builder: (context, _) {
        final p = vm.package;
        return Scaffold(
          appBar: AppBar(
            title: Text(p?.clientName ?? 'Package'),
            actions: [
              if (p != null)
                PopupMenuButton<String>(
                  key: const Key('packageMenu'),
                  onSelected: (v) {
                    if (v == 'edit') {
                      Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => PackageFormScreen(existing: p)));
                    } else if (v == 'delete') {
                      _delete();
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: ListTile(leading: Icon(Icons.edit_outlined), title: Text('Edit package'), contentPadding: EdgeInsets.zero)),
                    PopupMenuItem(value: 'delete', child: ListTile(leading: Icon(Icons.delete_outline, color: AppColors.red), title: Text('Delete package'), contentPadding: EdgeInsets.zero)),
                  ],
                ),
            ],
          ),
          floatingActionButton: p == null
              ? null
              : FloatingActionButton.extended(
                  key: const Key('newTaskButton'),
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => TaskFormScreen(packageId: p.id))),
                  icon: const Icon(Icons.add),
                  label: const Text('New task'),
                ),
          body: () {
            if (vm.isLoading) return const LoadingView();
            if (vm.notFound) return const EmptyState(icon: Icons.search_off, title: 'Package not found');
            final s = vm.summary!;
            return MaxWidth(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(child: Text(p!.packageName, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
                          Pill(label: s.health.label, color: healthColor(s.health), icon: Icons.monitor_heart_outlined),
                        ]),
                        Text('Started ${formatDate(p.startDate)} · Manager ${p.managerName}', style: const TextStyle(color: AppColors.muted)),
                        const SizedBox(height: 16),
                        PhaseStepper(current: p.phase),
                        const SizedBox(height: 12),
                        Wrap(spacing: 8, children: [
                          for (final phase in PackagePhase.values)
                            ChoiceChip(
                              label: Text(phase.label),
                              selected: phase == p.phase,
                              onSelected: (_) => vm.setPhase(phase),
                            ),
                        ]),
                        if (p.goals.isNotEmpty) ...[
                          const Divider(height: 24),
                          Text(p.goals),
                        ],
                      ]),
                    ),
                  ),
                  const SizedBox(height: 12),
                  StatRow(children: [
                    StatTile(label: 'Delivered of ${p.promisedItems} promised', value: '${s.delivered}', icon: Icons.verified_outlined, color: AppColors.green),
                    StatTile(label: 'Overdue', value: '${s.overdue}', icon: Icons.warning_amber_rounded, color: AppColors.red),
                    StatTile(label: 'Awaiting client', value: '${s.awaitingApproval}', icon: Icons.hourglass_top, color: AppColors.amber),
                  ]),
                  const SectionHeader('Tasks'),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(children: [
                      ChoiceChip(label: const Text('All'), selected: vm.statusFilter == null, onSelected: (_) => vm.setStatusFilter(null)),
                      for (final st in TaskStatus.values) ...[
                        const SizedBox(width: 8),
                        ChoiceChip(
                          label: Text('${st.label} (${vm.countFor(st)})'),
                          selected: vm.statusFilter == st,
                          onSelected: (_) => vm.setStatusFilter(st),
                        ),
                      ],
                    ]),
                  ),
                  const SizedBox(height: 10),
                  if (vm.tasks.isEmpty) const Text('No tasks here.', style: TextStyle(color: AppColors.muted)),
                  for (final t in vm.tasks)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: TaskCard(task: t, now: vm.now, showClient: false, showAssignee: true, onTap: () => TaskDetailScreen.open(context, t.id)),
                    ),
                  const SectionHeader('Approval log'),
                  if (vm.approvals.isEmpty) const Text('No client decisions yet.', style: TextStyle(color: AppColors.muted)),
                  for (final a in vm.approvals)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(
                        a.decision == ApprovalDecision.approved ? Icons.check_circle : Icons.change_circle,
                        color: a.decision == ApprovalDecision.approved ? AppColors.green : AppColors.red,
                      ),
                      title: Text('${vm.taskTitle(a.taskId)} · v${a.versionNumber}'),
                      subtitle: Text('${a.decision.label} by ${a.byName} · ${formatDateTime(a.createdAt)}'
                          '${a.note.isEmpty ? '' : '\n"${a.note}"'}'),
                    ),
                ],
              ),
            );
          }(),
        );
      },
    );
  }
}
