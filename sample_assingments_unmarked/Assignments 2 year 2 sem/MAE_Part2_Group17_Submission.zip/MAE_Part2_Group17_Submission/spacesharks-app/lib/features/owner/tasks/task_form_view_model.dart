import 'package:flutter/foundation.dart';

import '../../../core/models/models.dart';
import '../../../core/services/app_services.dart';
import '../../../core/utils/safe_notifier.dart';

/// A staff member with how many open tasks they have (shown in the
/// assignee picker so the owner assigns to someone with capacity, OM-UC4).
class StaffOption {
  const StaffOption(this.user, this.openTasks);
  final AppUser user;
  final int openTasks;
}

/// Create or edit a task (owner CRUD). Owned by: owner role.
class TaskFormViewModel extends ChangeNotifier with SafeChangeNotifier {
  TaskFormViewModel(this._services, this.owner, {required this.packageId, this.existing});

  final AppServices _services;
  final AppUser owner;
  final String packageId;
  final ContentTask? existing;

  List<StaffOption> _staff = [];
  ClientPackage? _package;
  bool _loading = true;
  bool _saving = false;
  String? _error;

  bool get isEditing => existing != null;
  bool get isLoading => _loading;
  bool get isSaving => _saving;
  String? get error => _error;
  List<StaffOption> get staff => _staff;
  ClientPackage? get package => _package;

  Future<void> load() async {
    try {
      final people = await _services.users.getByRole(UserRole.staff);
      final allTasks = await _services.tasks.getAll();
      _staff = [
        for (final p in people)
          StaffOption(p, allTasks.where((t) => t.assigneeId == p.id && t.status.isOpen).length),
      ]..sort((a, b) => a.openTasks.compareTo(b.openTasks));
      _package = await _services.packages.getById(packageId);
    } catch (e) {
      _error = 'Could not load the form: $e';
    }
    _loading = false;
    notifyListeners();
  }

  /// Extra checks beyond single fields. Returns an error message or null.
  /// Work is due at 5 PM on the chosen day. If that time has already passed
  /// today, it is due at the end of today instead, so a new task is never
  /// overdue the moment it is created.
  static DateTime dueTimeFor(DateTime date, DateTime now) {
    final fivePm = DateTime(date.year, date.month, date.day, 17);
    return fivePm.isAfter(now) ? fivePm : DateTime(date.year, date.month, date.day, 23, 59);
  }

  static String? checkDates({required DateTime? due, required DateTime? publish}) {
    if (due == null) return 'Pick a due date.';
    if (publish != null &&
        DateTime(publish.year, publish.month, publish.day)
            .isBefore(DateTime(due.year, due.month, due.day))) {
      return 'The publish date cannot be before the due date.';
    }
    return null;
  }

  /// Saves and returns true on success.
  Future<bool> save({
    required String title,
    required String description,
    required ContentType type,
    required AppUser assignee,
    required TaskPriority priority,
    required DateTime due,
    DateTime? publish,
  }) async {
    _saving = true;
    _error = null;
    notifyListeners();
    try {
      final now = DateTime.now();
      final base = existing;
      if (base == null) {
        await _services.tasks.create(ContentTask(
          id: '',
          packageId: packageId,
          clientName: _package?.clientName ?? '',
          title: title.trim(),
          description: description.trim(),
          contentType: type,
          assigneeId: assignee.id,
          assigneeName: assignee.name,
          dueDate: due,
          publishDate: publish,
          priority: priority,
          status: TaskStatus.todo,
          createdById: owner.id,
          createdAt: now,
          updatedAt: now,
        ));
      } else {
        await _services.tasks.update(ContentTask(
          id: base.id,
          packageId: base.packageId,
          clientName: base.clientName,
          title: title.trim(),
          description: description.trim(),
          contentType: type,
          assigneeId: assignee.id,
          assigneeName: assignee.name,
          dueDate: due,
          publishDate: publish,
          priority: priority,
          status: base.status,
          latestVersion: base.latestVersion,
          approvedVersion: base.approvedVersion,
          createdById: base.createdById,
          createdAt: base.createdAt,
          updatedAt: now,
        ));
      }
      return true;
    } catch (e) {
      _error = 'Could not save: $e';
      return false;
    } finally {
      _saving = false;
      notifyListeners();
    }
  }
}
