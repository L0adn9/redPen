import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../shared/calendar/weekly_calendar.dart';
import '../../shared/task_detail/task_detail_screen.dart';

/// Owner weekly content calendar per client with its phase (OM-UC6).
class OwnerCalendarScreen extends StatefulWidget {
  const OwnerCalendarScreen({super.key});

  @override
  State<OwnerCalendarScreen> createState() => _OwnerCalendarScreenState();
}

class _OwnerCalendarScreenState extends State<OwnerCalendarScreen> {
  String? _packageId;

  @override
  Widget build(BuildContext context) {
    final services = AppScope.of(context).services;
    return StreamBuilder<List<ClientPackage>>(
      stream: services.packages.watchAll(),
      builder: (context, packagesSnap) => StreamBuilder<List<ContentTask>>(
        stream: services.tasks.watchAll(),
        builder: (context, tasksSnap) {
          if (!packagesSnap.hasData || !tasksSnap.hasData) return const LoadingView();
          final packages = packagesSnap.data!;
          final selected = packages.where((p) => p.id == _packageId).firstOrNull;
          final tasks = selected == null
              ? tasksSnap.data!
              : tasksSnap.data!.where((t) => t.packageId == selected.id).toList();
          return MaxWidth(
            maxWidth: 820,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: [
                  ChoiceChip(label: const Text('All clients'), selected: selected == null, onSelected: (_) => setState(() => _packageId = null)),
                  for (final p in packages) ...[
                    const SizedBox(width: 8),
                    ChoiceChip(label: Text(p.clientName), selected: p.id == _packageId, onSelected: (_) => setState(() => _packageId = p.id)),
                  ],
                ]),
              ),
              if (selected != null) ...[
                const SizedBox(height: 12),
                PhaseStepper(current: selected.phase),
              ],
              const SizedBox(height: 8),
              WeeklyCalendar(tasks: tasks, onTaskTap: (t) => TaskDetailScreen.open(context, t.id)),
            ]),
          );
        },
      ),
    );
  }
}
