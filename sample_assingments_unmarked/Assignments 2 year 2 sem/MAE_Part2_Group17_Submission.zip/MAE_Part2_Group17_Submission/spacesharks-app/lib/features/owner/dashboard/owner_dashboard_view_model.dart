import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../../core/models/models.dart';
import '../../../core/services/app_services.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/safe_notifier.dart';

/// One package card on the dashboard (OM-UC1, OM-UC2, OM-UC8).
class PackageSummary {
  const PackageSummary({required this.package, required this.tasks, required this.now});
  final ClientPackage package;
  final List<ContentTask> tasks;
  final DateTime now;

  int get delivered => tasks.where((t) => t.status == TaskStatus.approved).length;
  int get overdue => tasks.where((t) => t.isOverdue(now)).length;
  int get awaitingApproval => tasks.where((t) => t.status == TaskStatus.awaitingApproval).length;

  int get dueThisWeek {
    final start = startOfWeek(now);
    final end = start.add(const Duration(days: 7));
    return tasks
        .where((t) => t.status.isOpen && !t.dueDate.isBefore(start) && t.dueDate.isBefore(end))
        .length;
  }

  /// Delivered vs promised, 0..1.
  double get deliveryProgress =>
      package.promisedItems == 0 ? 0 : (delivered / package.promisedItems).clamp(0, 1).toDouble();

  /// Share of this month's delivery period that has passed, 0..1.
  /// A package that started mid-month counts from its start date, so a
  /// package created today has had no time yet and is not "Behind".
  double get monthElapsed {
    final monthStart = DateTime(now.year, now.month, 1);
    final monthEnd = DateTime(now.year, now.month + 1, 1);
    final start = package.startDate.isAfter(monthStart) ? package.startDate : monthStart;
    final total = monthEnd.difference(start).inHours;
    if (total <= 0) return 1;
    return (now.difference(start).inHours / total).clamp(0, 1).toDouble();
  }

  /// Package performance indicator (OM-UC8): compares what has been
  /// delivered with what should have been delivered by today.
  PackageHealth get health {
    final expected = package.promisedItems * monthElapsed;
    if (overdue >= 2) return PackageHealth.behind;
    if (expected <= 0 || delivered >= expected) {
      return overdue > 0 ? PackageHealth.atRisk : PackageHealth.onTrack;
    }
    if (delivered >= expected * 0.6) return PackageHealth.atRisk;
    return PackageHealth.behind;
  }
}

enum PackageHealth {
  onTrack('On track'),
  atRisk('At risk'),
  behind('Behind');

  const PackageHealth(this.label);
  final String label;
}

/// Owner dashboard state. Owned by: Kaung (starter written for the base).
class OwnerDashboardViewModel extends ChangeNotifier with SafeChangeNotifier {
  OwnerDashboardViewModel(this._services, {DateTime Function()? clock})
      : _clock = clock ?? DateTime.now;

  final AppServices _services;
  final DateTime Function() _clock;
  final List<StreamSubscription<Object?>> _subs = [];

  List<ClientPackage> _packages = [];
  List<ContentTask> _tasks = [];
  bool _packagesLoaded = false;
  bool _tasksLoaded = false;
  String? _error;

  bool get isLoading => !(_packagesLoaded && _tasksLoaded) && _error == null;
  String? get error => _error;
  DateTime get now => _clock();

  void start() {
    _subs.add(_services.packages.watchAll().listen((p) {
      _packages = p;
      _packagesLoaded = true;
      notifyListeners();
    }, onError: _onError));
    _subs.add(_services.tasks.watchAll().listen((t) {
      _tasks = t;
      _tasksLoaded = true;
      notifyListeners();
    }, onError: _onError));
  }

  void _onError(Object e) {
    _error = 'Could not load the dashboard: $e';
    notifyListeners();
  }

  List<ClientPackage> get activePackages => _packages.where((p) => p.active).toList();

  List<ContentTask> get overdueTasks => _tasks.where((t) => t.isOverdue(now)).toList();

  List<ContentTask> get awaitingApproval =>
      _tasks.where((t) => t.status == TaskStatus.awaitingApproval).toList();

  List<PackageSummary> get summaries => [
        for (final p in activePackages)
          PackageSummary(
            package: p,
            tasks: _tasks.where((t) => t.packageId == p.id).toList(),
            now: now,
          ),
      ];

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
