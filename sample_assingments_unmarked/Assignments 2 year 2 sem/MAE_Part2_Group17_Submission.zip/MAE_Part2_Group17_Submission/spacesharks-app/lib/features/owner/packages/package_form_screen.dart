import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/common_widgets.dart';

/// Owner creates or edits a client package (CRUD for `packages`).
class PackageFormScreen extends StatefulWidget {
  const PackageFormScreen({super.key, this.existing});
  final ClientPackage? existing;

  @override
  State<PackageFormScreen> createState() => _PackageFormScreenState();
}

class _PackageFormScreenState extends State<PackageFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final _clientName = TextEditingController(text: widget.existing?.clientName);
  late final _packageName = TextEditingController(text: widget.existing?.packageName ?? 'Growth Monthly');
  late final _promised = TextEditingController(text: '${widget.existing?.promisedItems ?? 12}');
  late final _goals = TextEditingController(text: widget.existing?.goals);
  late PackagePhase _phase = widget.existing?.phase ?? PackagePhase.introduction;
  late String? _clientUserId = widget.existing?.clientUserId;
  late bool _active = widget.existing?.active ?? true;
  List<AppUser>? _clients;
  bool _saving = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_clients == null) {
      AppScope.of(context).services.users.getByRole(UserRole.client).then((c) {
        if (mounted) setState(() => _clients = c..sort((a, b) => a.company.compareTo(b.company)));
      });
    }
  }

  @override
  void dispose() {
    _clientName.dispose();
    _packageName.dispose();
    _promised.dispose();
    _goals.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final scope = AppScope.of(context);
    setState(() => _saving = true);
    try {
      final base = widget.existing;
      final package = ClientPackage(
        id: base?.id ?? '',
        clientName: _clientName.text.trim(),
        clientUserId: _clientUserId!,
        packageName: _packageName.text.trim(),
        phase: _phase,
        managerId: base?.managerId ?? scope.user.id,
        managerName: base?.managerName ?? scope.user.name,
        promisedItems: int.parse(_promised.text.trim()),
        startDate: base?.startDate ?? DateTime.now(),
        goals: _goals.text.trim(),
        active: _active,
      );
      if (base == null) {
        await scope.services.packages.create(package);
      } else {
        await scope.services.packages.update(package);
      }
      if (!mounted) return;
      showMessage(context, base == null ? 'Package created.' : 'Package updated.');
      Navigator.of(context).pop();
    } catch (e) {
      if (mounted) showMessage(context, 'Could not save: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final clients = _clients;
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'New package' : 'Edit package')),
      body: clients == null
          ? const LoadingView()
          : MaxWidth(
              maxWidth: 640,
              child: Form(
                key: _formKey,
                child: ListView(padding: const EdgeInsets.all(16), children: [
                  TextFormField(
                    key: const Key('clientNameField'),
                    controller: _clientName,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(labelText: 'Client business name'),
                    validator: Validators.all([Validators.required('Client name'), Validators.maxLength('Client name', 60)]),
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<String>(
                    key: const Key('clientAccountField'),
                    initialValue: _clientUserId,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Client account (who can see it)'),
                    items: [
                      for (final c in clients)
                        DropdownMenuItem(value: c.id, child: Text('${c.company} · ${c.email}', overflow: TextOverflow.ellipsis)),
                    ],
                    onChanged: (v) => setState(() => _clientUserId = v),
                    validator: (v) => v == null ? 'Choose the client account.' : null,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    key: const Key('packageNameField'),
                    controller: _packageName,
                    decoration: const InputDecoration(labelText: 'Package name'),
                    validator: Validators.all([Validators.required('Package name'), Validators.maxLength('Package name', 40)]),
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    key: const Key('promisedField'),
                    controller: _promised,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Deliverables promised per month'),
                    validator: Validators.intInRange('Promised items', 1, 60),
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<PackagePhase>(
                    key: const Key('phaseField'),
                    initialValue: _phase,
                    decoration: const InputDecoration(labelText: 'Phase'),
                    items: [for (final ph in PackagePhase.values) DropdownMenuItem(value: ph, child: Text('${ph.step}. ${ph.label}'))],
                    onChanged: (v) => setState(() => _phase = v ?? _phase),
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    key: const Key('goalsField'),
                    controller: _goals,
                    minLines: 2,
                    maxLines: 4,
                    decoration: const InputDecoration(labelText: 'Goals (optional)'),
                    validator: Validators.maxLength('Goals', 300),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Active package'),
                    value: _active,
                    onChanged: (v) => setState(() => _active = v),
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    key: const Key('savePackageButton'),
                    onPressed: _saving ? null : _save,
                    child: Text(_saving ? 'Saving...' : (widget.existing == null ? 'Create package' : 'Save changes')),
                  ),
                ]),
              ),
            ),
    );
  }
}
