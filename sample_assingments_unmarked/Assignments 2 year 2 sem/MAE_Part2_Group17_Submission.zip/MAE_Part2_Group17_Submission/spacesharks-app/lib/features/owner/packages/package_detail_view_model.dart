import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../../core/models/models.dart';
import '../../../core/services/app_services.dart';
import '../dashboard/owner_dashboard_view_model.dart';
import '../../../core/utils/safe_notifier.dart';

/// One client package for the owner: promised vs delivered, health, the task
/// list and the approval log (OM-UC2, OM-UC5, OM-UC8).
class PackageDetailViewModel extends ChangeNotifier with SafeChangeNotifier {
  PackageDetailViewModel(this._services, this.packageId, {DateTime Function()? clock})
      : _clock = clock ?? DateTime.now;

  final AppServices _services;
  final String packageId;
  final DateTime Function() _clock;
  final List<StreamSubscription<Object?>> _subs = [];

  ClientPackage? _package;
  List<ContentTask> _tasks = [];
  List<Approval> _approvals = [];
  bool _packageLoaded = false;
  bool _tasksLoaded = false;
  TaskStatus? _statusFilter;

  bool get isLoading => !(_packageLoaded && _tasksLoaded);
  bool get notFound => _packageLoaded && _package == null;
  ClientPackage? get package => _package;
  List<Approval> get approvals => _approvals;
  TaskStatus? get statusFilter => _statusFilter;
  DateTime get now => _clock();

  /// Set when the data cannot be loaded (e.g. offline, or the user signed out
  /// while the screen was still listening).
  String? error;

  void _onError(Object e) {
    error = 'Could not load the latest data.';
    notifyListeners();
  }

  void start() {
    _subs.add(_services.packages.watchById(packageId).listen((p) {
      _package = p;
      _packageLoaded = true;
      notifyListeners();
    }, onError: _onError));
    _subs.add(_services.tasks.watchForPackage(packageId).listen((t) {
      _tasks = t;
      _tasksLoaded = true;
      notifyListeners();
    }, onError: _onError));
    _subs.add(_services.feedback.watchApprovalsForPackage(packageId).listen((a) {
      _approvals = a;
      notifyListeners();
    }, onError: _onError));
  }

  PackageSummary? get summary =>
      _package == null ? null : PackageSummary(package: _package!, tasks: _tasks, now: now);

  void setStatusFilter(TaskStatus? status) {
    _statusFilter = status;
    notifyListeners();
  }

  /// Open work first (earliest due first), then delivered work (newest first).
  List<ContentTask> get tasks {
    final list = _statusFilter == null ? _tasks : _tasks.where((t) => t.status == _statusFilter).toList();
    final open = list.where((t) => t.status.isOpen).toList();
    final done = list.where((t) => !t.status.isOpen).toList()..sort((a, b) => b.dueDate.compareTo(a.dueDate));
    return [...open, ...done];
  }

  int countFor(TaskStatus status) => _tasks.where((t) => t.status == status).length;

  /// Changes the engagement phase (OM-UC6).
  Future<void> setPhase(PackagePhase phase) async {
    final p = _package;
    if (p != null) await _services.packages.update(p.copyWith(phase: phase));
  }

  Future<void> deletePackage() => _services.packages.deleteWithTasks(packageId);

  /// Title of the task an approval belongs to.
  String taskTitle(String taskId) =>
      _tasks.where((t) => t.id == taskId).map((t) => t.title).firstOrNull ?? 'Deleted task';

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
