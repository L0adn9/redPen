import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../../core/models/models.dart';
import '../../../core/services/app_services.dart';
import '../../../core/utils/safe_notifier.dart';

enum Capacity {
  overloaded('Overloaded'),
  busy('Busy'),
  hasCapacity('Has capacity');

  const Capacity(this.label);
  final String label;
}

/// One staff member's current load (OM-UC4).
class StaffLoad {
  const StaffLoad({required this.user, required this.openTasks, required this.now});
  final AppUser user;
  final List<ContentTask> openTasks;
  final DateTime now;

  int get open => openTasks.length;
  int get overdue => openTasks.where((t) => t.isOverdue(now)).length;
  int get dueThisWeek => openTasks.where((t) => t.dueDate.difference(now).inDays < 7).length;

  /// 5+ open tasks or 2+ overdue = overloaded; 3-4 = busy; else capacity.
  Capacity get capacity {
    if (open >= 5 || overdue >= 2) return Capacity.overloaded;
    if (open >= 3) return Capacity.busy;
    return Capacity.hasCapacity;
  }
}

/// Owner workload and handover page (OM-UC4, OM-UC7, OM-UC9).
class WorkloadViewModel extends ChangeNotifier with SafeChangeNotifier {
  WorkloadViewModel(this._services, {DateTime Function()? clock}) : _clock = clock ?? DateTime.now;

  final AppServices _services;
  final DateTime Function() _clock;
  final List<StreamSubscription<Object?>> _subs = [];

  List<AppUser> _staff = [];
  List<ContentTask> _tasks = [];
  List<Handover> _handovers = [];
  int _loadedStreams = 0;

  bool get isLoading => _loadedStreams < 3;
  DateTime get now => _clock();
  List<Handover> get handovers => _handovers;
  List<Handover> get pendingHandovers => _handovers.where((h) => !h.isReceived).toList();

  /// Set when the data cannot be loaded (e.g. offline, or the user signed out
  /// while the screen was still listening).
  String? error;

  void _onError(Object e) {
    error = 'Could not load the latest data.';
    notifyListeners();
  }

  void start() {
    void loaded() {
      if (_loadedStreams < 3) _loadedStreams++;
    }

    _subs.add(_services.users.watchByRole(UserRole.staff).listen((s) {
      _staff = s;
      loaded();
      notifyListeners();
    }, onError: _onError));
    _subs.add(_services.tasks.watchAll().listen((t) {
      _tasks = t;
      loaded();
      notifyListeners();
    }, onError: _onError));
    _subs.add(_services.files.watchAllHandovers().listen((h) {
      _handovers = h;
      loaded();
      notifyListeners();
    }, onError: _onError));
  }

  /// Most loaded first.
  List<StaffLoad> get loads => [
        for (final s in _staff)
          StaffLoad(
            user: s,
            openTasks: _tasks.where((t) => t.assigneeId == s.id && t.status.isOpen).toList(),
            now: now,
          ),
      ]..sort((a, b) => b.open.compareTo(a.open));

  /// Hours a handover took to be confirmed, or has been waiting.
  int hoursWaiting(Handover h) => (h.receivedAt ?? now).difference(h.sentAt).inHours;

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
