import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../shared/task_detail/task_detail_screen.dart';
import 'workload_view_model.dart';

Color capacityColor(Capacity c) => switch (c) {
      Capacity.overloaded => AppColors.red,
      Capacity.busy => AppColors.amber,
      Capacity.hasCapacity => AppColors.green,
    };

/// Owner workload and handovers (proposal Figure 6).
class WorkloadScreen extends StatefulWidget {
  const WorkloadScreen({super.key});

  @override
  State<WorkloadScreen> createState() => _WorkloadScreenState();
}

class _WorkloadScreenState extends State<WorkloadScreen> {
  WorkloadViewModel? _vm;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _vm ??= WorkloadViewModel(AppScope.of(context).services)..start();
  }

  @override
  void dispose() {
    _vm?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final vm = _vm!;
    final scope = AppScope.of(context);
    return ListenableBuilder(
      listenable: vm,
      builder: (context, _) {
        if (vm.isLoading) return const LoadingView();
        return MaxWidth(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const SectionHeader('Team workload'),
              AdaptiveGrid(children: [
                for (final load in vm.loads)
                  Card(
                    child: Theme(
                      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                      child: ExpansionTile(
                        key: Key('staff_${load.user.id}'),
                        leading: UserAvatar(name: load.user.name),
                        title: Text(load.user.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('${load.user.jobTitle}\n${load.open} open · ${load.overdue} overdue · ${load.dueThisWeek} due in 7 days'),
                        trailing: Pill(label: load.capacity.label, color: capacityColor(load.capacity)),
                        children: [
                          for (final t in load.openTasks)
                            ListTile(
                              dense: true,
                              title: Text(t.title),
                              subtitle: Text('${t.clientName} · ${formatDue(t.dueDate, vm.now)}',
                                  style: TextStyle(color: t.isOverdue(vm.now) ? AppColors.red : null)),
                              trailing: IconButton(
                                tooltip: 'Request status update',
                                icon: const Icon(Icons.help_outline),
                                onPressed: () async {
                                  await scope.services.alerts.requestStatus(task: t, owner: scope.user);
                                  if (context.mounted) showMessage(context, 'Asked ${t.assigneeName} for an update.');
                                },
                              ),
                              onTap: () => TaskDetailScreen.open(context, t.id),
                            ),
                          if (load.openTasks.isEmpty)
                            const ListTile(dense: true, title: Text('No open tasks')),
                        ],
                      ),
                    ),
                  ),
              ]),
              SectionHeader('Handovers (${vm.pendingHandovers.length} waiting)'),
              if (vm.handovers.isEmpty) const Text('No handovers yet.', style: TextStyle(color: AppColors.muted)),
              for (final h in vm.handovers)
                Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: Icon(h.isReceived ? Icons.task_alt : Icons.schedule,
                        color: h.isReceived ? AppColors.green : AppColors.amber),
                    title: Text(h.taskTitle),
                    subtitle: Text('${h.fromName} → ${h.toName} · sent ${formatDateTime(h.sentAt)}\n'
                        '${h.isReceived ? 'Received ${formatDateTime(h.receivedAt!)}' : 'Not confirmed yet (${vm.hoursWaiting(h)} h)'}'
                        '${h.note.isEmpty ? '' : '\n"${h.note}"'}'),
                    isThreeLine: true,
                    onTap: () => TaskDetailScreen.open(context, h.taskId),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
