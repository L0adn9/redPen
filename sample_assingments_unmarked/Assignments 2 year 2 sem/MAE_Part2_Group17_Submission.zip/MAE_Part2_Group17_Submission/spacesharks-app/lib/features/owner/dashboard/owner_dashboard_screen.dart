import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../shared/task_detail/task_detail_screen.dart';
import '../packages/package_detail_screen.dart';
import '../packages/package_form_screen.dart';
import '../../shared/task_card.dart';
import 'owner_dashboard_view_model.dart';

/// Owner/Manager client packages dashboard (proposal Figure 5).
/// Tiles (OM-UC1, OM-UC3), package cards with promised vs delivered and the
/// health indicator (OM-UC2, OM-UC8), and the overdue list.
class OwnerDashboardScreen extends StatefulWidget {
  const OwnerDashboardScreen({super.key});

  @override
  State<OwnerDashboardScreen> createState() => _OwnerDashboardScreenState();
}

class _OwnerDashboardScreenState extends State<OwnerDashboardScreen> {
  OwnerDashboardViewModel? _vm;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _vm ??= OwnerDashboardViewModel(AppScope.of(context).services)..start();
  }

  @override
  void dispose() {
    _vm?.dispose();
    super.dispose();
  }

  void _openPackage(PackageSummary s) => Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => PackageDetailScreen(packageId: s.package.id)));

  @override
  Widget build(BuildContext context) {
    final vm = _vm!;
    return ListenableBuilder(
      listenable: vm,
      builder: (context, _) {
        if (vm.error != null) return ErrorView(message: vm.error!);
        if (vm.isLoading) return const LoadingView();
        final summaries = vm.summaries;
        return Stack(children: [
          MaxWidth(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            children: [
              StatRow(children: [
                StatTile(label: 'Active packages', value: '${vm.activePackages.length}', icon: Icons.inventory_2_outlined),
                StatTile(label: 'Overdue items', value: '${vm.overdueTasks.length}', icon: Icons.warning_amber_rounded, color: AppColors.red),
                StatTile(label: 'Awaiting client approval', value: '${vm.awaitingApproval.length}', icon: Icons.hourglass_top, color: AppColors.amber),
              ]),
              const SectionHeader('Client packages'),
              if (summaries.isEmpty)
                const EmptyState(icon: Icons.inventory_2_outlined, title: 'No active packages'),
              AdaptiveGrid(children: [
                for (final s in summaries) _PackageCard(summary: s, onTap: () => _openPackage(s)),
              ]),
              if (vm.overdueTasks.isNotEmpty) ...[
                const SectionHeader('Overdue'),
                for (final t in vm.overdueTasks)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: TaskCard(task: t, now: vm.now, showAssignee: true, onTap: () => TaskDetailScreen.open(context, t.id)),
                  ),
              ],
            ],
          ),
          ),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton.extended(
              key: const Key('newPackageButton'),
              heroTag: 'newPackage',
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const PackageFormScreen())),
              icon: const Icon(Icons.add),
              label: const Text('New package'),
            ),
          ),
        ]);
      },
    );
  }
}

class _PackageCard extends StatelessWidget {
  const _PackageCard({required this.summary, required this.onTap});
  final PackageSummary summary;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = summary.package;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        key: Key('package_${p.id}'),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                child: Text(p.clientName,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              ),
              Pill(label: summary.health.label, color: healthColor(summary.health)),
            ]),
            Text('${p.packageName} · ${p.managerName}',
                style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            const SizedBox(height: 10),
            PhaseBadge(p.phase),
            const SizedBox(height: 12),
            Text('Delivered ${summary.delivered} of ${p.promisedItems} promised',
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            LinearProgressIndicator(
              value: summary.deliveryProgress,
              minHeight: 6,
              borderRadius: BorderRadius.circular(99),
              backgroundColor: AppColors.line,
              color: AppColors.green,
            ),
            const SizedBox(height: 10),
            Text('${summary.dueThisWeek} due this week · ${summary.overdue} overdue · ${summary.awaitingApproval} awaiting approval',
                style: const TextStyle(color: AppColors.muted, fontSize: 13)),
          ]),
        ),
      ),
    );
  }
}
