import 'package:flutter/material.dart';

import '../shared/role_shell.dart';
import 'calendar/owner_calendar_screen.dart';
import 'dashboard/owner_dashboard_screen.dart';
import 'workload/workload_screen.dart';

/// Owner/Manager home: dashboard, team workload, content calendar.
class OwnerHome extends StatelessWidget {
  const OwnerHome({super.key});

  @override
  Widget build(BuildContext context) => RoleShell(tabs: [
        RoleTab(
          label: 'Dashboard',
          icon: Icons.dashboard_outlined,
          selectedIcon: Icons.dashboard,
          builder: (_) => const OwnerDashboardScreen(),
        ),
        RoleTab(
          label: 'Workload',
          icon: Icons.groups_outlined,
          selectedIcon: Icons.groups,
          builder: (_) => const WorkloadScreen(),
        ),
        RoleTab(
          label: 'Calendar',
          icon: Icons.calendar_month_outlined,
          selectedIcon: Icons.calendar_month,
          builder: (_) => const OwnerCalendarScreen(),
        ),
      ]);
}
