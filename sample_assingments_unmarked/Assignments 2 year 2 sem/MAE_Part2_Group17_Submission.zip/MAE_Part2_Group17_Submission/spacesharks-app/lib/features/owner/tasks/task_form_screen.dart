import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/common_widgets.dart';
import 'task_form_view_model.dart';

/// Owner creates or edits a task and assigns it (CRUD: create/update).
class TaskFormScreen extends StatefulWidget {
  const TaskFormScreen({super.key, required this.packageId, this.existing});
  final String packageId;
  final ContentTask? existing;

  @override
  State<TaskFormScreen> createState() => _TaskFormScreenState();
}

class _TaskFormScreenState extends State<TaskFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final _title = TextEditingController(text: widget.existing?.title);
  late final _description = TextEditingController(text: widget.existing?.description);
  late ContentType _type = widget.existing?.contentType ?? ContentType.post;
  late TaskPriority _priority = widget.existing?.priority ?? TaskPriority.medium;
  late DateTime? _due = widget.existing?.dueDate;
  late DateTime? _publish = widget.existing?.publishDate;
  String? _assigneeId;
  String? _dateError;
  TaskFormViewModel? _vm;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final scope = AppScope.of(context);
    _assigneeId ??= widget.existing?.assigneeId;
    _vm ??= TaskFormViewModel(scope.services, scope.user,
        packageId: widget.packageId, existing: widget.existing)
      ..load();
  }

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    _vm?.dispose();
    super.dispose();
  }

  Future<DateTime?> _pickDate(DateTime? initial, {required DateTime first}) async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: initial != null && !initial.isBefore(first) ? initial : first,
      firstDate: first,
      lastDate: DateTime(now.year + 2),
    );
    if (date == null) return null;
    return TaskFormViewModel.dueTimeFor(date, DateTime.now());
  }

  Future<void> _save() async {
    final vm = _vm!;
    final formOk = _formKey.currentState!.validate();
    final now = DateTime.now();
    final dateError = TaskFormViewModel.checkDates(due: _due, publish: _publish) ??
        (!vm.isEditing ? Validators.notInPast(_due, now) : null);
    setState(() => _dateError = dateError);
    if (!formOk || dateError != null) return;
    final assignee = vm.staff.firstWhere((s) => s.user.id == _assigneeId).user;
    final ok = await vm.save(
      title: _title.text,
      description: _description.text,
      type: _type,
      assignee: assignee,
      priority: _priority,
      due: _due!,
      publish: _publish,
    );
    if (!mounted) return;
    if (ok) {
      showMessage(context, vm.isEditing ? 'Task updated.' : 'Task created and ${assignee.name} notified.');
      Navigator.of(context).pop();
    } else {
      showMessage(context, vm.error ?? 'Could not save.', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final vm = _vm!;
    return Scaffold(
      appBar: AppBar(title: Text(vm.isEditing ? 'Edit task' : 'New task')),
      body: ListenableBuilder(
        listenable: vm,
        builder: (context, _) {
          if (vm.isLoading) return const LoadingView();
          if (vm.error != null && vm.staff.isEmpty) return ErrorView(message: vm.error!);
          final now = DateTime.now();
          final today = DateTime(now.year, now.month, now.day);
          return MaxWidth(
            maxWidth: 640,
            child: Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (vm.package != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text('For ${vm.package!.clientName}',
                          style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
                    ),
                  TextFormField(
                    key: const Key('taskTitleField'),
                    controller: _title,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: const InputDecoration(labelText: 'Title'),
                    validator: Validators.all([Validators.required('Title'), Validators.maxLength('Title', 80)]),
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    key: const Key('taskDescriptionField'),
                    controller: _description,
                    minLines: 2,
                    maxLines: 5,
                    decoration: const InputDecoration(labelText: 'Brief / notes (optional)'),
                    validator: Validators.maxLength('Brief', 500),
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<ContentType>(
                    key: const Key('taskTypeField'),
                    initialValue: _type,
                    decoration: const InputDecoration(labelText: 'Content type'),
                    items: [for (final t in ContentType.values) DropdownMenuItem(value: t, child: Text(t.label))],
                    onChanged: (v) => setState(() => _type = v ?? _type),
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<String>(
                    key: const Key('taskAssigneeField'),
                    initialValue: _assigneeId,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Assign to', helperText: 'Sorted by fewest open tasks'),
                    items: [
                      for (final s in vm.staff)
                        DropdownMenuItem(
                          value: s.user.id,
                          child: Text('${s.user.name} · ${s.user.jobTitle} · ${s.openTasks} open',
                              overflow: TextOverflow.ellipsis),
                        ),
                    ],
                    onChanged: (v) => setState(() => _assigneeId = v),
                    validator: (v) => v == null ? 'Choose who will do this.' : null,
                  ),
                  const SizedBox(height: 18),
                  const Text('Priority', style: TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  SegmentedButton<TaskPriority>(
                    key: const Key('taskPriorityField'),
                    segments: [for (final p in TaskPriority.values) ButtonSegment(value: p, label: Text(p.label))],
                    selected: {_priority},
                    onSelectionChanged: (s) => setState(() => _priority = s.first),
                  ),
                  const SizedBox(height: 18),
                  Row(children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        key: const Key('taskDueButton'),
                        onPressed: () async {
                          final d = await _pickDate(_due, first: vm.isEditing ? DateTime(2020) : today);
                          if (d != null) setState(() => _due = d);
                        },
                        icon: const Icon(Icons.event),
                        label: Text(_due == null ? 'Due date' : 'Due ${formatDay(_due!)}'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        key: const Key('taskPublishButton'),
                        onPressed: () async {
                          final d = await _pickDate(_publish ?? _due, first: vm.isEditing ? DateTime(2020) : today);
                          if (d != null) setState(() => _publish = DateTime(d.year, d.month, d.day, 10));
                        },
                        icon: const Icon(Icons.campaign_outlined),
                        label: Text(_publish == null ? 'Publish date' : 'Publish ${formatDay(_publish!)}'),
                      ),
                    ),
                  ]),
                  if (_dateError != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(_dateError!, key: const Key('taskDateError'), style: const TextStyle(color: AppColors.red)),
                    ),
                  const SizedBox(height: 24),
                  FilledButton(
                    key: const Key('saveTaskButton'),
                    onPressed: vm.isSaving ? null : _save,
                    child: Text(vm.isSaving ? 'Saving...' : (vm.isEditing ? 'Save changes' : 'Create task')),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
