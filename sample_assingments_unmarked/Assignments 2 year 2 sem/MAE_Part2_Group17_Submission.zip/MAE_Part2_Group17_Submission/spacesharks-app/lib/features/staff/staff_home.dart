import 'package:flutter/material.dart';

import '../shared/role_shell.dart';
import 'handovers/handovers_screen.dart';
import 'tasks/my_tasks_screen.dart';
import 'week/my_week_screen.dart';

/// Content Creator / Staff home: my tasks, my week, handovers.
class StaffHome extends StatelessWidget {
  const StaffHome({super.key});

  @override
  Widget build(BuildContext context) => RoleShell(tabs: [
        RoleTab(
          label: 'My tasks',
          icon: Icons.checklist_outlined,
          selectedIcon: Icons.checklist,
          builder: (_) => const MyTasksScreen(),
        ),
        RoleTab(
          label: 'My week',
          icon: Icons.calendar_month_outlined,
          selectedIcon: Icons.calendar_month,
          builder: (_) => const MyWeekScreen(),
        ),
        RoleTab(
          label: 'Handovers',
          icon: Icons.swap_horiz_outlined,
          selectedIcon: Icons.swap_horiz,
          builder: (_) => const HandoversScreen(),
        ),
      ]);
}
