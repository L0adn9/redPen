import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../../core/widgets/dialogs.dart';
import '../../shared/calendar/weekly_calendar.dart';
import '../../shared/task_detail/task_detail_screen.dart';

/// Staff weekly calendar and workload, with "Flag overload" (ST-UC8).
class MyWeekScreen extends StatelessWidget {
  const MyWeekScreen({super.key});

  Future<void> _flag(BuildContext context, int open) async {
    final scope = AppScope.of(context);
    final reason = await askForText(context,
        title: 'Flag overload to the manager',
        label: 'Why? What should move?',
        hint: 'e.g. 3 reels due Friday, can someone take the Glow Skin one?',
        confirmLabel: 'Send flag',
        required: true);
    if (reason == null) return;
    await scope.services.alerts.flagOverload(staff: scope.user, openTasks: open, reason: reason);
    if (context.mounted) showMessage(context, 'Your manager has been alerted.');
  }

  @override
  Widget build(BuildContext context) {
    final scope = AppScope.of(context);
    return StreamBuilder<List<ContentTask>>(
      stream: scope.services.tasks.watchForAssignee(scope.user.id),
      builder: (context, snapshot) {
        if (snapshot.hasError) return ErrorView(message: '${snapshot.error}');
        if (!snapshot.hasData) return const LoadingView();
        final now = DateTime.now();
        final tasks = snapshot.data!;
        final open = tasks.where((t) => t.status.isOpen).toList();
        final overdue = open.where((t) => t.isOverdue(now)).length;
        final week = open.where((t) => t.dueDate.difference(now).inDays < 7).length;
        return MaxWidth(
          maxWidth: 820,
          child: ListView(padding: const EdgeInsets.all(16), children: [
            StatRow(children: [
              StatTile(label: 'Open tasks', value: '${open.length}', icon: Icons.checklist),
              StatTile(label: 'Due in 7 days', value: '$week', icon: Icons.event, color: AppColors.amber),
              StatTile(label: 'Overdue', value: '$overdue', icon: Icons.warning_amber_rounded, color: AppColors.red),
            ]),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              key: const Key('flagOverloadButton'),
              onPressed: () => _flag(context, open.length),
              icon: const Icon(Icons.local_fire_department_outlined, color: AppColors.red),
              label: const Text('Too much work? Flag overload to the manager'),
            ),
            const SectionHeader('My week'),
            WeeklyCalendar(tasks: tasks, showAssignee: false, onTaskTap: (t) => TaskDetailScreen.open(context, t.id)),
          ]),
        );
      },
    );
  }
}
