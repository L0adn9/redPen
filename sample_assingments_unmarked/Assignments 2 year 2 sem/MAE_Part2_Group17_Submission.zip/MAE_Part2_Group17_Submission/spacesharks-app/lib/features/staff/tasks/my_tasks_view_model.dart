import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../../core/models/models.dart';
import '../../../core/services/app_services.dart';
import '../../../core/utils/safe_notifier.dart';

/// Ranks open tasks so the most urgent comes first (ST-UC3).
/// Overdue beats due-soon, then priority, then the earlier due date.
int compareUrgency(ContentTask a, ContentTask b, DateTime now) {
  int bucket(ContentTask t) {
    if (t.isOverdue(now)) return 0;
    if (t.status == TaskStatus.changesRequested) return 1;
    if (t.dueDate.difference(now).inHours <= 48) return 2;
    return 3;
  }

  final byBucket = bucket(a).compareTo(bucket(b));
  if (byBucket != 0) return byBucket;
  final byPriority = a.priority.index.compareTo(b.priority.index);
  if (byPriority != 0) return byPriority;
  return a.dueDate.compareTo(b.dueDate);
}

/// Staff "My tasks" state. Owned by: Muntasir (starter written for the base).
class MyTasksViewModel extends ChangeNotifier with SafeChangeNotifier {
  MyTasksViewModel(this._services, this._user, {DateTime Function()? clock})
      : _clock = clock ?? DateTime.now;

  final AppServices _services;
  final AppUser _user;
  final DateTime Function() _clock;
  StreamSubscription<List<ContentTask>>? _sub;

  List<ContentTask> _tasks = [];
  bool _loaded = false;
  String? _error;
  String? _clientFilter;

  bool get isLoading => !_loaded && _error == null;
  String? get error => _error;
  DateTime get now => _clock();
  String? get clientFilter => _clientFilter;

  void start() {
    _sub = _services.tasks.watchForAssignee(_user.id).listen((tasks) {
      _tasks = tasks;
      _loaded = true;
      notifyListeners();
    }, onError: (Object e) {
      _error = 'Could not load your tasks: $e';
      notifyListeners();
    });
  }

  /// Clients this person has tasks for (filter chips, ST-UC2).
  List<String> get clients => {for (final t in _tasks) t.clientName}.toList()..sort();

  void setClientFilter(String? client) {
    _clientFilter = client;
    notifyListeners();
  }

  Iterable<ContentTask> get _filtered =>
      _clientFilter == null ? _tasks : _tasks.where((t) => t.clientName == _clientFilter);

  List<ContentTask> get _open =>
      _filtered.where((t) => t.status.isOpen).toList()..sort((a, b) => compareUrgency(a, b, now));

  /// Overdue, changes requested, or due within 48 hours.
  List<ContentTask> get doFirst => _open
      .where((t) =>
          t.isOverdue(now) ||
          t.status == TaskStatus.changesRequested ||
          t.dueDate.difference(now).inHours <= 48)
      .toList();

  List<ContentTask> get later => _open.where((t) => !doFirst.contains(t)).toList();

  List<ContentTask> get done =>
      _filtered.where((t) => t.status == TaskStatus.approved).toList();

  int get openCount => _open.length;

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
