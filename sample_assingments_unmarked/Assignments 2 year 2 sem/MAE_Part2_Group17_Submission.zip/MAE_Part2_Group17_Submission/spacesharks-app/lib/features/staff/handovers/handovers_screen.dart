import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../shared/task_detail/task_detail_screen.dart';

/// Staff handovers: confirm files handed to me, and check whether my
/// handovers were received (ST-UC6).
class HandoversScreen extends StatelessWidget {
  const HandoversScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scope = AppScope.of(context);
    final files = scope.services.files;
    return StreamBuilder<List<Handover>>(
      stream: files.watchHandoversTo(scope.user.id),
      builder: (context, toMe) => StreamBuilder<List<Handover>>(
        stream: files.watchHandoversFrom(scope.user.id),
        builder: (context, fromMe) {
          if (!toMe.hasData || !fromMe.hasData) return const LoadingView();
          final incoming = [...toMe.data!]..sort((a, b) => (a.isReceived ? 1 : 0).compareTo(b.isReceived ? 1 : 0));
          return MaxWidth(
            maxWidth: 760,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              SectionHeader('Handed to me (${incoming.where((h) => !h.isReceived).length} to confirm)'),
              if (incoming.isEmpty) const Text('Nothing handed to you.', style: TextStyle(color: AppColors.muted)),
              for (final h in incoming)
                _HandoverCard(
                  handover: h,
                  subtitle: 'From ${h.fromName} · ${formatDateTime(h.sentAt)}',
                  action: h.isReceived
                      ? null
                      : FilledButton(
                          key: Key('confirm_${h.id}'),
                          onPressed: () async {
                            await files.confirmReceived(h.id);
                            if (context.mounted) showMessage(context, '${h.fromName} can now see you received it.');
                          },
                          child: const Text('Confirm received'),
                        ),
                ),
              SectionHeader('Handed over by me (${fromMe.data!.length})'),
              if (fromMe.data!.isEmpty) const Text('You have not handed anything over.', style: TextStyle(color: AppColors.muted)),
              for (final h in fromMe.data!)
                _HandoverCard(handover: h, subtitle: 'To ${h.toName} · ${formatDateTime(h.sentAt)}'),
            ]),
          );
        },
      ),
    );
  }
}

class _HandoverCard extends StatelessWidget {
  const _HandoverCard({required this.handover, required this.subtitle, this.action});
  final Handover handover;
  final String subtitle;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    final h = handover;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: () => TaskDetailScreen.open(context, h.taskId),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(h.taskTitle, style: const TextStyle(fontWeight: FontWeight.w700))),
              Pill(
                label: h.isReceived ? 'Received' : 'Waiting',
                color: h.isReceived ? AppColors.green : AppColors.amber,
                icon: h.isReceived ? Icons.task_alt : Icons.schedule,
              ),
            ]),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            if (h.note.isNotEmpty) ...[const SizedBox(height: 6), Text('"${h.note}"')],
            if (h.isReceived)
              Text('Confirmed ${formatDateTime(h.receivedAt!)}', style: const TextStyle(color: AppColors.green, fontSize: 12)),
            if (action != null) ...[const SizedBox(height: 10), Align(alignment: Alignment.centerRight, child: action)],
          ]),
        ),
      ),
    );
  }
}
