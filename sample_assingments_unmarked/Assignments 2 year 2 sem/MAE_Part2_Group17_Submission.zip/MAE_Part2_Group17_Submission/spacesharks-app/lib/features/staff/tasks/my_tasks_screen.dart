import 'package:flutter/material.dart';

import '../../../core/app_scope.dart';
import '../../../core/models/models.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../shared/task_detail/task_detail_screen.dart';
import '../../shared/task_card.dart';
import 'my_tasks_view_model.dart';

/// Staff task list with "Do first" (proposal Figure 7).
/// Sorted by urgency (ST-UC3) with a client filter (ST-UC2).
class MyTasksScreen extends StatefulWidget {
  const MyTasksScreen({super.key});

  @override
  State<MyTasksScreen> createState() => _MyTasksScreenState();
}

class _MyTasksScreenState extends State<MyTasksScreen> {
  MyTasksViewModel? _vm;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final scope = AppScope.of(context);
    _vm ??= MyTasksViewModel(scope.services, scope.user)..start();
  }

  @override
  void dispose() {
    _vm?.dispose();
    super.dispose();
  }

  void _openTask(ContentTask task) => TaskDetailScreen.open(context, task.id);

  @override
  Widget build(BuildContext context) {
    final vm = _vm!;
    return ListenableBuilder(
      listenable: vm,
      builder: (context, _) {
        if (vm.error != null) return ErrorView(message: vm.error!);
        if (vm.isLoading) return const LoadingView();
        Widget card(ContentTask t) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: TaskCard(key: Key('task_${t.id}'), task: t, now: vm.now, onTap: () => _openTask(t)),
            );
        return MaxWidth(
          maxWidth: 760,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: [
                  ChoiceChip(
                    label: const Text('All clients'),
                    selected: vm.clientFilter == null,
                    onSelected: (_) => vm.setClientFilter(null),
                  ),
                  for (final c in vm.clients) ...[
                    const SizedBox(width: 8),
                    ChoiceChip(
                      label: Text(c),
                      selected: vm.clientFilter == c,
                      onSelected: (_) => vm.setClientFilter(c),
                    ),
                  ],
                ]),
              ),
              SectionHeader('Do first (${vm.doFirst.length})'),
              if (vm.doFirst.isEmpty) const Text('Nothing urgent right now.'),
              for (final t in vm.doFirst) card(t),
              SectionHeader('Later (${vm.later.length})'),
              for (final t in vm.later) card(t),
              if (vm.done.isNotEmpty) ...[
                SectionHeader('Approved (${vm.done.length})'),
                for (final t in vm.done) card(t),
              ],
            ],
          ),
        );
      },
    );
  }
}
