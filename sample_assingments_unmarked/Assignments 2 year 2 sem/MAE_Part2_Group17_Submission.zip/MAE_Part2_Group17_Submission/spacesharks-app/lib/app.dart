import 'package:flutter/material.dart';

import 'core/app_scope.dart';
import 'core/config/app_config.dart';
import 'core/services/app_services.dart';
import 'core/session/session_view_model.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/auth_gate.dart';

class SpacesharksApp extends StatefulWidget {
  const SpacesharksApp({super.key, required this.services});
  final AppServices services;

  @override
  State<SpacesharksApp> createState() => _SpacesharksAppState();
}

class _SpacesharksAppState extends State<SpacesharksApp> {
  late final SessionViewModel _session = SessionViewModel(widget.services.auth);

  @override
  void dispose() {
    _session.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AppScope(
        services: widget.services,
        session: _session,
        child: MaterialApp(
          title: AppConfig.appName,
          debugShowCheckedModeBanner: false,
          theme: AppTheme.light(),
          home: const AuthGate(),
        ),
      );
}
