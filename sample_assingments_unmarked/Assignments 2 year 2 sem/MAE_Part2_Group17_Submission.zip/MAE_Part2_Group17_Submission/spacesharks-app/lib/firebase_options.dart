// Firebase settings for the project "spacesharks-app" (Android and Web).
// Values come from the Firebase console (google-services.json and the web
// app's firebaseConfig). They are not secrets: access is controlled by
// firestore.rules. Used only when the app runs with --dart-define=BACKEND=firebase.

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    if (defaultTargetPlatform == TargetPlatform.android) return android;
    throw UnsupportedError(
        'Firebase is set up for Android and Web only. Register an iOS app in '
        'the Firebase console and run `flutterfire configure` to add iOS.');
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDElI75oa46QZE7_rWg1GxXVjG4CXHufDM',
    appId: '1:476977493266:android:e2f22f24476993e0f9efcb',
    messagingSenderId: '476977493266',
    projectId: 'spacesharks-app',
    storageBucket: 'spacesharks-app.firebasestorage.app',
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBcB3Bj9JkjI5XiG2ykW3NcJjOOF7-R3wM',
    appId: '1:476977493266:web:53551b6c5eee9af3f9efcb',
    messagingSenderId: '476977493266',
    projectId: 'spacesharks-app',
    authDomain: 'spacesharks-app.firebaseapp.com',
    storageBucket: 'spacesharks-app.firebasestorage.app',
  );
}
