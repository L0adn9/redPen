# Firebase setup (Kaung)

The app is finished, but it runs on **demo data** right now (stored in memory and reset on every restart). These steps connect it to a real Firebase project, which is the backend database the report describes (section 4.0).

**You only need a browser and a Google account.** You do not need Flutter, Android Studio or any code. It takes about 20 minutes.

| Part | Who | Time |
|---|---|---|
| A. Create the project in the Firebase console | Kaung | 15 min |
| B. Send Hassan two config files/snippets | Kaung | 2 min |
| C. Connect the app and load the demo data | Hassan | 10 min |
| D. Publish the security rules | Kaung | 2 min |
| E. Test every role on Firebase | Everyone | 15 min |

---

## Part A: Create the project (Kaung)

### A1. New project
1. Go to <https://console.firebase.google.com> and sign in with your Google account.
2. Click **Create a project** (or **Add project**).
3. Name: `spacesharks-app`. Click **Continue**.
4. Google Analytics: **turn it off** (we don't need it). Click **Create project**, wait, then **Continue**.

You are now on the project overview page. Note the **Project ID** under the project name (e.g. `spacesharks-app-1a2b3`). We need it later.

### A2. Turn on sign-in (Authentication)
1. Left menu: **Build → Authentication → Get started**.
2. **Sign-in method** tab → click **Email/Password**.
3. Turn on the first switch (**Email/Password**). Leave "Email link" off. Click **Save**.

### A3. Create the database (Cloud Firestore)
1. Left menu: **Build → Firestore Database → Create database**.
2. Edition (if asked): **Standard**.
3. Location: **asia-southeast1 (Singapore)**. This cannot be changed later.
4. Security rules: choose **Start in test mode**. Click **Create**.

> Test mode lets the app load the demo data in Part C. We replace it with our real rules in Part D, so don't skip Part D.

**Do not** turn on Cloud Storage. It needs the paid Blaze plan, and the app stores files inside Firestore instead (max about 700 KB per file, already explained in the report).

### A4. Register the Android app
1. Go back to **Project overview** (house icon, top left).
2. Click the **Android** icon (or **Add app → Android**).
3. **Android package name**: copy exactly:
   ```
   com.spacesharks.spacesharks_app
   ```
4. App nickname: `SPACESHARKS Android`. Leave the SHA-1 empty. Click **Register app**.
5. Click **Download google-services.json**. Keep this file.
6. Click **Next**, **Next**, **Continue to console**. Ignore the Gradle/SDK instructions. They are already handled in the code.

### A5. Register the Web app (so we can test in Chrome)
1. **Project overview → Add app → Web** (the `</>` icon).
2. Nickname: `SPACESHARKS Web`. Leave "Firebase Hosting" **unticked**. Click **Register app**.
3. You'll see a code box with `const firebaseConfig = { apiKey: ..., authDomain: ..., projectId: ..., ... };`.
   **Copy the whole `firebaseConfig = { ... }` block.**
4. Click **Continue to console**.

### A6. Add Hassan to the project (recommended)
So Hassan can check the data and fix things without asking you:
1. Gear icon (top left) → **Project settings → Users and permissions**.
2. **Add member** → Hassan's Gmail → role **Editor** → **Add member**.

---

## Part B: Send Hassan (Kaung)

Send these in the WhatsApp group or a direct message:

1. The **`google-services.json`** file from A4.
2. The **`firebaseConfig = { ... }`** block from A5.
3. The **Project ID**.

These are not secret passwords. Firebase config values are meant to be inside the app. Security comes from the rules in Part D. Still, don't post them publicly.

---

## Part C: Connect the app (Hassan, with Claude)

Hassan sends the files to Claude, who:

1. Replaces the placeholder `lib/firebase_options.dart` with the real values for Android and Web, and adds `android/app/google-services.json`.
2. Pushes the change to GitHub.

Then Hassan, on his Mac:

```bash
git pull
flutter run -d chrome --dart-define=BACKEND=firebase
```

3. On the login screen tap **Developer: load demo data into Firebase** (only visible in this debug run). Wait until it finishes (about 30 seconds).
4. Check in the Firebase console:
   - **Authentication → Users**: 7 users (`owner@spacesharks.test`, 3 staff, 3 clients).
   - **Firestore Database → Data**: collections `users`, `packages`, `tasks`, `comments`, `approvals`, `versions`, `handovers`, `alerts`.

All demo accounts use the password `password123`.

> **Alternative if Kaung already has Flutter installed:** in the project folder run
> `dart pub global activate flutterfire_cli`, then
> `flutterfire configure --project=<project-id> --platforms=android,web`.
> This writes `lib/firebase_options.dart` and `android/app/google-services.json` for you. Commit and push both files. Then do steps 3 and 4 above.

---

## Part D: Publish the security rules (Kaung, after Part C)

Only after the demo data is loaded:

1. Open `firestore.rules` in this repository on GitHub and copy all of it.
2. Firebase console → **Firestore Database → Rules** tab.
3. Delete everything in the editor, paste our rules, click **Publish**.

What the rules enforce (this is in the report, section 3.2):
- Owners read and write everything.
- Staff read packages and tasks, and update their own work, handovers and comments.
- Clients only see their own package, its deliverables, comments and approvals.

If you ever need to reload the demo data, switch back to test mode first (Rules tab → History, or paste the test-mode rule), load it, then publish our rules again.

### D2. Screenshots for the report
Take these and send them to Hassan (they go in section 4.0 of the report):
- **Authentication → Users** (the 7 accounts)
- **Firestore Database → Data** (the collections with documents)
- **Firestore Database → Rules** (our published rules)

---

## Part E: Test every role on Firebase (everyone)

Run with `flutter run -d chrome --dart-define=BACKEND=firebase` (or install the Firebase APK from Hassan). Tick each line:

| # | Sign in as | Check | OK? |
|---|---|---|---|
| 1 | `owner@spacesharks.test` | Dashboard shows 3 packages with health labels | |
| 2 | owner | Create a new task for Kopi Kita, assign it to Priya Nair (copywriter) | |
| 3 | `writer@spacesharks.test` | The new task is in **My tasks** with a "New task" alert | |
| 4 | writer | Start work, upload an image, send for approval | |
| 5 | `client@kopikita.test` | Alert "Please review", open it, **Approve** | |
| 6 | owner | Package shows the approval in the **Approval log** with time | |
| 7 | `client@glowskin.test` | Can **not** see Kopi Kita's package (rules work) | |
| 8 | any | Close and reopen the app: the data is still there | |
| 9 | two devices | Approve on one, the other updates within a second | |

If something fails, screenshot the error and send it to Hassan.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "Firebase is not configured yet" | Part C not done yet: `lib/firebase_options.dart` is still the placeholder. |
| "Incorrect email or password" for demo accounts | Demo data not loaded yet (Part C step 3), or Email/Password is not enabled (A2). |
| "Missing or insufficient permissions" while loading demo data | Rules were published before loading. Switch Firestore back to test mode, load, publish again (Part D). |
| "Missing or insufficient permissions" when using the app | The user's profile is missing from `users`. Reload the demo data. |
| No "load demo data" button | It only shows in a debug run with `--dart-define=BACKEND=firebase`, not in the release APK. |
| Upload says the file is too large | Use an image under 700 KB (we're on the free plan). |

## Final APK (Hassan, Friday)

```bash
flutter build apk --release --dart-define=BACKEND=firebase
# APK: build/app/outputs/flutter-apk/app-release.apk
```
